// ====================================================================
// 《大明国策 v2》静态数据
// 八个模块：地图/省/兵/将/府部/市肆/敌国/间谍
// ====================================================================

// 朝代与年号
const DYNASTY = '大明';
const REIGN_TITLE = '永乐';
const START_YEAR = 1;
const SEASONS = ['春', '夏', '秋', '冬'];

// 1) 大明行政区与战略要地（自定坐标体系，逻辑地图，500x500 像素画布）
// 0..499 的逻辑坐标，画布自适应
// 属性：人口(万)、粮产(万石)、商业、城防、忠诚、兵源、是否有卫所
const PROVINCES = [
    { id:'shunTian',    name:'顺天府',     x:330, y:200, pop:480, grain:120, commerce:80,  fort:90, loyalty:80, garrison:15000, type:'capital' },
    { id:'shanDong',    name:'山东',       x:360, y:240, pop:620, grain:150, commerce:60,  fort:55, loyalty:65, garrison:8000,  type:'plain' },
    { id:'heNan',       name:'河南',       x:300, y:270, pop:540, grain:180, commerce:50,  fort:50, loyalty:70, garrison:6000,  type:'plain' },
    { id:'shaanXi',     name:'陕西',       x:230, y:280, pop:300, grain:90,  commerce:30,  fort:60, loyalty:55, garrison:12000, type:'border' },
    { id:'ningXia',     name:'宁夏',       x:200, y:230, pop:60,  grain:18,  commerce:10,  fort:75, loyalty:50, garrison:9000,  type:'border' },
    { id:'ganSu',       name:'甘肃',       x:160, y:260, pop:120, grain:30,  commerce:20,  fort:60, loyalty:45, garrison:7000,  type:'border' },
    { id:'liaoDong',    name:'辽东',       x:380, y:140, pop:180, grain:45,  commerce:25,  fort:70, loyalty:60, garrison:14000, type:'border' },
    { id:'xuanFu',      name:'宣府',       x:310, y:160, pop:90,  grain:22,  commerce:10,  fort:85, loyalty:65, garrison:11000, type:'border' },
    { id:'daTong',      name:'大同',       x:270, y:160, pop:80,  grain:20,  commerce:10,  fort:80, loyalty:60, garrison:10000, type:'border' },
    { id:'shanXi',      name:'山西',       x:280, y:220, pop:380, grain:90,  commerce:55,  fort:65, loyalty:70, garrison:7000,  type:'mountain' },
    { id:'jiangNan',    name:'江南',       x:340, y:330, pop:900, grain:320, commerce:160, fort:50, loyalty:75, garrison:6000,  type:'rich' },
    { id:'zheJiang',    name:'浙江',       x:380, y:360, pop:520, grain:160, commerce:120, fort:55, loyalty:75, garrison:5000,  type:'coast' },
    { id:'fuJian',      name:'福建',       x:370, y:410, pop:260, grain:80,  commerce:60,  fort:50, loyalty:70, garrison:5000,  type:'coast' },
    { id:'guangDong',   name:'广东',       x:320, y:450, pop:340, grain:90,  commerce:70,  fort:45, loyalty:65, garrison:5000,  type:'coast' },
    { id:'guangXi',     name:'广西',       x:260, y:430, pop:180, grain:50,  commerce:20,  fort:40, loyalty:55, garrison:4000,  type:'mountain' },
    { id:'yunNan',      name:'云南',       x:210, y:410, pop:140, grain:30,  commerce:15,  fort:50, loyalty:45, garrison:8000,  type:'mountain' },
    { id:'guiZhou',     name:'贵州',       x:240, y:380, pop:120, grain:25,  commerce:10,  fort:45, loyalty:50, garrison:4000,  type:'mountain' },
    { id:'siChuan',     name:'四川',       x:220, y:340, pop:420, grain:140, commerce:55,  fort:55, loyalty:65, garrison:6000,  type:'mountain' },
    { id:'huBei',       name:'湖广',       x:300, y:340, pop:480, grain:160, commerce:60,  fort:50, loyalty:70, garrison:5000,  type:'plain' },
    { id:'jiangXi',     name:'江西',       x:320, y:360, pop:380, grain:120, commerce:70,  fort:50, loyalty:75, garrison:4500,  type:'plain' }
];
// 邻接关系（用于行军路径）
const PROVINCE_NEIGHBORS = {
    shunTian:['shanDong','heNan','shanXi','xuanFu'],
    shanDong:['shunTian','heNan','jiangNan','liaoDong'],
    heNan:['shunTian','shanDong','huBei','shanXi','shaanXi'],
    shanXi:['shunTian','heNan','shaanXi','daTong','xuanFu'],
    shanXi:['shunTian','heNan','shaanXi','daTong','xuanFu'],
    xuanFu:['shunTian','shanXi','daTong','liaoDong'],
    daTong:['shanXi','xuanFu','shaanXi','ningXia'],
    ningXia:['daTong','shaanXi','ganSu'],
    ganSu:['ningXia','shaanXi'],
    shaanXi:['heNan','shanXi','daTong','ningXia','ganSu','siChuan','huBei'],
    liaoDong:['xuanFu','shanDong'],
    jiangNan:['shanDong','zheJiang','jiangXi','huBei'],
    zheJiang:['jiangNan','jiangXi','fuJian'],
    fuJian:['zheJiang','guangDong'],
    guangDong:['fuJian','guangXi','yunNan'],
    guangXi:['guangDong','yunNan','guiZhou'],
    yunNan:['guangXi','guiZhou','siChuan'],
    guiZhou:['yunNan','guangXi','siChuan','huBei'],
    siChuan:['shaanXi','huBei','guiZhou','yunNan'],
    huBei:['heNan','shaanXi','jiangNan','jiangXi','guiZhou','siChuan'],
    jiangXi:['jiangNan','zheJiang','huBei','fuJian']
};
// 距离表（行军所需季数）
const MARCH_DAYS = 90; // 1 季 = 90 天
function marchDaysBetween(fromId, toId) {
    if (fromId === toId) return 0;
    // BFS 最短路（按邻接）
    const visited = new Set([fromId]);
    const queue = [[fromId, 0]];
    while (queue.length) {
        const [cur, d] = queue.shift();
        const nbrs = PROVINCE_NEIGHBORS[cur] || [];
        for (const n of nbrs) {
            if (n === toId) return d + 1;
            if (!visited.has(n)) { visited.add(n); queue.push([n, d + 1]); }
        }
    }
    return 5; // 不连通时最远距离
}

// 2) 兵种（10 种）—— 攻击、防御、机动力、维持费(银/月/千兵)、装备
const UNIT_TYPES = {
    infantry:    { name:'步卒',     atk:5,  def:8,  move:1, cost:100, equip:['甲','刀'] },
    pikeman:     { name:'长枪兵',   atk:7,  def:10, move:1, cost:120, equip:['甲','长枪'] },
    swordsman:   { name:'刀牌手',   atk:9,  def:9,  move:1, cost:150, equip:['甲','刀','盾'] },
    archer:      { name:'弓弩手',   atk:8,  def:5,  move:1, cost:120, equip:['弓','甲'] },
    crossbow:    { name:'神机营',   atk:11, def:6,  move:1, cost:200, equip:['弩','甲'] },
    gunner:      { name:'火铳营',   atk:14, def:5,  move:1, cost:280, equip:['火铳','甲'] },
    cavalry:     { name:'骑兵',     atk:10, def:7,  move:2, cost:220, equip:['马','甲'] },
    heavyCav:    { name:'重骑兵',   atk:14, def:10, move:2, cost:350, equip:['重马','甲'] },
    chariot:     { name:'车营',     atk:6,  def:14, move:1, cost:250, equip:['车','甲'] },
    warship:     { name:'水师',     atk:11, def:9,  move:2, cost:300, equip:['舰','炮'] }
};
const UNIT_IDS = Object.keys(UNIT_TYPES);

// 3) 将领池
const GENERAL_GIVEN = ['骥','鹏','虎','豹','彪','雄','烈','勇','英','毅','猛','刚','岳','云','武','扬'];
const GENERAL_STYLE = ['忠','勇','智','严','仁','义','烈','悍'];
function makeGeneral(name, style, ability, faction) {
    return {
        id: 'g_' + Math.random().toString(36).slice(2, 8),
        name, style,
        stats: { attack: ability + Math.floor(Math.random()*15)-5, defense: ability + Math.floor(Math.random()*15)-5, intellect: ability + Math.floor(Math.random()*15)-5 },
        loyalty: 50 + Math.floor(Math.random()*30),
        ability,
        faction,        // 倾向
        commanding: null, // 当前指挥的 army id
        status: 'free'  // free / commanding / wounded / dead
    };
}

// 4) 五军都督府 / 府部体制（12 个府部）
const DEPARTMENTS = [
    { id:'censor',   name:'都察院', desc:'风闻言事，弹劾百官。', function:'反腐+查案', headStat:'民望' },
    { id:'personnel',name:'吏部',   desc:'铨选考核，官员任免。', function:'招贤+任免', headStat:'人才' },
    { id:'revenue',  name:'户部',   desc:'钱粮赋税，赈灾调拨。', function:'税收+赈灾', headStat:'府库' },
    { id:'rites',    name:'礼部',   desc:'朝贡祭祀，科举教化。', function:'外交+教化', headStat:'教化' },
    { id:'war',      name:'兵部',   desc:'调兵遣将，军籍马政。', function:'调兵+军纪', headStat:'军威' },
    { id:'justice',  name:'刑部',   desc:'律法刑狱，缉捕盗匪。', function:'律法+治安', headStat:'治安' },
    { id:'works',    name:'工部',   desc:'营造水利，城池屯田。', function:'建设+水利', headStat:'营缮' },
    { id:'cabinet',  name:'内阁',   desc:'票拟机要，票拟批答。', function:'议政+票拟', headStat:'机要' },
    { id:'grand',    name:'五军都督府', desc:'掌天下军政，行营调卫。', function:'训练+行营', headStat:'兵籍' },
    { id:'silijian', name:'司礼监', desc:'批红传旨，内廷机要。', function:'内廷+情报', headStat:'内廷' },
    { id:'jinyi',    name:'锦衣卫', desc:'北镇抚司，巡查缉捕。', function:'间谍+反间', headStat:'耳目' },
    { id:'east',     name:'东厂',   desc:'内廷侦缉，监视百官。', function:'侦查+刺探', headStat:'罗织' }
];
// 每府部当前官员（首长）—— 玩家任命影响其效率
// 5) 物资 / 市肆商品（10 大类）
const GOODS = [
    { id:'grain',   name:'粮',   unit:'石',   base:1,  vol:0.5,  category:'粮' },
    { id:'salt',    name:'盐',   unit:'引',   base:8,  vol:1,    category:'专' },
    { id:'iron',    name:'铁',   unit:'斤',   base:2,  vol:1,    category:'工' },
    { id:'tea',     name:'茶',   unit:'斤',   base:3,  vol:1,    category:'商' },
    { id:'silk',    name:'丝',   unit:'匹',   base:18, vol:1.2,  category:'商' },
    { id:'horse',   name:'马',   unit:'匹',   base:35, vol:2,    category:'军' },
    { id:'cannon',  name:'火炮', unit:'门',   base:500,vol:5,    category:'军' },
    { id:'porcelain',name:'瓷', unit:'件',   base:12, vol:1,    category:'商' },
    { id:'cotton',  name:'棉布', unit:'匹',   base:4,  vol:1,    category:'工' },
    { id:'paper',   name:'纸',   unit:'刀',   base:2,  vol:0.5,  category:'文' }
];
// 6) 五国 / 势力（敌国 + 朝贡国）— 每国有：坐标、首府、政体、军力、国库、外交、好战度
const NATIONS = [
    { id:'mongolYuan', name:'北元大汗国', color:'#b55', stype:'horde', capital:'哈拉和林', military:28000, treasury:6000, diplomacy:-30, aggression:75,
      gov:{type:'部落联盟', ministers:4, ministersLeft:3, intelPower:40}, provinces:[{name:'漠北',x:200,y:60},{name:'辽北',x:280,y:80}], aiPersona:'aggressive' },
    { id:'oirat',     name:'瓦剌',       color:'#d75', stype:'horde', capital:'别失八里', military:18000, treasury:3000, diplomacy:-15, aggression:55,
      gov:{type:'部落联盟', ministers:4, ministersLeft:4, intelPower:30}, provinces:[{name:'准噶尔',x:100,y:200},{name:'瓦剌故地',x:80,y:160}], aiPersona:'raider' },
    { id:'japan',     name:'日本国',     color:'#5a8', stype:'kingdom', capital:'京都', military:14000, treasury:5000, diplomacy:0, aggression:40,
      gov:{type:'幕府将军', ministers:5, ministersLeft:5, intelPower:50}, provinces:[{name:'本州',x:480,y:280},{name:'九州',x:450,y:330}], aiPersona:'trader' },
    { id:'korea',     name:'朝鲜国',     color:'#5ac', stype:'tributary', capital:'汉城', military:8000, treasury:2500, diplomacy:50, aggression:10,
      gov:{type:'李朝朝廷', ministers:5, ministersLeft:5, intelPower:35}, provinces:[{name:'汉城',x:430,y:230}], aiPersona:'tribute' },
    { id:'annam',     name:'安南国',     color:'#a85', stype:'tributary', capital:'升龙', military:10000, treasury:2000, diplomacy:20, aggression:35,
      gov:{type:'安南朝廷', ministers:4, ministersLeft:3, intelPower:25}, provinces:[{name:'升龙',x:280,y:480}], aiPersona:'restless' }
];
// 7) 间谍行动类型
const SPY_OPS = [
    { id:'recon',   name:'侦察', desc:'探明敌国军力、城防、外交动向。', cost:200, intelDelta:30, dur:1, risk:0.15 },
    { id:'bribe',   name:'策反', desc:'收买敌国官员，降低其忠诚/满意度。', cost:500, intelDelta:15, dur:2, risk:0.30 },
    { id:'sabotage',name:'破坏', desc:'纵火、毒井、断敌补给。', cost:800, intelDelta:20, dur:2, risk:0.45 },
    { id:'assassinate',name:'刺杀', desc:'刺杀敌国将相/首辅。', cost:1500,intelDelta:25, dur:3, risk:0.55 },
    { id:'counter', name:'反间', desc:'识破并反制敌国间谍，提升我方反间能力。', cost:400, intelDelta:35, dur:1, risk:0.20 }
];
// 8) 五大传统政治派系（保留）
const FACTIONS = [
    { id:'civil',    name:'文官集团', satisfaction:60, influence:40, desc:'六部+内阁' },
    { id:'military', name:'武将集团', satisfaction:60, influence:30, desc:'五军都督+九边' },
    { id:'royal',    name:'宗室藩王', satisfaction:50, influence:20, desc:'各地藩王' },
    { id:'eunuch',   name:'宦官集团', satisfaction:50, influence:25, desc:'司礼监' },
    { id:'consort',  name:'外戚集团', satisfaction:55, influence:15, desc:'后妃家族' }
];
// 9) 首辅学派
const SCHOLAR_LIST = ['儒家','法家','兵家','农家','道家','墨家','纵横家','阴阳家','医家'];
const SCHOLAR_CAUTION = {
    '儒家':'以仁德安民为先', '法家':'当以律法立威、赏罚分明', '兵家':'士卒之怒不可轻，整军为先',
    '农家':'以农为本、先安耕织', '道家':'无为而治、顺时应势', '墨家':'以工代赈、器械济民',
    '纵横家':'权衡制衡、远交近攻', '阴阳家':'观象察变、敬天修德', '医家':'救民生、御疾疫'
};
// 10) 奏折（每份含完整选项与数值影响）
const MEMORIAL_TEMPLATES = [
    { type:'灾荒', title:'蝗灾肆虐', desc:'北直隶一带蝗灾泛滥，庄稼尽毁。', advisor:'农家：先保庄稼，再赈灾民。',
      options:[
        {text:'开仓赈灾', effects:{food:-800, treasury:-300, stability:10, civilSat:8, milSat:-2, prestige:2}},
        {text:'征发徭役灭蝗', effects:{food:-200, stability:-5, civilSat:-5, milSat:3, prestige:-3}},
        {text:'置之不理', effects:{stability:-15, civilSat:-10, prestige:-5}}
      ]},
    { type:'灾荒', title:'黄河决口', desc:'开封段黄河决口，淹没数县。', advisor:'法家：征发徭役修堤。',
      options:[
        {text:'拨款修堤', effects:{treasury:-1200, stability:8, civilSat:5, milSat:-2}},
        {text:'征发民夫', effects:{food:-300, stability:-3, civilSat:-8, milSat:2}},
        {text:'顺其自然', effects:{stability:-18, civilSat:-12, food:-500}}
      ]},
    { type:'灾荒', title:'瘟疫爆发', desc:'江南瘟疫流行。', advisor:'医家：广设医馆。',
      options:[
        {text:'派医官救治', effects:{treasury:-800, stability:5, civilSat:6, eunuchSat:3}},
        {text:'隔离疫区', effects:{food:-200, stability:-5, milSat:5, civilSat:-3}},
        {text:'祭祀祈福', effects:{prestige:-2, stability:-3, mandate:3, civilSat:-2}}
      ]},
    { type:'灾荒', title:'陕西大旱', desc:'赤地千里。', advisor:'道家：天灾乃天意。',
      options:[
        {text:'开官仓赈济', effects:{food:-1000, stability:8, civilSat:8, prestige:5}},
        {text:'祈雨祭天', effects:{mandate:5, prestige:3, stability:1}},
        {text:'强制征粮', effects:{food:500, stability:-15, civilSat:-10, milSat:3}}
      ]},
    { type:'灾荒', title:'京师地震', desc:'宫殿受损。', advisor:'阴阳家：上天示警。',
      options:[
        {text:'修缮宫殿', effects:{treasury:-1500, prestige:5, stability:3}},
        {text:'减免赋税', effects:{food:-200, stability:8, civilSat:5, prestige:5}},
        {text:'不理会', effects:{stability:-10, prestige:-5, mandate:-5}}
      ]},
    { type:'军事', title:'鞑靼犯边', desc:'大同府遭鞑靼骑兵劫掠。', advisor:'兵家：立即出兵。',
      options:[
        {text:'出兵迎击', effects:{militaryPower:-500, prestige:8, milSat:10, civilSat:-3, treasury:-1000}},
        {text:'坚壁清野', effects:{food:-300, stability:-3, milSat:-5, prestige:-2}},
        {text:'纳贡求和', effects:{treasury:-1500, prestige:-8, milSat:-8, stability:-2}}
      ]},
    { type:'军事', title:'倭寇劫掠沿海', desc:'倭寇登陆浙江。', advisor:'兵家：调水师围剿。',
      options:[
        {text:'派兵剿倭', effects:{militaryPower:-300, prestige:6, milSat:8, treasury:-800}},
        {text:'加强海禁', effects:{treasury:200, stability:-3, civilSat:-5, eunuchSat:5}},
        {text:'招安海盗', effects:{treasury:-400, stability:2, milSat:-3}}
      ]},
    { type:'军事', title:'土司叛乱', desc:'云南土司反叛。', advisor:'法家：改土归流。',
      options:[
        {text:'出兵平叛', effects:{militaryPower:-600, prestige:5, milSat:8, treasury:-1200}},
        {text:'招抚土司', effects:{prestige:3, stability:2, treasury:-500}},
        {text:'改土归流', effects:{civilSat:5, stability:-5, royalSat:-5, prestige:4}}
      ]},
    { type:'军事', title:'边军缺饷', desc:'九边将士数月未发饷。', advisor:'武将：立刻拨饷。',
      options:[
        {text:'立刻拨饷', effects:{treasury:-1500, milSat:12, stability:5}},
        {text:'拖欠部分', effects:{treasury:-500, milSat:-8, stability:-5}},
        {text:'削减编制', effects:{militaryPower:-1000, treasury:500, milSat:-15, stability:-10}}
      ]},
    { type:'军事', title:'武将争功', desc:'两将争边功，兵部请示。', advisor:'法家：赏罚严明。',
      options:[
        {text:'各赏银千两', effects:{treasury:-1000, milSat:8, civilSat:-3, prestige:2}},
        {text:'各打五十大板', effects:{milSat:-10, stability:3, civilSat:3}},
        {text:'严查军功虚报', effects:{milSat:-5, treasury:300, civilSat:5, prestige:2}}
      ]},
    { type:'政治', title:'举荐贤才', desc:'吏部推荐一名地方官。', advisor:'吏部：此人可堪大用。',
      options:[
        {text:'直接录用', effects:{prestige:3, civilSat:8, eunuchSat:-5}},
        {text:'驳回', effects:{civilSat:-5, prestige:-2}},
        {text:'调查后再定', effects:{treasury:-200, stability:2, civilSat:2, eunuchSat:5}}
      ]},
    { type:'政治', title:'科场舞弊', desc:'会试舞弊丑闻。', advisor:'礼部：严查重典。',
      options:[
        {text:'严查到底', effects:{prestige:5, stability:3, civilSat:-5, eunuchSat:-3}},
        {text:'压下消息', effects:{stability:-5, civilSat:3, eunuchSat:5}},
        {text:'重新考试', effects:{treasury:-300, prestige:4, civilSat:5}}
      ]},
    { type:'政治', title:'官员贪污', desc:'御史弹劾户部侍郎。', advisor:'都察院：抄家问斩。',
      options:[
        {text:'严查抄家', effects:{treasury:800, prestige:3, civilSat:-6, eunuchSat:3}},
        {text:'降级留用', effects:{stability:-3, civilSat:-2, prestige:-2, treasury:300}},
        {text:'睁一只眼闭一只眼', effects:{stability:-8, civilSat:-8, eunuchSat:5}}
      ]},
    { type:'经济', title:'商贾请开海禁', desc:'闽浙大贾联名上书。', advisor:'户部：开则利厚，盗亦随之。',
      options:[
        {text:'局部开海', effects:{treasury:1500, stability:-3, civilSat:5, eunuchSat:-3, prestige:4}},
        {text:'维持海禁', effects:{stability:2, civilSat:-2, treasury:300}},
        {text:'查办领头商人', effects:{treasury:500, civilSat:-10, stability:-2}}
      ]},
    { type:'经济', title:'发现银矿', desc:'云南奏报发现银矿。', advisor:'工部：官营为上。',
      options:[
        {text:'官营开采', effects:{treasury:2000, civilSat:-3, prestige:2}},
        {text:'民营开采征税', effects:{treasury:1000, civilSat:3, prestige:2}},
        {text:'封矿禁采', effects:{stability:2, civilSat:-2, prestige:-1}}
      ]},
    { type:'外交', title:'朝鲜来贡', desc:'朝鲜使臣请册封世子。', advisor:'礼部：当厚往薄来。',
      options:[
        {text:'册封并厚赐', effects:{treasury:-500, prestige:10, civilSat:5}},
        {text:'册封薄赐', effects:{prestige:5, civilSat:2, treasury:-200}},
        {text:'暂缓处理', effects:{stability:-2, prestige:-3}}
      ]},
    { type:'外交', title:'安南内附', desc:'安南权臣请降称臣。', advisor:'兵部：可收为藩属。',
      options:[
        {text:'收为藩属', effects:{prestige:8, treasury:500, stability:-2}},
        {text:'册封而复其国', effects:{prestige:3, treasury:300, stability:2}},
        {text:'拒绝受降', effects:{prestige:-2, civilSat:-2}}
      ]},
    { type:'宗室', title:'藩王请增护卫', desc:'宁王请增护卫三千。', advisor:'兵部：恐有养寇自重。',
      options:[
        {text:'准增护卫', effects:{milSat:2, royalSat:10, treasury:-800}},
        {text:'驳回', effects:{royalSat:-10, milSat:-5, stability:-2}},
        {text:'削减护卫', effects:{royalSat:-15, milSat:-8, stability:-5, prestige:3}}
      ]}
];
// 11) 奇观（保留）
const PROJECTS = [
    { id:'zicheng',    name:'紫禁城',   desc:'扩建宫城，彰显天子威仪。', cost:{treasury:12000}, turns:10, effect:{mandate:20, prestige:30, stability:10} },
    { id:'changcheng', name:'万里长城', desc:'修筑边墙，连九边为一体。', cost:{treasury:9000, food:3000}, turns:15, effect:{militaryPower:3000, prestige:15} },
    { id:'yunhe',      name:'大运河',   desc:'疏通运河，南北漕运通畅。', cost:{treasury:6000}, turns:8,  effect:{treasury:1000, food:800, prestige:8} },
    { id:'dadian',     name:'永乐大典', desc:'敕修群书，汇三千年文脉。', cost:{treasury:4000}, turns:6,  effect:{prestige:20, civilSat:10} },
    { id:'xiaoling',   name:'明孝陵',   desc:'营建皇陵，以安历代先灵。', cost:{treasury:5000}, turns:6,  effect:{mandate:10, royalSat:10} }
];
const PROJECT_NAMES = { zicheng:'紫禁城', changcheng:'万里长城', yunhe:'大运河', dadian:'永乐大典', xiaoling:'明孝陵' };
// 12) 每季政令（必选 1 项）
const POLICY_TEMPLATES = {
    1: [ // 春
        { text:'轻徭薄赋', desc:'减春税赋，休养生息。', effects:{ food:400, stability:4, civilSat:5 } },
        { text:'重农兴桑', desc:'劝课农桑，广植桑麻。', effects:{ food:500, prestige:2 } },
        { text:'兴办春闱', desc:'加开科第，广纳贤才。', effects:{ civilSat:6, prestige:4, treasury:-300 } }
    ],
    2: [ // 夏
        { text:'大举操练', desc:'点校兵马，张军威。', effects:{ militaryPower:400, milSat:5, treasury:-400 } },
        { text:'疏浚水利', desc:'以工代赈，修渠固堤。', effects:{ food:300, stability:3, treasury:-300 } },
        { text:'减免杂费', desc:'罢不急之务，宽民力。', effects:{ stability:4, civilSat:4, prestige:2 } }
    ],
    3: [ // 秋
        { text:'加征国赋', desc:'增平米税，充国用。', effects:{ treasury:1500, stability:-6, civilSat:-6 } },
        { text:'均平秋税', desc:'量入为出，宽严得宜。', effects:{ treasury:800 } },
        { text:'开仓平粜', desc:'柴粮抑价，济饥民。', effects:{ stability:5, civilSat:5, food:-300 } }
    ],
    4: [ // 冬
        { text:'祭祀天地', desc:'郊天祀地，祈国祚永昌。', effects:{ mandate:6, prestige:4, treasury:-500 } },
        { text:'编纂国史', desc:'命史官修实录，以彰功业。', effects:{ prestige:5, civilSat:3, treasury:-300 } },
        { text:'冬犒三军', desc:'颁赏九边，稳军心。', effects:{ milSat:6, militaryPower:200, treasury:-600 } }
    ]
};
// 13) 皇储 / 后宫
const PRINCE_GIVEN = ['允','瞻','祈','祐','溥','祁','见','永','翊','常'];
const PRINCE_CHAR  = ['仁','暴','庸','明','睿','悍','和','惰'];
// 14) 隐患池（处理失当追加）
const HAZARD_POOL = [
    { title:'灾民流徙', desc:'流民聚于畿辅，恐生民变。', advisor:'农家：当开粥棚。',
      options:[
        {text:'设粥厂', effects:{treasury:-500, food:-400, stability:6, civilSat:6}},
        {text:'遣送还乡', effects:{food:-200, stability:2, civilSat:3, prestige:2}},
        {text:'驱其出境', effects:{stability:-10, milSat:3, prestige:-5}}
      ]},
    { title:'瘟疫复发', desc:'江南多城复有疫讯。', advisor:'医家：当再遣医官。',
      options:[
        {text:'再遣医官', effects:{treasury:-600, stability:5, civilSat:5}},
        {text:'封锁疫城', effects:{food:-300, milSat:4, stability:-4}},
        {text:'迁民意避', effects:{food:-500, stability:3, civilSat:3}}
      ]},
    { title:'边军鼓噪', desc:'九边军士聚众鼓噪。', advisor:'兵部：当速发饷银。',
      options:[
        {text:'补发饷银', effects:{treasury:-1000, milSat:10, stability:4}},
        {text:'严惩为首', effects:{milSat:-8, stability:-6, prestige:3}},
        {text:'调镇他处', effects:{treasury:-400, milSat:-3, militaryPower:-300}}
      ]}
];
// 15) 季节基础收入
const SEASONAL_INCOME = {
    1: { food:200, desc:'春耕，粮储略增。' },
    2: { militaryPower:100, desc:'夏操兵马。' },
    3: { treasury:800, food:400, desc:'秋收，税粮并入。' },
    4: { prestige:3, mandate:2, desc:'冬祭，威望与天命稍增。' }
};
// 16) 派系行为触发
const FACTION_EVENTS = {
    civil:    { lowSat:{name:'文官怠政', desc:'六部推诿，政事积压。', effects:{stability:-4, treasury:-200}},
                highInf:{name:'文官结党', desc:'内阁票拟专擅，皇权旁落。', effects:{mandate:-3, stability:-2}} },
    military: { lowSat:{name:'武将离心', desc:'九边将帅心怀怨望。', effects:{stability:-5, militaryPower:-300}},
                highInf:{name:'武将跋扈', desc:'武将恃功傲上。', effects:{mandate:-2, stability:-3}} },
    royal:    { lowSat:{name:'宗室怨望', desc:'藩王心怀怨望。', effects:{stability:-3, prestige:-2}},
                highInf:{name:'宗室擅权', desc:'藩王逾制。', effects:{stability:-4, treasury:-300}} },
    eunuch:   { lowSat:{name:'阉宦懈怠', desc:'内廷机要迟滞。', effects:{stability:-2, eunuchSat:5}},
                highInf:{name:'宦官专权', desc:'司礼监擅权乱政。', effects:{mandate:-4, stability:-2}} },
    consort:  { lowSat:{name:'外戚寒心', desc:'后妃家族离心。', effects:{stability:-2, prestige:-1}},
                highInf:{name:'外戚干政', desc:'外戚与宦官争权。', effects:{mandate:-2, stability:-3, treasury:-300}} }
};
// 17) 失败阈值
const FAIL_THRESHOLDS = {
    mandate0:        { type:'mandate_end', desc:'天命耗尽，天下倾覆。' },
    stability0:      { type:'stability_end', desc:'民怨沸腾，国本动摇。' },
    peasantRevolt:   { type:'peasant_end', desc:'粮尽而民变。' },
    eunuchOver90:    { type:'eunuch_coup', desc:'宦官废立，大宝移于阉竖。' },
    consortOver90:   { type:'consort_coup', desc:'外戚篡权，社稷易主。' }
};
// 18) 胜利条件
const VICTORY_CONDITIONS = {
    yongleProsperity: { name:'永乐盛世', desc:'连续10年稳定>80 威望>80 天命>80' },
    allComeToCourt:   { name:'万国来朝', desc:'外交均>50 且与四邻无战事' },
    driveOutTartar:   { name:'驱逐鞑虏', desc:'灭亡北元/瓦剌任何一国' },
    revival:          { name:'中兴之主', desc:'从稳定<30恢复到稳定>70，持续5年' }
};
// 19) 府部官员
function blankDeptHead() { return { name:'空缺', ability:30, loyalty:50, faction:'civil' }; }
const ACCOUNT_ENDING_NAMES = {
    victory: '盛世/中兴',
    mandate_end:'天命已尽', stability_end:'国本动摇', peasant_end:'农民起义',
    eunuch_coup:'宦官废立', consort_coup:'外戚篡权'
};
// 20) AI 敌国性格
const AI_BEHAVIORS = {
    aggressive: { tickProb:0.9, attackProb:0.35, tributeProb:0.0, tradeProb:0.05 },
    raider:     { tickProb:0.7, attackProb:0.20, tributeProb:0.0, tradeProb:0.10 },
    trader:     { tickProb:0.5, attackProb:0.05, tributeProb:0.10,tradeProb:0.55 },
    tribute:    { tickProb:0.4, attackProb:0.02, tributeProb:0.70,tradeProb:0.30 },
    restless:   { tickProb:0.6, attackProb:0.10, tributeProb:0.20,tradeProb:0.30 }
};
