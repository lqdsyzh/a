// ====================================================================
// 《大明国策 v2》核心引擎
// 账号/状态/资源/战斗/行军/AI 敌国/间谍/朝政
// ====================================================================

// ====== 账号（本地多账号） ======
const ACCOUNTS_KEY = 'daming_accounts_v2';
const CURRENT_KEY  = 'daming_current_v2';
function getAccountDB() { try { return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || '{}'); } catch (e) { return {}; } }
function getCurrentUser() { return localStorage.getItem(CURRENT_KEY) || null; }
function getSaveKey(u) { return 'daming_save_v2_' + (u || 'guest'); }
function registerAccount(user, pass) {
    user = (user || '').trim();
    if (!/^[A-Za-z0-9_\u4e00-\u9fa5]{2,16}$/.test(user)) return { ok:false, msg:'用户名需2-16位中文/字母/数字/下划线' };
    if (!pass || pass.length < 4) return { ok:false, msg:'密码至少4位' };
    const db = getAccountDB();
    if (db[user]) return { ok:false, msg:'该用户已存在' };
    db[user] = { password: pass, created: Date.now(), endings: [], games: 0, yearsPlayed: 0 };
    try { localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(db)); } catch(e){ return {ok:false,msg:'存储失败'}; }
    loginAccount(user, pass);
    return { ok:true, msg:'注册成功' };
}
function loginAccount(user, pass) {
    const db = getAccountDB();
    if (!db[user]) return { ok:false, msg:'用户不存在' };
    if (db[user].password !== pass) return { ok:false, msg:'密码错误' };
    try { localStorage.setItem(CURRENT_KEY, user); } catch(e){}
    return { ok:true, msg:'登录成功' };
}
function logoutAccount() { try { localStorage.removeItem(CURRENT_KEY); } catch(e){} }
function saveGame() {
    const u = getCurrentUser(); if (!u) return false;
    try { localStorage.setItem(getSaveKey(u), JSON.stringify(state)); return true; } catch(e) { return false; }
}
function loadGame() {
    const u = getCurrentUser(); if (!u) return false;
    try { const data = localStorage.getItem(getSaveKey(u)); if (!data) return false; Object.assign(state, JSON.parse(data)); return true; } catch(e) { return false; }
}
function recordEnding(endingType) {
    const u = getCurrentUser(); if (!u) return;
    const db = getAccountDB(); if (!db[u]) return;
    db[u].endings = db[u].endings || [];
    db[u].endings.push({ type: endingType, name: ACCOUNT_ENDING_NAMES[endingType] || endingType, year: state.year, date: Date.now() });
    db[u].games = (db[u].games || 0) + 1;
    db[u].yearsPlayed = (db[u].yearsPlayed || 0) + state.year;
    try { localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(db)); } catch(e){}
}

// ====== 全局状态 ======
const state = {
    year: 1, season: 1,
    treasury: 10000, food: 5000, stability: 60, prestige: 50,
    militaryPower: 8000, mandate: 70,
    factions: JSON.parse(JSON.stringify(FACTIONS)),
    currentMemorials: [],
    log: [],
    gameOver: false, victory: null,
    prosperityYears: 0, revivalYears: 0, wasLowStability: false,
    scholar: '儒家',
    policyChosen: false, chosenPolicy: null,
    projects: [], doneProjects: [],
    princes: [], heir: null,
    hazards: [],
    // —— v2 新增 ——
    generals: [],            // 我方将领池
    armies: [],              // 我方军团（带将领、兵种、状态）
    drafts: [],              // 训练中的新兵
    provinces: JSON.parse(JSON.stringify(PROVINCES)), // 复制以挂载运行时属性
    provinceGarrisonExtra: {}, // 每省增派
    nations: JSON.parse(JSON.stringify(NATIONS)),  // 复制
    spyMissions: [],         // 我方派遣的间谍任务
    myIntel: 50,             // 我方情报值
    deptHeads: {},           // 府部官员（id -> {name, ability, loyalty, faction}）
    goodsPrices: {},         // 市肆当前价
    market: { grain: 0, salt: 0, iron: 0, tea: 0, silk: 0, horse: 0, cannon: 0, porcelain: 0, cotton: 0, paper: 0 }, // 玩家库存
    diplomacy: {},           // 国家id -> 外交值
    currentWars: {},         // 国家id -> 战事计数
    battleLog: [],           // 近期战斗
    mapView: { x: 0, y: 0, scale: 1 }  // 地图视图
};

// ====== 工具函数 ======
function log(message, level) {
    state.log.unshift({ year: state.year, season: SEASONS[state.season - 1], text: message, level: level || 'info' });
    if (state.log.length > 120) state.log.pop();
    if (typeof renderLog === 'function') renderLog();
}
function getFaction(id) { return state.factions.find(f => f.id === id); }
function updateFaction(id, sat, inf) {
    const f = getFaction(id); if (!f) return;
    if (sat) f.satisfaction = Math.max(0, Math.min(100, f.satisfaction + sat));
    if (inf) f.influence    = Math.max(5, Math.min(100, f.influence + inf));
}
function applyEffects(e) {
    if (!e) return;
    if (e.treasury)      state.treasury      = Math.max(0, state.treasury + e.treasury);
    if (e.food)         state.food          = state.food + e.food;
    if (e.stability)    state.stability     = Math.max(0, Math.min(100, state.stability + e.stability));
    if (e.prestige)     state.prestige      = Math.max(0, Math.min(100, state.prestige + e.prestige));
    if (e.militaryPower) state.militaryPower = Math.max(0, state.militaryPower + e.militaryPower);
    if (e.mandate)      state.mandate       = Math.max(0, Math.min(100, state.mandate + e.mandate));
    if (e.civilSat)     updateFaction('civil', e.civilSat, 0);
    if (e.milSat)       updateFaction('military', e.milSat, 0);
    if (e.royalSat)     updateFaction('royal', e.royalSat, 0);
    if (e.eunuchSat)    updateFaction('eunuch', e.eunuchSat, 0);
    if (e.consortSat)   updateFaction('consort', e.consortSat, 0);
}

// ====== 奏折 / 政令 / 朝议 ======
function generateMemorials() {
    const baseCount = state.season === 4 ? 1 + Math.floor(Math.random() * 2) : 2 + Math.floor(Math.random() * 2);
    let count = baseCount;
    const list = [];
    if (state.hazards.length > 0 && count > 0) {
        const h = state.hazards[0];
        list.push({ id: 0, ...h, title: h.title + '（隐患）' });
        state.hazards.shift();
        count--;
    }
    const recent = state._recentMemorials || [];
    const pool = MEMORIAL_TEMPLATES.filter(t => !recent.includes(t.title));
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    const chosen = shuffled.slice(0, Math.min(count, pool.length));
    state._recentMemorials = recent.concat(chosen.map(c => c.title)).slice(-6);
    chosen.forEach((tpl, i) => list.push({ id: list.length + i, ...tpl }));
    state.currentMemorials = list;
    return list;
}
function maybeAccumulateHazard(opt) {
    const e = opt.effects || {};
    const bad = (e.stability <= -10) || (e.food !== undefined && e.food <= -800) || (e.treasury !== undefined && e.treasury <= -1200);
    if (!bad) return;
    const open = HAZARD_POOL.filter(h => !state.hazards.includes(h.title) && !state.currentMemorials.some(m => m.title.indexOf(h.title) === 0));
    if (open.length > 0) { const h = open[Math.floor(Math.random() * open.length)]; state.hazards.push(h.title); log(`朝局隐忧：${h.desc}`, 'warn'); }
}
function handleMemorialChoice(memorialId, optionIndex) {
    const m = state.currentMemorials.find(x => x.id === memorialId);
    if (!m) return;
    const opt = m.options[optionIndex]; if (!opt) return;
    applyEffects(opt.effects);
    maybeAccumulateHazard(opt);
    log(`批复「${m.title}」：${opt.text}`);
    state.currentMemorials = state.currentMemorials.filter(x => x.id !== memorialId);
    if (typeof renderMemorialList === 'function') renderMemorialList();
    if (state.currentMemorials.length === 0) { closeMemorialModal(); completeSeason(); }
}
function choosePolicy(idx) {
    const list = POLICY_TEMPLATES[state.season]; if (!list || !list[idx]) return;
    const p = list[idx];
    if ((p.effects.treasury || 0) < 0 && state.treasury + (p.effects.treasury || 0) < 0) return;
    applyEffects(p.effects);
    state.chosenPolicy = p.text;
    state.policyChosen = true;
    log(`颁行政策：${p.text}（${p.desc}）`);
    if (typeof renderPolicyPanel === 'function') renderPolicyPanel();
}
function handleProject(idx, mode) {
    const p = PROJECTS[idx]; if (!p) return;
    if (mode === 'start') {
        if (state.projects.some(x => x.id === p.id)) return;
        if (state.doneProjects.includes(p.id)) return;
        if (state.treasury < p.cost.treasury) { log(`国库不足，无法启动「${p.name}」。`, 'warn'); return; }
        if (p.cost.food && state.food < p.cost.food) { log(`粮食不足，无法启动「${p.name}」。`, 'warn'); return; }
        state.treasury -= p.cost.treasury;
        if (p.cost.food) state.food -= p.cost.food;
        state.projects.push({ id: p.id, progress: 0, turns: p.turns });
        log(`大兴土木：启动「${p.name}」（需${p.turns}季）。`);
    } else if (mode === 'advance') {
        const pr = state.projects.find(x => x.id === p.id); if (!pr) return;
        pr.progress++;
        log(`「${p.name}」施工推进（${pr.progress}/${pr.turns}）。`);
        if (pr.progress >= pr.turns) {
            state.projects = state.projects.filter(x => x.id !== p.id);
            state.doneProjects.push(p.id);
            applyEffects(p.effect);
            log(`「${p.name}」落成！`, 'good');
        }
    }
    if (typeof renderProjectsPanel === 'function') renderProjectsPanel();
}
function startCourt() {
    if (state.gameOver) return;
    if (!state.policyChosen) { openPolicyPanel(); return; }
    if (state.currentMemorials.length > 0) { document.getElementById('memorialModal').classList.remove('hide'); renderMemorialList(); return; }
    generateMemorials();
    renderMemorialList();
    document.getElementById('memorialModal').classList.remove('hide');
    document.getElementById('btnYear').disabled = true;
    if (typeof renderPolicyAck === 'function') renderPolicyAck();
}
function closeMemorialModal() { const m = document.getElementById('memorialModal'); if (m) m.classList.add('hide'); }

// ====== 季节推进 / 结算 ======
function completeSeason() {
    const inc = SEASONAL_INCOME[state.season];
    if (inc) {
        if (inc.food) state.food += inc.food;
        if (inc.militaryPower) state.militaryPower += inc.militaryPower;
        if (inc.treasury) state.treasury += inc.treasury;
        if (inc.prestige) state.prestige = Math.min(100, state.prestige + inc.prestige);
        if (inc.mandate) state.mandate = Math.min(100, state.mandate + inc.mandate);
        log(`${SEASONS[state.season - 1]}季结算：${inc.desc}`);
    }
    // 训练中的部队按季推进
    state.drafts = state.drafts.filter(d => { d.daysLeft -= 90; if (d.daysLeft <= 0) {
        const a = { id:'army_' + Date.now() + '_' + Math.floor(Math.random()*1000), name:d.name, unitType:d.unitType, count:d.count, general:null, morale:70, training:60, origin:null, status:'ready' };
        state.armies.push(a);
        state.militaryPower += d.count;
        log(`新军「${d.name}」成军，编入京师。`);
        return false;
    } return true; });
    // 推进所有行军中军团
    tickMarches();
    // 推进所有间谍任务
    tickSpies();
    // 推进奇观（每季可推 1）
    // AI 行为 tick
    tickAI();
    // 维护费：每千兵 3 银/季
    const upkeep = Math.ceil(state.militaryPower / 1000) * 3;
    state.treasury = Math.max(0, state.treasury - upkeep);
    log(`军费：支出 ${upkeep} 银（按兵数）。`);

    state.season++;
    if (state.season > 4) { annualSettlement(); state.season = 1; state.year++; }
    state.policyChosen = false; state.chosenPolicy = null;
    checkFactionThresholds();
    checkVictoryDefeat();
    refreshAfterTick();
    if (state.gameOver) { if (typeof showGameOver === 'function') showGameOver(); return; }
    const sn = SEASONS[state.season - 1];
    const status = document.getElementById('courtStatus');
    const btn = document.getElementById('btnYear');
    if (status) status.innerHTML = `已进入${sn}季，点击「开启${sn}季朝议」先颁政令，再处奏折。`;
    if (btn) { btn.textContent = `开启${sn}季朝议`; btn.disabled = false; }
}
function refreshAfterTick() {
    ['updateTopBar','renderFactionPanel','renderOverview','renderFactionAlert','renderProjectsPanel','renderPrincesPanel','renderPolicyPanel','renderDiplomacyPanel','renderArmiesPanel','renderMarketPanel','renderSpyPanel','renderDeptsPanel'].forEach(fn => { try { if (typeof window[fn] === 'function') window[fn](); } catch(e){} });
    if (typeof renderLog === 'function') renderLog();
    if (typeof switchTab === 'function') switchTab('court');
}
function annualSettlement() {
    state.treasury += 500; state.food += 300;
    if (Math.random() < 0.3) { state.food += 200; log('今年风调雨顺，粮食丰收。', 'good'); }
    updateFaction('civil', 1, 1);
    updateFaction('military', -1, 0);
    updateFaction('eunuch', 1, 1);
    agePrinces();
    state.scholar = SCHOLAR_LIST[Math.floor(Math.random() * SCHOLAR_LIST.length)];
    log(`永乐${state.year}年年度结算。今岁由【${state.scholar}】学派执掌朝柄。`);
    checkPrinceBirth();
    // 敌国每年外交自然恢复
    state.nations.forEach(n => { state.diplomacy[n.id] = (state.diplomacy[n.id] || 0); state.diplomacy[n.id] = Math.min(100, state.diplomacy[n.id] + 3); });
}

// ====== 皇储 ======
function checkPrinceBirth() {
    if (state.princes.length === 0) { ensureFirstPrince(); return; }
    if (Math.random() < 0.4) {
        const g = PRINCE_GIVEN[Math.floor(Math.random() * PRINCE_GIVEN.length)];
        const c = PRINCE_CHAR[Math.floor(Math.random() * PRINCE_CHAR.length)];
        const ab = 30 + Math.floor(Math.random() * 70);
        state.princes.push({ name: '朱' + g, char: c, ability: ab, age: 1, crown: false });
        log(`后宫喜讯：皇子「朱${g}」诞生。`);
    }
}
function ensureFirstPrince() {
    if (state.princes.length > 0) return;
    const g = PRINCE_GIVEN[Math.floor(Math.random() * PRINCE_GIVEN.length)];
    const c = PRINCE_CHAR[Math.floor(Math.random() * PRINCE_CHAR.length)];
    const ab = 40 + Math.floor(Math.random() * 55);
    state.princes.push({ name: '朱' + g, char: c, ability: ab, age: 1, crown: false });
}
function agePrinces() { state.princes.forEach(p => p.age++); }
function setHeir(idx) {
    if (!state.princes[idx]) return;
    const old = state.princes.findIndex(p => p.crown);
    if (old >= 0) state.princes[old].crown = false;
    state.princes[idx].crown = true;
    state.heir = idx;
    const p = state.princes[idx];
    if (p.ability >= 65) { state.prestige = Math.min(100, state.prestige + 5); log(`立贤储君「${p.name}」声望更隆。`, 'good'); }
    else { state.stability = Math.min(100, state.stability + 3); log(`循例立长「${p.name}」，朝局稳固。`); }
    const others = state.princes.filter((_, i) => i !== idx);
    if (others.length > 0) { updateFaction('royal', -3, 0); log('未被立储的皇子心怀不满，宗室微恙。', 'warn'); }
}
function enfeoffPrince(idx) {
    if (!state.princes[idx]) return;
    const p = state.princes[idx];
    updateFaction('royal', 2, 3);
    log(`皇子「${p.name}」就藩之国，宗室拱卫愈固。`);
    if (p.crown) { state.princes[idx].crown = false; state.heir = null; }
}

// ====== 派系 / 胜负 ======
function checkFactionThresholds() {
    state.factions.forEach(f => {
        if (f.satisfaction < 20 && FACTION_EVENTS[f.id] && FACTION_EVENTS[f.id].lowSat) {
            const ev = FACTION_EVENTS[f.id].lowSat;
            if (f.id === 'military' && Math.random() < 0.5) {
                applyEffects({ militaryPower: -500, stability: -5 });
                log(`【兵变】${f.name}军心崩溃，部分兵将哗变劫掠州县！`, 'danger');
            } else { log(`【${ev.name}】${ev.desc}`, 'warn'); applyEffects(ev.effects); }
            f.satisfaction = 25;
        }
        if (f.influence > 80 && FACTION_EVENTS[f.id] && FACTION_EVENTS[f.id].highInf) {
            const ev = FACTION_EVENTS[f.id].highInf;
            log(`【${ev.name}】${ev.desc}`, 'warn'); applyEffects(ev.effects);
            f.influence = 75;
        }
        if ((f.id === 'eunuch' || f.id === 'consort') && f.influence > 90) {
            const fail = f.id === 'eunuch' ? FAIL_THRESHOLDS.eunuchOver90 : FAIL_THRESHOLDS.consortOver90;
            triggerGameOver(fail.type, fail.desc);
        }
    });
}
function checkVictoryDefeat() {
    if (state.mandate <= 0) { triggerGameOver('mandate_end', FAIL_THRESHOLDS.mandate0.desc); return; }
    if (state.stability <= 0) { triggerGameOver('stability_end', FAIL_THRESHOLDS.stability0.desc); return; }
    if (state.food < 0 && state.stability < 20) { triggerGameOver('peasant_end', FAIL_THRESHOLDS.peasantRevolt.desc); return; }
    if (state.stability > 80 && state.prestige > 80 && state.mandate > 80) {
        state.prosperityYears++;
        if (state.prosperityYears >= 10) { triggerVictory('yongleProsperity', VICTORY_CONDITIONS.yongleProsperity.name); return; }
    } else state.prosperityYears = 0;
    if (state.stability < 30) state.wasLowStability = true;
    if (state.wasLowStability && state.stability > 70) {
        state.revivalYears++;
        if (state.revivalYears >= 5) triggerVictory('revival', VICTORY_CONDITIONS.revival.name);
    } else if (state.stability <= 70) state.revivalYears = 0;
    // 万国来朝：所有邻国/朝贡国外交>50 且无战事
    const allGood = state.nations.every(n => (state.diplomacy[n.id] || 0) > 50 && !state.currentWars[n.id]);
    if (allGood) triggerVictory('allComeToCourt', VICTORY_CONDITIONS.allComeToCourt.name);
}
function triggerGameOver(failType, desc) {
    if (state.gameOver) return;
    state.gameOver = true; state.victory = false;
    log(`【亡国】${desc}`, 'danger');
    recordEnding(failType); saveGame();
}
function triggerVictory(winId, name) {
    if (state.gameOver) return;
    state.gameOver = true; state.victory = true;
    log(`【盛世】${name} —— 大明万年！`, 'good');
    recordEnding('victory'); saveGame();
}

// ====== 府部 ======
function initDeptHeads() {
    if (Object.keys(state.deptHeads).length > 0) return;
    DEPARTMENTS.forEach(d => state.deptHeads[d.id] = blankDeptHead());
    // 随机给 4 个府部配上人
    const sample = [...DEPARTMENTS].sort(() => Math.random() - 0.5).slice(0, 4);
    sample.forEach(d => state.deptHeads[d.id] = { name: ['王守仁','严嵩','于谦','张居正','李景隆','胡宗宪','戚继光','杨荣','徐阶','王振'][Math.floor(Math.random()*10)], ability: 40 + Math.floor(Math.random()*50), loyalty: 50 + Math.floor(Math.random()*30), faction: ['civil','military','eunuch','consort'][Math.floor(Math.random()*4)] });
}
function appointHead(deptId, name) {
    if (!state.deptHeads[deptId]) return;
    const ab = 30 + Math.floor(Math.random() * 60);
    const loy = 50 + Math.floor(Math.random() * 30);
    state.deptHeads[deptId] = { name: name || state.deptHeads[deptId].name, ability: ab, loyalty: loy, faction: 'civil' };
    log(`任命${DEPARTMENTS.find(d=>d.id===deptId).name}主官：${state.deptHeads[deptId].name}。`);
}

// ====== 将领 / 部队 / 行军 / 战斗 ======
function recruitGeneral() {
    const given = GENERAL_GIVEN[Math.floor(Math.random() * GENERAL_GIVEN.length)];
    const style = GENERAL_STYLE[Math.floor(Math.random() * GENERAL_STYLE.length)];
    const ab = 30 + Math.floor(Math.random() * 60);
    const fac = ['civil','military','eunuch'][Math.floor(Math.random()*3)];
    const g = makeGeneral('朱' + given, style, ab, fac);
    state.generals.push(g);
    log(`新将投效：「${g.name}」${g.style}（能${g.ability}）。`, 'good');
}
function ensureGenerals() {
    if (state.generals.length >= 4) return;
    while (state.generals.length < 4) recruitGeneral();
}
function raiseArmy(unitType, count) {
    const ut = UNIT_TYPES[unitType]; if (!ut) return null;
    count = Math.max(100, count);
    const cost = Math.ceil(count / 1000) * ut.cost * 5; // 训练期一次性成本
    if (state.treasury < cost) { log(`国库不足，无法建军。`, 'warn'); return null; }
    state.treasury -= cost;
    const name = ut.name + '营' + (state.armies.length + state.drafts.length + 1);
    const days = 180; // 半年训练
    state.drafts.push({ name, unitType, count, daysLeft: days });
    log(`新募${name} ${count}人，征训中。`);
    return true;
}
function assignGeneralToArmy(armyId, generalId) {
    const a = state.armies.find(x => x.id === armyId); if (!a) return;
    const g = state.generals.find(x => x.id === generalId); if (!g) return;
    if (a.general) { a.general.commanding = null; a.general.status = 'free'; }
    a.general = g; g.commanding = armyId; g.status = 'commanding';
}
function unassignGeneral(armyId) {
    const a = state.armies.find(x => x.id === armyId); if (!a || !a.general) return;
    a.general.commanding = null; a.general.status = 'free'; a.general = null;
}
function moveArmy(armyId, targetProvinceId) {
    const a = state.armies.find(x => x.id === armyId); if (!a || a.status !== 'ready') return;
    if (!a.origin) a.origin = 'shunTian';
    const days = marchDaysBetween(a.origin, targetProvinceId) * 30;
    a.status = 'marching';
    a.march = { from: a.origin, to: targetProvinceId, daysLeft: days, total: days };
    state.militaryPower -= a.count; // 离开京师
    log(`「${a.name}」自${nameOfProvince(a.origin)}出发，奔袭${nameOfProvince(targetProvinceId)}（${days}日）。`);
}
function nameOfProvince(id) {
    const p = state.provinces.find(x => x.id === id); return p ? p.name : id;
}
function tickMarches() {
    state.armies.forEach(a => {
        if (a.status !== 'marching' || !a.march) return;
        a.march.daysLeft -= 90;
        if (a.march.daysLeft <= 0) {
            a.origin = a.march.to;
            a.status = 'ready';
            a.march = null;
            state.militaryPower += a.count; // 到达
            log(`「${a.name}」抵达${nameOfProvince(a.origin)}。`);
        }
    });
}
// 战斗公式
function computePower(army) {
    const ut = UNIT_TYPES[army.unitType];
    const gen = army.general;
    const atkBase = army.count * (ut.atk / 10) * (army.training / 100) * (army.morale / 100);
    const defBase = army.count * (ut.def / 10) * (army.training / 100) * (army.morale / 100);
    const atk = atkBase * (gen ? (1 + gen.stats.attack / 200) : 1);
    const def = defBase * (gen ? (1 + gen.stats.defense / 200) : 1);
    return { atk, def };
}
// 玩家对敌国某省发动进攻
function attackProvince(nationId, provinceIdx, armyIds) {
    const nation = state.nations.find(n => n.id === nationId); if (!nation) return;
    const target = nation.provinces[provinceIdx]; if (!target) return;
    const myArmies = armyIds.map(id => state.armies.find(a => a.id === id)).filter(Boolean);
    if (myArmies.length === 0) return;
    // 聚合
    const myCount = myArmies.reduce((s, a) => s + a.count, 0);
    const myAtk = myArmies.reduce((s, a) => s + computePower(a).atk, 0);
    const myDef = myArmies.reduce((s, a) => s + computePower(a).def, 0);
    // 守军（敌国总军力按 AI persona 比例分配到该省）
    const guard = Math.round(nation.military * 0.3);
    const enemyAtk = guard * 0.8; // 守城
    const enemyDef = guard * 1.5;
    // 战损
    const myLoss = Math.round(myCount * Math.min(0.5, (enemyAtk / (myAtk + enemyDef || 1))));
    const enLoss = Math.round(guard * Math.min(0.7, (myAtk / (myAtk + enemyDef || 1))));
    // 分配
    let remainLoss = myLoss;
    myArmies.forEach(a => { const l = Math.floor(a.count / myCount * myLoss); a.count = Math.max(0, a.count - l); a.morale = Math.max(20, a.morale - 15); });
    state.militaryPower = Math.max(0, state.militaryPower - myLoss);
    nation.military = Math.max(0, nation.military - enLoss);
    state.diplomacy[nationId] = (state.diplomacy[nationId] || 0) - 20;
    state.currentWars[nationId] = (state.currentWars[nationId] || 0) + 1;
    state.battleLog.unshift({ year: state.year, season: SEASONS[state.season-1], target: target.name, myLoss, enLoss });
    if (state.battleLog.length > 30) state.battleLog.pop();
    log(`【攻伐】攻${target.name}：歼敌${enLoss}，我军伤亡${myLoss}。`, 'warn');
    // 胜负判定
    if (enLoss >= guard * 0.5) {
        // 占领
        nation.provinces.splice(provinceIdx, 1);
        log(`我军攻克「${target.name}」！`, 'good');
        // 灭国判定
        if (nation.provinces.length === 0) { log(`【灭国】${nation.name}既亡！`, 'good'); nation.military = 0; state.diplomacy[nationId] = -100; triggerVictory('driveOutTartar', `灭${nation.name}：${VICTORY_CONDITIONS.driveOutTartar.name}`); }
    }
    // 溃败
    myArmies.forEach(a => { if (a.count === 0) { a.status = 'dead'; a.general && (a.general.status = 'wounded'); }});
    state.armies = state.armies.filter(a => a.status !== 'dead');
}

// ====== 间谍 ======
function dispatchSpy(nationId, opId) {
    const op = SPY_OPS.find(o => o.id === opId); if (!op) return;
    const cost = op.cost;
    if (state.treasury < cost) { log(`国库不足，无法派遣。`, 'warn'); return; }
    const nation = state.nations.find(n => n.id === nationId); if (!nation) return;
    state.treasury -= cost;
    const mission = { id:'m_'+Date.now()+'_'+Math.floor(Math.random()*1000), nationId, opId, daysLeft: op.dur * 90, total: op.dur * 90, success: null };
    state.spyMissions.push(mission);
    state.diplomacy[nationId] = (state.diplomacy[nationId] || 0) - (op.id === 'assassinate' ? 10 : 5);
    log(`已派遣【${op.name}】至${nation.name}，预计${op.dur}季完成。`);
}
function tickSpies() {
    const remain = [];
    state.spyMissions.forEach(m => {
        m.daysLeft -= 90;
        if (m.daysLeft <= 0) {
            const op = SPY_OPS.find(o => o.id === m.opId);
            const nation = state.nations.find(n => n.id === m.nationId);
            const success = Math.random() < (1 - op.risk + (state.myIntel - nation.gov.intelPower) / 200);
            if (success) {
                log(`【谍报】对${nation.name}的「${op.name}」成功！`, 'good');
                if (m.opId === 'recon') state.myIntel = Math.min(100, state.myIntel + 8);
                if (m.opId === 'bribe') nation.gov.ministersLeft = Math.max(1, nation.gov.ministersLeft - 1);
                if (m.opId === 'sabotage') nation.military = Math.max(0, nation.military - 500);
                if (m.opId === 'assassinate') { nation.gov.ministersLeft = Math.max(0, nation.gov.ministersLeft - 2); nation.aggression = Math.max(0, nation.aggression - 10); }
                if (m.opId === 'counter') { state.myIntel = Math.min(100, state.myIntel + 12); nation.gov.intelPower = Math.max(10, nation.gov.intelPower - 5); }
            } else {
                log(`【谍报】对${nation.name}的「${op.name}」失败，线人折损。`, 'warn');
                state.myIntel = Math.max(0, state.myIntel - 5);
            }
        } else remain.push(m);
    });
    state.spyMissions = remain;
}

// ====== 市肆（10 类商品买卖） ======
function refreshMarketPrices() {
    GOODS.forEach(g => { const v = (Math.random() * 0.5 + 0.75); state.goodsPrices[g.id] = Math.round(g.base * v); });
}
function buyGood(id, qty) {
    const g = GOODS.find(x => x.id === id); if (!g) return;
    const price = state.goodsPrices[id] || g.base;
    const cost = price * qty;
    if (state.treasury < cost) { log(`国库不足。`, 'warn'); return; }
    state.treasury -= cost;
    state.market[id] = (state.market[id] || 0) + qty;
    if (id === 'grain') state.food += qty;
    if (id === 'iron' || id === 'cannon') state.militaryPower += Math.floor(qty / 100);
    log(`采买${g.name}${qty}${g.unit}（${cost}银）。`);
}
function sellGood(id, qty) {
    const g = GOODS.find(x => x.id === id); if (!g) return;
    if ((state.market[id] || 0) < qty) { log(`库存不足。`, 'warn'); return; }
    const price = state.goodsPrices[id] || g.base;
    const rev = Math.floor(price * qty * 0.9);
    state.market[id] -= qty;
    state.treasury += rev;
    log(`卖出${g.name}${qty}${g.unit}（得${rev}银）。`);
}

// ====== AI 敌国 ======
function tickAI() {
    state.nations.forEach(n => {
        const persona = AI_BEHAVIORS[n.aiPersona] || AI_BEHAVIORS.aggressive;
        // 外交自然衰减 / 增长
        state.diplomacy[n.id] = (state.diplomacy[n.id] || 0);
        if (state.currentWars[n.id]) state.diplomacy[n.id] -= 5;
        // 朝贡
        if (Math.random() < persona.tributeProb && !state.currentWars[n.id]) {
            state.treasury += 200; state.prestige = Math.min(100, state.prestige + 2);
            log(`${n.name}遣使朝贡，进贡金银。`, 'good');
            state.diplomacy[n.id] = Math.min(100, state.diplomacy[n.id] + 3);
        }
        // 互市
        if (Math.random() < persona.tradeProb && !state.currentWars[n.id]) {
            state.treasury += 300; log(`${n.name}遣商互市，朝廷抽分。`, 'good');
            state.diplomacy[n.id] = Math.min(100, state.diplomacy[n.id] + 2);
        }
        // 进攻
        if (Math.random() < persona.attackProb && !state.currentWars[n.id]) {
            const borderCandidates = ['xuanFu','daTong','liaoDong','ningXia','ganSu','yunNan'].filter(id => state.provinces.find(p => p.id === id));
            if (borderCandidates.length > 0) {
                const target = borderCandidates[Math.floor(Math.random() * borderCandidates.length)];
                const loss = Math.min(state.militaryPower, 200 + Math.floor(Math.random() * 600));
                const stDam = 2 + Math.floor(Math.random() * 4);
                state.militaryPower = Math.max(0, state.militaryPower - loss);
                state.stability = Math.max(0, state.stability - stDam);
                state.currentWars[n.id] = (state.currentWars[n.id] || 0) + 1;
                log(`【边患】${n.name}袭扰${nameOfProvince(target)}，损兵${loss}，稳定-${stDam}。`, 'danger');
                n.military = Math.max(0, n.military - Math.floor(loss * 0.7));
            }
        }
    });
}

// ====== 外交动作 ======
function improveDiplomacy(nationId, delta) {
    state.diplomacy[nationId] = Math.max(-100, Math.min(100, (state.diplomacy[nationId] || 0) + delta));
}
function declareWar(nationId) {
    state.diplomacy[nationId] = -100; state.currentWars[nationId] = (state.currentWars[nationId] || 0) + 1;
    log(`与${state.nations.find(n=>n.id===nationId).name}开战！`, 'warn');
}
function makePeace(nationId) {
    state.diplomacy[nationId] = 0; state.currentWars[nationId] = 0;
    log(`与${state.nations.find(n=>n.id===nationId).name}议和。`);
}

// ====== 新游戏 / 初始化 ======
function newGame() {
    const fresh = {
        year: 1, season: 1, treasury: 10000, food: 5000,
        stability: 60, prestige: 50, militaryPower: 8000, mandate: 70,
        factions: JSON.parse(JSON.stringify(FACTIONS)),
        currentMemorials: [], log: [], gameOver: false, victory: null,
        prosperityYears: 0, revivalYears: 0, wasLowStability: false,
        scholar: SCHOLAR_LIST[Math.floor(Math.random() * SCHOLAR_LIST.length)],
        policyChosen: false, chosenPolicy: null,
        projects: [], doneProjects: [],
        princes: [], heir: null,
        hazards: [], _recentMemorials: [],
        generals: [], armies: [], drafts: [],
        provinces: JSON.parse(JSON.stringify(PROVINCES)),
        provinceGarrisonExtra: {},
        nations: JSON.parse(JSON.stringify(NATIONS)),
        spyMissions: [],
        myIntel: 50,
        deptHeads: {},
        goodsPrices: {},
        market: { grain:0,salt:0,iron:0,tea:0,silk:0,horse:0,cannon:0,porcelain:0,cotton:0,paper:0 },
        diplomacy: { mongolYuan:-30, oirat:-15, japan:0, korea:50, annam:20 },
        currentWars: {},
        battleLog: [],
        mapView: { x: 0, y: 0, scale: 1 }
    };
    Object.assign(state, fresh);
    ensureFirstPrince();
    initDeptHeads();
    ensureGenerals();
    refreshMarketPrices();
    // 给我方一支在京师的现成军团
    state.armies.push({ id:'army_init', name:'京营', unitType:'infantry', count:3000, general:null, morale:80, training:70, origin:'shunTian', status:'ready' });
    state.armies.push({ id:'army_cav', name:'三千营', unitType:'cavalry', count:1500, general:null, morale:80, training:75, origin:'shunTian', status:'ready' });
    state.armies.push({ id:'army_gun', name:'神机营', unitType:'gunner', count:1000, general:null, morale:80, training:80, origin:'shunTian', status:'ready' });
}
