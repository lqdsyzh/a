// ====================================================================
// 《大明国策 v2》静态数据
// 八个模块：地图/省/兵/将/府部/市肆/敌国/间谍
// ====================================================================

// 朝代与年号
const DYNASTY = '大明';
const REIGN_TITLE = '永乐';
const START_YEAR = 1;
const SEASONS = ['春', '夏', '秋', '冬'];

// 1) 大明行政区与战略要地（自定坐标体系，逻辑地图，500x500 像素画布）
// 0..499 的逻辑坐标，画布自适应
// 属性：人口(万)、粮产(万石)、商业、城防、忠诚、兵源、是否有卫所
const PROVINCES = [
    { id:'shunTian',    name:'顺天府',     x:330, y:200, pop:480, grain:120, commerce:80,  fort:90, loyalty:80, garrison:15000, type:'capital' },
    { id:'shanDong',    name:'山东',       x:360, y:240, pop:620, grain:150, commerce:60,  fort:55, loyalty:65, garrison:8000,  type:'plain' },
    { id:'heNan',       name:'河南',       x:300, y:270, pop:540, grain:180, commerce:50,  fort:50, loyalty:70, garrison:6000,  type:'plain' },
    { id:'shaanXi',     name:'陕西',       x:230, y:280, pop:300, grain:90,  commerce:30,  fort:60, loyalty:55, garrison:12000, type:'border' },
    { id:'ningXia',     name:'宁夏',       x:200, y:230, pop:60,  grain:18,  commerce:10,  fort:75, loyalty:50, garrison:9000,  type:'border' },
    { id:'ganSu',       name:'甘肃',       x:160, y:260, pop:120, grain:30,  commerce:20,  fort:60, loyalty:45, garrison:7000,  type:'border' },
    { id:'liaoDong',    name:'辽东',       x:380, y:140, pop:180, grain:45,  commerce:25,  fort:70, loyalty:60, garrison:14000, type:'border' },
    { id:'xuanFu',      name:'宣府',       x:310, y:160, pop:90,  grain:22,  commerce:10,  fort:85, loyalty:65, garrison:11000, type:'border' },
    { id:'daTong',      name:'大同',       x:270, y:160, pop:80,  grain:20,  commerce:10,  fort:80, loyalty:60, garrison:10000, type:'border' },
    { id:'shanXi',      name:'山西',       x:280, y:220, pop:380, grain:90,  commerce:55,  fort:65, loyalty:70, garrison:7000,  type:'mountain' },
    { id:'jiangNan',    name:'江南',       x:340, y:330, pop:900, grain:320, commerce:160, fort:50, loyalty:75, garrison:6000,  type:'rich' },
    { id:'zheJiang',    name:'浙江',       x:380, y:360, pop:520, grain:160, commerce:120, fort:55, loyalty:75, garrison:5000,  type:'coast' },
    { id:'fuJian',      name:'福建',       x:370, y:410, pop:260, grain:80,  commerce:60,  fort:50, loyalty:70, garrison:5000,  type:'coast' },
    { id:'guangDong',   name:'广东',       x:320, y:450, pop:340, grain:90,  commerce:70,  fort:45, loyalty:65, garrison:5000,  type:'coast' },
    { id:'guangXi',     name:'广西',       x:260, y:430, pop:180, grain:50,  commerce:20,  fort:40, loyalty:55, garrison:4000,  type:'mountain' },
    { id:'yunNan',      name:'云南',       x:210, y:410, pop:140, grain:30,  commerce:15,  fort:50, loyalty:45, garrison:8000,  type:'mountain' },
    { id:'guiZhou',     name:'贵州',       x:240, y:380, pop:120, grain:25,  commerce:10,  fort:45, loyalty:50, garrison:4000,  type:'mountain' },
    { id:'siChuan',     name:'四川',       x:220, y:340, pop:420, grain:140, commerce:55,  fort:55, loyalty:65, garrison:6000,  type:'mountain' },
    { id:'huBei',       name:'湖广',       x:300, y:340, pop:480, grain:160, commerce:60,  fort:50, loyalty:70, garrison:5000,  type:'plain' },
    { id:'jiangXi',     name:'江西',       x:320, y:360, pop:380, grain:120, commerce:70,  fort:50, loyalty:75, garrison:4500,  type:'plain' }
];
// 邻接关系（用于行军路径）
const PROVINCE_NEIGHBORS = {
    shunTian:['shanDong','heNan','shanXi','xuanFu'],
    shanDong:['shunTian','heNan','jiangNan','liaoDong'],
    heNan:['shunTian','shanDong','huBei','shanXi','shaanXi'],
    shanXi:['shunTian','heNan','shaanXi','daTong','xuanFu'],
    shanXi:['shunTian','heNan','shaanXi','daTong','xuanFu'],
    xuanFu:['shunTian','shanXi','daTong','liaoDong'],
    daTong:['shanXi','xuanFu','shaanXi','ningXia'],
    ningXia:['daTong','shaanXi','ganSu'],
    ganSu:['ningXia','shaanXi'],
    shaanXi:['heNan','shanXi','daTong','ningXia','ganSu','siChuan','huBei'],
    liaoDong:['xuanFu','shanDong'],
    jiangNan:['shanDong','zheJiang','jiangXi','huBei'],
    zheJiang:['jiangNan','jiangXi','fuJian'],
    fuJian:['zheJiang','guangDong'],
    guangDong:['fuJian','guangXi','yunNan'],
    guangXi:['guangDong','yunNan','guiZhou'],
    yunNan:['guangXi','guiZhou','siChuan'],
    guiZhou:['yunNan','guangXi','siChuan','huBei'],
    siChuan:['shaanXi','huBei','guiZhou','yunNan'],
    huBei:['heNan','shaanXi','jiangNan','jiangXi','guiZhou','siChuan'],
    jiangXi:['jiangNan','zheJiang','huBei','fuJian']
};
// 距离表（行军所需季数）
const MARCH_DAYS = 90; // 1 季 = 90 天
function marchDaysBetween(fromId, toId) {
    if (fromId === toId) return 0;
    // BFS 最短路（按邻接）
    const visited = new Set([fromId]);
    const queue = [[fromId, 0]];
    while (queue.length) {
        const [cur, d] = queue.shift();
        const nbrs = PROVINCE_NEIGHBORS[cur] || [];
        for (const n of nbrs) {
            if (n === toId) return d + 1;
            if (!visited.has(n)) { visited.add(n); queue.push([n, d + 1]); }
        }
    }
    return 5; // 不连通时最远距离
}

// 2) 兵种（10 种）—— 攻击、防御、机动力、维持费(银/月/千兵)、装备
const UNIT_TYPES = {
    infantry:    { name:'步卒',     atk:5,  def:8,  move:1, cost:100, equip:['甲','刀'] },
    pikeman:     { name:'长枪兵',   atk:7,  def:10, move:1, cost:120, equip:['甲','长枪'] },
    swordsman:   { name:'刀牌手',   atk:9,  def:9,  move:1, cost:150, equip:['甲','刀','盾'] },
    archer:      { name:'弓弩手',   atk:8,  def:5,  move:1, cost:120, equip:['弓','甲'] },
    crossbow:    { name:'神机营',   atk:11, def:6,  move:1, cost:200, equip:['弩','甲'] },
    gunner:      { name:'火铳营',   atk:14, def:5,  move:1, cost:280, equip:['火铳','甲'] },
    cavalry:     { name:'骑兵',     atk:10, def:7,  move:2, cost:220, equip:['马','甲'] },
    heavyCav:    { name:'重骑兵',   atk:14, def:10, move:2, cost:350, equip:['重马','甲'] },
    chariot:     { name:'车营',     atk:6,  def:14, move:1, cost:250, equip:['车','甲'] },
    warship:     { name:'水师',     atk:11, def:9,  move:2, cost:300, equip:['舰','炮'] }
};
const UNIT_IDS = Object.keys(UNIT_TYPES);

// 3) 将领池
const GENERAL_GIVEN = ['骥','鹏','虎','豹','彪','雄','烈','勇','英','毅','猛','刚','岳','云','武','扬'];
const GENERAL_STYLE = ['忠','勇','智','严','仁','义','烈','悍'];
function makeGeneral(name, style, ability, faction) {
    return {
        id: 'g_' + Math.random().toString(36).slice(2, 8),
        name, style,
        stats: { attack: ability + Math.floor(Math.random()*15)-5, defense: ability + Math.floor(Math.random()*15)-5, intellect: ability + Math.floor(Math.random()*15)-5 },
        loyalty: 50 + Math.floor(Math.random()*30),
        ability,
        faction,        // 倾向
        commanding: null, // 当前指挥的 army id
        status: 'free'  // free / commanding / wounded / dead
    };
}

// 4) 五军都督府 / 府部体制（12 个府部）
const DEPARTMENTS = [
    { id:'censor',   name:'都察院', desc:'风闻言事，弹劾百官。', function:'反腐+查案', headStat:'民望' },
    { id:'personnel',name:'吏部',   desc:'铨选考核，官员任免。', function:'招贤+任免', headStat:'人才' },
    { id:'revenue',  name:'户部',   desc:'钱粮赋税，赈灾调拨。', function:'税收+赈灾', headStat:'府库' },
    { id:'rites',    name:'礼部',   desc:'朝贡祭祀，科举教化。', function:'外交+教化', headStat:'教化' },
    { id:'war',      name:'兵部',   desc:'调兵遣将，军籍马政。', function:'调兵+军纪', headStat:'军威' },
    { id:'justice',  name:'刑部',   desc:'律法刑狱，缉捕盗匪。', function:'律法+治安', headStat:'治安' },
    { id:'works',    name:'工部',   desc:'营造水利，城池屯田。', function:'建设+水利', headStat:'营缮' },
    { id:'cabinet',  name:'内阁',   desc:'票拟机要，票拟批答。', function:'议政+票拟', headStat:'机要' },
    { id:'grand',    name:'五军都督府', desc:'掌天下军政，行营调卫。', function:'训练+行营', headStat:'兵籍' },
    { id:'silijian', name:'司礼监', desc:'批红传旨，内廷机要。', function:'内廷+情报', headStat:'内廷' },
    { id:'jinyi',    name:'锦衣卫', desc:'北镇抚司，巡查缉捕。', function:'间谍+反间', headStat:'耳目' },
    { id:'east',     name:'东厂',   desc:'内廷侦缉，监视百官。', function:'侦查+刺探', headStat:'罗织' }
];
// 每府部当前官员（首长）—— 玩家任命影响其效率
// 5) 物资 / 市肆商品（10 大类）
const GOODS = [
    { id:'grain',   name:'粮',   unit:'石',   base:1,  vol:0.5,  category:'粮' },
    { id:'salt',    name:'盐',   unit:'引',   base:8,  vol:1,    category:'专' },
    { id:'iron',    name:'铁',   unit:'斤',   base:2,  vol:1,    category:'工' },
    { id:'tea',     name:'茶',   unit:'斤',   base:3,  vol:1,    category:'商' },
    { id:'silk',    name:'丝',   unit:'匹',   base:18, vol:1.2,  category:'商' },
    { id:'horse',   name:'马',   unit:'匹',   base:35, vol:2,    category:'军' },
    { id:'cannon',  name:'火炮', unit:'门',   base:500,vol:5,    category:'军' },
    { id:'porcelain',name:'瓷', unit:'件',   base:12, vol:1,    category:'商' },
    { id:'cotton',  name:'棉布', unit:'匹',   base:4,  vol:1,    category:'工' },
    { id:'paper',   name:'纸',   unit:'刀',   base:2,  vol:0.5,  category:'文' }
];
// 6) 五国 / 势力（敌国 + 朝贡国）— 每国有：坐标、首府、政体、军力、国库、外交、好战度
const NATIONS = [
    { id:'mongolYuan', name:'北元大汗国', color:'#b55', stype:'horde', capital:'哈拉和林', military:28000, treasury:6000, diplomacy:-30, aggression:75,
      gov:{type:'部落联盟', ministers:4, ministersLeft:3, intelPower:40}, provinces:[{name:'漠北',x:200,y:60},{name:'辽北',x:280,y:80}], aiPersona:'aggressive' },
    { id:'oirat',     name:'瓦剌',       color:'#d75', stype:'horde', capital:'别失八里', military:18000, treasury:3000, diplomacy:-15, aggression:55,
      gov:{type:'部落联盟', ministers:4, ministersLeft:4, intelPower:30}, provinces:[{name:'准噶尔',x:100,y:200},{name:'瓦剌故地',x:80,y:160}], aiPersona:'raider' },
    { id:'japan',     name:'日本国',     color:'#5a8', stype:'kingdom', capital:'京都', military:14000, treasury:5000, diplomacy:0, aggression:40,
      gov:{type:'幕府将军', ministers:5, ministersLeft:5, intelPower:50}, provinces:[{name:'本州',x:480,y:280},{name:'九州',x:450,y:330}], aiPersona:'trader' },
    { id:'korea',     name:'朝鲜国',     color:'#5ac', stype:'tributary', capital:'汉城', military:8000, treasury:2500, diplomacy:50, aggression:10,
      gov:{type:'李朝朝廷', ministers:5, ministersLeft:5, intelPower:35}, provinces:[{name:'汉城',x:430,y:230}], aiPersona:'tribute' },
    { id:'annam',     name:'安南国',     color:'#a85', stype:'tributary', capital:'升龙', military:10000, treasury:2000, diplomacy:20, aggression:35,
      gov:{type:'安南朝廷', ministers:4, ministersLeft:3, intelPower:25}, provinces:[{name:'升龙',x:280,y:480}], aiPersona:'restless' }
];
// 7) 间谍行动类型
const SPY_OPS = [
    { id:'recon',   name:'侦察', desc:'探明敌国军力、城防、外交动向。', cost:200, intelDelta:30, dur:1, risk:0.15 },
    { id:'bribe',   name:'策反', desc:'收买敌国官员，降低其忠诚/满意度。', cost:500, intelDelta:15, dur:2, risk:0.30 },
    { id:'sabotage',name:'破坏', desc:'纵火、毒井、断敌补给。', cost:800, intelDelta:20, dur:2, risk:0.45 },
    { id:'assassinate',name:'刺杀', desc:'刺杀敌国将相/首辅。', cost:1500,intelDelta:25, dur:3, risk:0.55 },
    { id:'counter', name:'反间', desc:'识破并反制敌国间谍，提升我方反间能力。', cost:400, intelDelta:35, dur:1, risk:0.20 }
];
// 8) 五大传统政治派系（保留）
const FACTIONS = [
    { id:'civil',    name:'文官集团', satisfaction:60, influence:40, desc:'六部+内阁' },
    { id:'military', name:'武将集团', satisfaction:60, influence:30, desc:'五军都督+九边' },
    { id:'royal',    name:'宗室藩王', satisfaction:50, influence:20, desc:'各地藩王' },
    { id:'eunuch',   name:'宦官集团', satisfaction:50, influence:25, desc:'司礼监' },
    { id:'consort',  name:'外戚集团', satisfaction:55, influence:15, desc:'后妃家族' }
];
// 9) 首辅学派
const SCHOLAR_LIST = ['儒家','法家','兵家','农家','道家','墨家','纵横家','阴阳家','医家'];
const SCHOLAR_CAUTION = {
    '儒家':'以仁德安民为先', '法家':'当以律法立威、赏罚分明', '兵家':'士卒之怒不可轻，整军为先',
    '农家':'以农为本、先安耕织', '道家':'无为而治、顺时应势', '墨家':'以工代赈、器械济民',
    '纵横家':'权衡制衡、远交近攻', '阴阳家':'观象察变、敬天修德', '医家':'救民生、御疾疫'
};
// 10) 奏折（每份含完整选项与数值影响）
const MEMORIAL_TEMPLATES = [
    { type:'灾荒', title:'蝗灾肆虐', desc:'北直隶一带蝗灾泛滥，庄稼尽毁。', advisor:'农家：先保庄稼，再赈灾民。',
      options:[
        {text:'开仓赈灾', effects:{food:-800, treasury:-300, stability:10, civilSat:8, milSat:-2, prestige:2}},
        {text:'征发徭役灭蝗', effects:{food:-200, stability:-5, civilSat:-5, milSat:3, prestige:-3}},
        {text:'置之不理', effects:{stability:-15, civilSat:-10, prestige:-5}}
      ]},
    { type:'灾荒', title:'黄河决口', desc:'开封段黄河决口，淹没数县。', advisor:'法家：征发徭役修堤。',
      options:[
        {text:'拨款修堤', effects:{treasury:-1200, stability:8, civilSat:5, milSat:-2}},
        {text:'征发民夫', effects:{food:-300, stability:-3, civilSat:-8, milSat:2}},
        {text:'顺其自然', effects:{stability:-18, civilSat:-12, food:-500}}
      ]},
    { type:'灾荒', title:'瘟疫爆发', desc:'江南瘟疫流行。', advisor:'医家：广设医馆。',
      options:[
        {text:'派医官救治', effects:{treasury:-800, stability:5, civilSat:6, eunuchSat:3}},
        {text:'隔离疫区', effects:{food:-200, stability:-5, milSat:5, civilSat:-3}},
        {text:'祭祀祈福', effects:{prestige:-2, stability:-3, mandate:3, civilSat:-2}}
      ]},
    { type:'灾荒', title:'陕西大旱', desc:'赤地千里。', advisor:'道家：天灾乃天意。',
      options:[
        {text:'开官仓赈济', effects:{food:-1000, stability:8, civilSat:8, prestige:5}},
        {text:'祈雨祭天', effects:{mandate:5, prestige:3, stability:1}},
        {text:'强制征粮', effects:{food:500, stability:-15, civilSat:-10, milSat:3}}
      ]},
    { type:'灾荒', title:'京师地震', desc:'宫殿受损。', advisor:'阴阳家：上天示警。',
      options:[
        {text:'修缮宫殿', effects:{treasury:-1500, prestige:5, stability:3}},
        {text:'减免赋税', effects:{food:-200, stability:8, civilSat:5, prestige:5}},
        {text:'不理会', effects:{stability:-10, prestige:-5, mandate:-5}}
      ]},
    { type:'军事', title:'鞑靼犯边', desc:'大同府遭鞑靼骑兵劫掠。', advisor:'兵家：立即出兵。',
      options:[
        {text:'出兵迎击', effects:{militaryPower:-500, prestige:8, milSat:10, civilSat:-3, treasury:-1000}},
        {text:'坚壁清野', effects:{food:-300, stability:-3, milSat:-5, prestige:-2}},
        {text:'纳贡求和', effects:{treasury:-1500, prestige:-8, milSat:-8, stability:-2}}
      ]},
    { type:'军事', title:'倭寇劫掠沿海', desc:'倭寇登陆浙江。', advisor:'兵家：调水师围剿。',
      options:[
        {text:'派兵剿倭', effects:{militaryPower:-300, prestige:6, milSat:8, treasury:-800}},
        {text:'加强海禁', effects:{treasury:200, stability:-3, civilSat:-5, eunuchSat:5}},
        {text:'招安海盗', effects:{treasury:-400, stability:2, milSat:-3}}
      ]},
    { type:'军事', title:'土司叛乱', desc:'云南土司反叛。', advisor:'法家：改土归流。',
      options:[
        {text:'出兵平叛', effects:{militaryPower:-600, prestige:5, milSat:8, treasury:-1200}},
        {text:'招抚土司', effects:{prestige:3, stability:2, treasury:-500}},
        {text:'改土归流', effects:{civilSat:5, stability:-5, royalSat:-5, prestige:4}}
      ]},
    { type:'军事', title:'边军缺饷', desc:'九边将士数月未发饷。', advisor:'武将：立刻拨饷。',
      options:[
        {text:'立刻拨饷', effects:{treasury:-1500, milSat:12, stability:5}},
        {text:'拖欠部分', effects:{treasury:-500, milSat:-8, stability:-5}},
        {text:'削减编制', effects:{militaryPower:-1000, treasury:500, milSat:-15, stability:-10}}
      ]},
    { type:'军事', title:'武将争功', desc:'两将争边功，兵部请示。', advisor:'法家：赏罚严明。',
      options:[
        {text:'各赏银千两', effects:{treasury:-1000, milSat:8, civilSat:-3, prestige:2}},
        {text:'各打五十大板', effects:{milSat:-10, stability:3, civilSat:3}},
        {text:'严查军功虚报', effects:{milSat:-5, treasury:300, civilSat:5, prestige:2}}
      ]},
    { type:'政治', title:'举荐贤才', desc:'吏部推荐一名地方官。', advisor:'吏部：此人可堪大用。',
      options:[
        {text:'直接录用', effects:{prestige:3, civilSat:8, eunuchSat:-5}},
        {text:'驳回', effects:{civilSat:-5, prestige:-2}},
        {text:'调查后再定', effects:{treasury:-200, stability:2, civilSat:2, eunuchSat:5}}
      ]},
    { type:'政治', title:'科场舞弊', desc:'会试舞弊丑闻。', advisor:'礼部：严查重典。',
      options:[
        {text:'严查到底', effects:{prestige:5, stability:3, civilSat:-5, eunuchSat:-3}},
        {text:'压下消息', effects:{stability:-5, civilSat:3, eunuchSat:5}},
        {text:'重新考试', effects:{treasury:-300, prestige:4, civilSat:5}}
      ]},
    { type:'政治', title:'官员贪污', desc:'御史弹劾户部侍郎。', advisor:'都察院：抄家问斩。',
      options:[
        {text:'严查抄家', effects:{treasury:800, prestige:3, civilSat:-6, eunuchSat:3}},
        {text:'降级留用', effects:{stability:-3, civilSat:-2, prestige:-2, treasury:300}},
        {text:'睁一只眼闭一只眼', effects:{stability:-8, civilSat:-8, eunuchSat:5}}
      ]},
    { type:'经济', title:'商贾请开海禁', desc:'闽浙大贾联名上书。', advisor:'户部：开则利厚，盗亦随之。',
      options:[
        {text:'局部开海', effects:{treasury:1500, stability:-3, civilSat:5, eunuchSat:-3, prestige:4}},
        {text:'维持海禁', effects:{stability:2, civilSat:-2, treasury:300}},
        {text:'查办领头商人', effects:{treasury:500, civilSat:-10, stability:-2}}
      ]},
    { type:'经济', title:'发现银矿', desc:'云南奏报发现银矿。', advisor:'工部：官营为上。',
      options:[
        {text:'官营开采', effects:{treasury:2000, civilSat:-3, prestige:2}},
        {text:'民营开采征税', effects:{treasury:1000, civilSat:3, prestige:2}},
        {text:'封矿禁采', effects:{stability:2, civilSat:-2, prestige:-1}}
      ]},
    { type:'外交', title:'朝鲜来贡', desc:'朝鲜使臣请册封世子。', advisor:'礼部：当厚往薄来。',
      options:[
        {text:'册封并厚赐', effects:{treasury:-500, prestige:10, civilSat:5}},
        {text:'册封薄赐', effects:{prestige:5, civilSat:2, treasury:-200}},
        {text:'暂缓处理', effects:{stability:-2, prestige:-3}}
      ]},
    { type:'外交', title:'安南内附', desc:'安南权臣请降称臣。', advisor:'兵部：可收为藩属。',
      options:[
        {text:'收为藩属', effects:{prestige:8, treasury:500, stability:-2}},
        {text:'册封而复其国', effects:{prestige:3, treasury:300, stability:2}},
        {text:'拒绝受降', effects:{prestige:-2, civilSat:-2}}
      ]},
    { type:'宗室', title:'藩王请增护卫', desc:'宁王请增护卫三千。', advisor:'兵部：恐有养寇自重。',
      options:[
        {text:'准增护卫', effects:{milSat:2, royalSat:10, treasury:-800}},
        {text:'驳回', effects:{royalSat:-10, milSat:-5, stability:-2}},
        {text:'削减护卫', effects:{royalSat:-15, milSat:-8, stability:-5, prestige:3}}
      ]}
];
// 11) 奇观（保留）
const PROJECTS = [
    { id:'zicheng',    name:'紫禁城',   desc:'扩建宫城，彰显天子威仪。', cost:{treasury:12000}, turns:10, effect:{mandate:20, prestige:30, stability:10} },
    { id:'changcheng', name:'万里长城', desc:'修筑边墙，连九边为一体。', cost:{treasury:9000, food:3000}, turns:15, effect:{militaryPower:3000, prestige:15} },
    { id:'yunhe',      name:'大运河',   desc:'疏通运河，南北漕运通畅。', cost:{treasury:6000}, turns:8,  effect:{treasury:1000, food:800, prestige:8} },
    { id:'dadian',     name:'永乐大典', desc:'敕修群书，汇三千年文脉。', cost:{treasury:4000}, turns:6,  effect:{prestige:20, civilSat:10} },
    { id:'xiaoling',   name:'明孝陵',   desc:'营建皇陵，以安历代先灵。', cost:{treasury:5000}, turns:6,  effect:{mandate:10, royalSat:10} }
];
const PROJECT_NAMES = { zicheng:'紫禁城', changcheng:'万里长城', yunhe:'大运河', dadian:'永乐大典', xiaoling:'明孝陵' };
// 12) 每季政令（必选 1 项）
const POLICY_TEMPLATES = {
    1: [ // 春
        { text:'轻徭薄赋', desc:'减春税赋，休养生息。', effects:{ food:400, stability:4, civilSat:5 } },
        { text:'重农兴桑', desc:'劝课农桑，广植桑麻。', effects:{ food:500, prestige:2 } },
        { text:'兴办春闱', desc:'加开科第，广纳贤才。', effects:{ civilSat:6, prestige:4, treasury:-300 } }
    ],
    2: [ // 夏
        { text:'大举操练', desc:'点校兵马，张军威。', effects:{ militaryPower:400, milSat:5, treasury:-400 } },
        { text:'疏浚水利', desc:'以工代赈，修渠固堤。', effects:{ food:300, stability:3, treasury:-300 } },
        { text:'减免杂费', desc:'罢不急之务，宽民力。', effects:{ stability:4, civilSat:4, prestige:2 } }
    ],
    3: [ // 秋
        { text:'加征国赋', desc:'增平米税，充国用。', effects:{ treasury:1500, stability:-6, civilSat:-6 } },
        { text:'均平秋税', desc:'量入为出，宽严得宜。', effects:{ treasury:800 } },
        { text:'开仓平粜', desc:'柴粮抑价，济饥民。', effects:{ stability:5, civilSat:5, food:-300 } }
    ],
    4: [ // 冬
        { text:'祭祀天地', desc:'郊天祀地，祈国祚永昌。', effects:{ mandate:6, prestige:4, treasury:-500 } },
        { text:'编纂国史', desc:'命史官修实录，以彰功业。', effects:{ prestige:5, civilSat:3, treasury:-300 } },
        { text:'冬犒三军', desc:'颁赏九边，稳军心。', effects:{ milSat:6, militaryPower:200, treasury:-600 } }
    ]
};
// 13) 皇储 / 后宫
const PRINCE_GIVEN = ['允','瞻','祈','祐','溥','祁','见','永','翊','常'];
const PRINCE_CHAR  = ['仁','暴','庸','明','睿','悍','和','惰'];
// 14) 隐患池（处理失当追加）
const HAZARD_POOL = [
    { title:'灾民流徙', desc:'流民聚于畿辅，恐生民变。', advisor:'农家：当开粥棚。',
      options:[
        {text:'设粥厂', effects:{treasury:-500, food:-400, stability:6, civilSat:6}},
        {text:'遣送还乡', effects:{food:-200, stability:2, civilSat:3, prestige:2}},
        {text:'驱其出境', effects:{stability:-10, milSat:3, prestige:-5}}
      ]},
    { title:'瘟疫复发', desc:'江南多城复有疫讯。', advisor:'医家：当再遣医官。',
      options:[
        {text:'再遣医官', effects:{treasury:-600, stability:5, civilSat:5}},
        {text:'封锁疫城', effects:{food:-300, milSat:4, stability:-4}},
        {text:'迁民意避', effects:{food:-500, stability:3, civilSat:3}}
      ]},
    { title:'边军鼓噪', desc:'九边军士聚众鼓噪。', advisor:'兵部：当速发饷银。',
      options:[
        {text:'补发饷银', effects:{treasury:-1000, milSat:10, stability:4}},
        {text:'严惩为首', effects:{milSat:-8, stability:-6, prestige:3}},
        {text:'调镇他处', effects:{treasury:-400, milSat:-3, militaryPower:-300}}
      ]}
];
// 15) 季节基础收入
const SEASONAL_INCOME = {
    1: { food:200, desc:'春耕，粮储略增。' },
    2: { militaryPower:100, desc:'夏操兵马。' },
    3: { treasury:800, food:400, desc:'秋收，税粮并入。' },
    4: { prestige:3, mandate:2, desc:'冬祭，威望与天命稍增。' }
};
// 16) 派系行为触发
const FACTION_EVENTS = {
    civil:    { lowSat:{name:'文官怠政', desc:'六部推诿，政事积压。', effects:{stability:-4, treasury:-200}},
                highInf:{name:'文官结党', desc:'内阁票拟专擅，皇权旁落。', effects:{mandate:-3, stability:-2}} },
    military: { lowSat:{name:'武将离心', desc:'九边将帅心怀怨望。', effects:{stability:-5, militaryPower:-300}},
                highInf:{name:'武将跋扈', desc:'武将恃功傲上。', effects:{mandate:-2, stability:-3}} },
    royal:    { lowSat:{name:'宗室怨望', desc:'藩王心怀怨望。', effects:{stability:-3, prestige:-2}},
                highInf:{name:'宗室擅权', desc:'藩王逾制。', effects:{stability:-4, treasury:-300}} },
    eunuch:   { lowSat:{name:'阉宦懈怠', desc:'内廷机要迟滞。', effects:{stability:-2, eunuchSat:5}},
                highInf:{name:'宦官专权', desc:'司礼监擅权乱政。', effects:{mandate:-4, stability:-2}} },
    consort:  { lowSat:{name:'外戚寒心', desc:'后妃家族离心。', effects:{stability:-2, prestige:-1}},
                highInf:{name:'外戚干政', desc:'外戚与宦官争权。', effects:{mandate:-2, stability:-3, treasury:-300}} }
};
// 17) 失败阈值
const FAIL_THRESHOLDS = {
    mandate0:        { type:'mandate_end', desc:'天命耗尽，天下倾覆。' },
    stability0:      { type:'stability_end', desc:'民怨沸腾，国本动摇。' },
    peasantRevolt:   { type:'peasant_end', desc:'粮尽而民变。' },
    eunuchOver90:    { type:'eunuch_coup', desc:'宦官废立，大宝移于阉竖。' },
    consortOver90:   { type:'consort_coup', desc:'外戚篡权，社稷易主。' }
};
// 18) 胜利条件
const VICTORY_CONDITIONS = {
    yongleProsperity: { name:'永乐盛世', desc:'连续10年稳定>80 威望>80 天命>80' },
    allComeToCourt:   { name:'万国来朝', desc:'外交均>50 且与四邻无战事' },
    driveOutTartar:   { name:'驱逐鞑虏', desc:'灭亡北元/瓦剌任何一国' },
    revival:          { name:'中兴之主', desc:'从稳定<30恢复到稳定>70，持续5年' }
};
// 19) 府部官员
function blankDeptHead() { return { name:'空缺', ability:30, loyalty:50, faction:'civil' }; }
const ACCOUNT_ENDING_NAMES = {
    victory: '盛世/中兴',
    mandate_end:'天命已尽', stability_end:'国本动摇', peasant_end:'农民起义',
    eunuch_coup:'宦官废立', consort_coup:'外戚篡权'
};
// 20) AI 敌国性格
const AI_BEHAVIORS = {
    aggressive: { tickProb:0.9, attackProb:0.35, tributeProb:0.0, tradeProb:0.05 },
    raider:     { tickProb:0.7, attackProb:0.20, tributeProb:0.0, tradeProb:0.10 },
    trader:     { tickProb:0.5, attackProb:0.05, tributeProb:0.10,tradeProb:0.55 },
    tribute:    { tickProb:0.4, attackProb:0.02, tributeProb:0.70,tradeProb:0.30 },
    restless:   { tickProb:0.6, attackProb:0.10, tributeProb:0.20,tradeProb:0.30 }
};

// ====================================================================
// v3 大改：职官 / 选官 / 死亡 / 扩省 / 山水 / 宫廷
// ====================================================================

// === 21) 职官表（自定义可改、可封可贬） ============================
// rank 1..9（品）：1=正一品，9=正九品
// 类别：中央 / 地方 / 军事 / 监察 / 宗藩 / 宫廷
// 职官之间存在升迁路径：每个职官可定义多个 `next` 候选职位
const OFFICE_CATEGORIES = ['中央','地方','军事','监察','宗藩','宫廷'];
const OFFICES = [
    // —— 宰相系列 ——
    { id:'c1', name:'内阁首辅',       cat:'中央', rank:1, salary:12000, max:1, dept:'cabinet',  desc:'票拟机要、统率百官',      next:['c1'], salaryNext:[] },
    { id:'c2', name:'内阁次辅',       cat:'中央', rank:1, salary:10000, max:2, dept:'cabinet',  desc:'协理票拟、参赞机务',      next:['c1'] },
    { id:'c3', name:'内阁大学士',     cat:'中央', rank:2, salary:8000,  max:5, dept:'cabinet',  desc:'参预机务、票拟批答',      next:['c2','c1'] },
    { id:'c4', name:'中书舍人',       cat:'中央', rank:5, salary:2500,  max:6, dept:'cabinet',  desc:'缮写诏敕、传宣制命',      next:['c3'] },
    // —— 六部尚书 ——
    { id:'m1', name:'吏部尚书',       cat:'中央', rank:2, salary:7000,  max:1, dept:'personnel',desc:'铨选考核、任免百官',     next:['c2','c3'] },
    { id:'m2', name:'户部尚书',       cat:'中央', rank:2, salary:7000,  max:1, dept:'revenue',  desc:'钱粮赋税、赈灾调拨',     next:['c2','c3'] },
    { id:'m3', name:'礼部尚书',       cat:'中央', rank:2, salary:7000,  max:1, dept:'rites',    desc:'朝贡祭祀、科举教化',     next:['c2','c3'] },
    { id:'m4', name:'兵部尚书',       cat:'中央', rank:2, salary:7000,  max:1, dept:'war',      desc:'调兵遣将、军籍马政',     next:['c2','c3'] },
    { id:'m5', name:'刑部尚书',       cat:'中央', rank:2, salary:7000,  max:1, dept:'justice',  desc:'律法刑狱、缉捕盗匪',     next:['c2','c3'] },
    { id:'m6', name:'工部尚书',       cat:'中央', rank:2, salary:7000,  max:1, dept:'works',    desc:'营造水利、城池屯田',     next:['c2','c3'] },
    { id:'m7', name:'吏部侍郎',       cat:'中央', rank:3, salary:4500,  max:2, dept:'personnel',desc:'铨选副手、协理部务',     next:['m1'] },
    { id:'m8', name:'户部侍郎',       cat:'中央', rank:3, salary:4500,  max:2, dept:'revenue',  desc:'赋税副手、协理部务',     next:['m2'] },
    { id:'m9', name:'兵部侍郎',       cat:'中央', rank:3, salary:4500,  max:2, dept:'war',      desc:'军务副手、协理部务',     next:['m4'] },
    { id:'m10',name:'礼部侍郎',       cat:'中央', rank:3, salary:4500,  max:2, dept:'rites',    desc:'礼部副手、协理部务',     next:['m3'] },
    { id:'m11',name:'刑部侍郎',       cat:'中央', rank:3, salary:4500,  max:2, dept:'justice',  desc:'刑部副手、协理部务',     next:['m5'] },
    { id:'m12',name:'工部侍郎',       cat:'中央', rank:3, salary:4500,  max:2, dept:'works',    desc:'工部副手、协理部务',     next:['m6'] },
    // —— 都察院 / 监察 ——
    { id:'s1', name:'左都御史',       cat:'监察', rank:2, salary:7000,  max:1, dept:'censor',   desc:'风闻言事、总领弹劾',     next:['c2','c3'] },
    { id:'s2', name:'右都御史',       cat:'监察', rank:2, salary:7000,  max:1, dept:'censor',   desc:'风闻言事、总领弹劾',     next:['c2','c3'] },
    { id:'s3', name:'左副都御史',     cat:'监察', rank:3, salary:4500,  max:2, dept:'censor',   desc:'协理都察',               next:['s1','s2'] },
    { id:'s4', name:'右副都御史',     cat:'监察', rank:3, salary:4500,  max:2, dept:'censor',   desc:'协理都察',               next:['s1','s2'] },
    { id:'s5', name:'监察御史',       cat:'监察', rank:5, salary:2500,  max:13,dept:'censor',   desc:'分巡十三道、按察地方',   next:['s3','s4'] },
    { id:'s6', name:'巡按御史',       cat:'监察', rank:4, salary:3500,  max:13,dept:'censor',   desc:'代天子巡狩、所至震慑',   next:['s3','s4'] },
    // —— 司礼监 / 宫廷 ——
    { id:'p1', name:'司礼监掌印太监', cat:'宫廷', rank:2, salary:6000,  max:1, dept:'silijian', desc:'批红传旨、内廷机要',     next:['p2'] },
    { id:'p2', name:'司礼监秉笔太监', cat:'宫廷', rank:3, salary:4000,  max:4, dept:'silijian', desc:'代写意见、票拟入内',     next:['p1'] },
    { id:'p3', name:'御马监太监',     cat:'宫廷', rank:4, salary:3000,  max:2, dept:'silijian', desc:'御马监印、御马军务',     next:['p2'] },
    { id:'p4', name:'东厂掌印',       cat:'宫廷', rank:3, salary:5000,  max:1, dept:'east',     desc:'内廷侦缉之首',           next:['p1'] },
    { id:'p5', name:'东厂掌刑',       cat:'宫廷', rank:4, salary:3500,  max:2, dept:'east',     desc:'罗织罪名、拷讯囚徒',     next:['p4'] },
    { id:'p6', name:'锦衣卫指挥使',   cat:'军事', rank:2, salary:6500,  max:1, dept:'jinyi',    desc:'北镇抚司之首、巡查缉捕', next:['c2','c3'] },
    { id:'p7', name:'锦衣卫同知',     cat:'军事', rank:3, salary:4000,  max:2, dept:'jinyi',    desc:'协理卫事',               next:['p6'] },
    { id:'p8', name:'锦衣卫佥事',     cat:'军事', rank:4, salary:3000,  max:4, dept:'jinyi',    desc:'分理卫事',               next:['p7'] },
    // —— 翰林院 / 储才 ——
    { id:'h1', name:'翰林院学士',     cat:'中央', rank:3, salary:4000,  max:5, dept:'cabinet',  desc:'天子近臣、储才之职',     next:['c3','c2'] },
    { id:'h2', name:'侍讲学士',       cat:'中央', rank:4, salary:3000,  max:4, dept:'cabinet',  desc:'经筵日讲、侍读禁中',     next:['h1'] },
    { id:'h3', name:'国子监祭酒',     cat:'中央', rank:4, salary:3000,  max:1, dept:'rites',    desc:'太学之长、领袖成均',     next:['h1'] },
    { id:'h4', name:'国子监司业',     cat:'中央', rank:5, salary:2500,  max:2, dept:'rites',    desc:'太学副手',               next:['h3'] },
    { id:'h5', name:'翰林院编修',     cat:'中央', rank:6, salary:2000,  max:6, dept:'cabinet',  desc:'修书撰史、储才',         next:['h2','h1'] },
    { id:'h6', name:'翰林院检讨',     cat:'中央', rank:7, salary:1500,  max:6, dept:'cabinet',  desc:'修书撰史、储才',         next:['h5','h2'] },
    { id:'h7', name:'庶吉士',         cat:'中央', rank:7, salary:1200,  max:20,dept:'cabinet',  desc:'进士翘楚、馆选储才',     next:['h6','h5'] },
    // —— 五军都督府 ——
    { id:'a1', name:'五军都督府左都督',cat:'军事', rank:2, salary:7000,  max:1, dept:'grand',    desc:'掌行营调卫、协同兵部',  next:['c2','c3'] },
    { id:'a2', name:'五军都督府右都督',cat:'军事', rank:2, salary:7000,  max:1, dept:'grand',    desc:'掌行营调卫、协同兵部',  next:['c2','c3'] },
    { id:'a3', name:'五军都督府佥事', cat:'军事', rank:3, salary:4500,  max:4, dept:'grand',    desc:'分理五军府事',           next:['a1','a2'] },
    // —— 地方：省、府、县 ——
    { id:'l1', name:'巡抚',           cat:'地方', rank:3, salary:4500,  max:20,dept:'war',      desc:'代天子巡抚、军民兼统',   next:['a1','a2','m1','m2'] },
    { id:'l2', name:'总督',           cat:'地方', rank:2, salary:6000,  max:10,dept:'war',      desc:'总制一方、调度多省',     next:['a1','a2'] },
    { id:'l3', name:'承宣布政使司左布政使',cat:'地方', rank:3, salary:4500, max:20,dept:'revenue', desc:'一省民政、赋税长官',     next:['m2','m7'] },
    { id:'l4', name:'承宣布政使司右布政使',cat:'地方', rank:3, salary:4500, max:20,dept:'revenue', desc:'一省民政、赋税副职',     next:['m2','m7'] },
    { id:'l5', name:'提刑按察使',     cat:'监察', rank:3, salary:4500,  max:20,dept:'justice',  desc:'一省刑名、驿传邮传',     next:['m5','s3','s4'] },
    { id:'l6', name:'学政',           cat:'地方', rank:3, salary:4000,  max:20,dept:'rites',    desc:'一省学务、岁考院试',     next:['m3','h1'] },
    { id:'l7', name:'都转运盐使',     cat:'地方', rank:3, salary:4500,  max:6, dept:'revenue',  desc:'盐政专司、财赋重镇',     next:['m2'] },
    { id:'l8', name:'知府',           cat:'地方', rank:4, salary:3000,  max:200,dept:'revenue', desc:'一府长官、统辖数县',     next:['l3','l4'] },
    { id:'l9', name:'同知',           cat:'地方', rank:5, salary:2000,  max:200,dept:'revenue', desc:'知府副手、协理府务',     next:['l8'] },
    { id:'l10',name:'通判',           cat:'地方', rank:6, salary:1500,  max:200,dept:'revenue', desc:'刑名钱谷、协理府务',     next:['l9','l8'] },
    { id:'l11',name:'知州',           cat:'地方', rank:5, salary:2200,  max:200,dept:'revenue', desc:'一州之长、直辖属县',     next:['l8'] },
    { id:'l12',name:'知县',           cat:'地方', rank:7, salary:1200,  max:1500,dept:'revenue',desc:'一县父母、亲民之官',     next:['l11','l10'] },
    { id:'l13',name:'县丞',           cat:'地方', rank:8, salary:900,   max:1500,dept:'revenue',desc:'知县副手',               next:['l12'] },
    { id:'l14',name:'主簿',           cat:'地方', rank:9, salary:700,   max:1500,dept:'revenue',desc:'一县文书、勾稽账册',     next:['l13','l12'] },
    { id:'l15',name:'典史',           cat:'地方', rank:9, salary:600,   max:1500,dept:'justice', desc:'一县巡捕、缉盗',         next:['l13'] },
    // —— 军事：都司、总兵 ——
    { id:'w1', name:'都指挥使',       cat:'军事', rank:3, salary:4500,  max:20,dept:'war',      desc:'一省军政、统辖卫所',     next:['a1','a2'] },
    { id:'w2', name:'都指挥同知',     cat:'军事', rank:4, salary:3000,  max:40,dept:'war',      desc:'都司副手',               next:['w1'] },
    { id:'w3', name:'都指挥佥事',     cat:'军事', rank:5, salary:2500,  max:60,dept:'war',      desc:'都司属官',               next:['w2'] },
    { id:'w4', name:'总兵官',         cat:'军事', rank:3, salary:4500,  max:30,dept:'war',      desc:'一镇军政、统兵镇守',     next:['a1','a2'] },
    { id:'w5', name:'副总兵',         cat:'军事', rank:4, salary:3000,  max:60,dept:'war',      desc:'总兵副手',               next:['w4'] },
    { id:'w6', name:'参将',           cat:'军事', rank:5, salary:2500,  max:90,dept:'war',      desc:'分领营兵、镇守要地',     next:['w5','w4'] },
    { id:'w7', name:'游击将军',       cat:'军事', rank:5, salary:2500,  max:60,dept:'war',      desc:'机动作战、游击策应',     next:['w6','w5'] },
    { id:'w8', name:'守备',           cat:'军事', rank:6, salary:1500,  max:120,dept:'war',     desc:'一城一堡镇守',           next:['w7','w6'] },
    { id:'w9', name:'千户',           cat:'军事', rank:6, salary:1500,  max:200,dept:'war',     desc:'千户所所长',             next:['w8'] },
    { id:'w10',name:'百户',           cat:'军事', rank:7, salary:1000,  max:500,dept:'war',     desc:'百户所所长',             next:['w9'] },
    { id:'w11',name:'卫指挥使',       cat:'军事', rank:4, salary:3000,  max:100,dept:'war',     desc:'一卫军政、辖五千户所',   next:['w1'] },
    // —— 宗藩 ——
    { id:'r1', name:'宗人府宗令',     cat:'宗藩', rank:2, salary:7000,  max:1, dept:'royal',    desc:'掌皇族玉牒、议处藩政',   next:['c2','c3'] },
    { id:'r2', name:'宗人府经历',     cat:'宗藩', rank:6, salary:1500,  max:3, dept:'royal',    desc:'宗人府属官',             next:['r1'] },
    { id:'r3', name:'诸王',           cat:'宗藩', rank:1, salary:20000, max:30,dept:'royal',    desc:'藩王世子、统御封国',     next:['r1'] },
    { id:'r4', name:'王府长史',       cat:'宗藩', rank:5, salary:2500,  max:30,dept:'royal',    desc:'王府事务总管',           next:['r3','r1'] },
    { id:'r5', name:'王府纪善',       cat:'宗藩', rank:7, salary:1200,  max:30,dept:'royal',    desc:'规谏辅导宗藩',           next:['r4'] }
];
// 职官 → 府部 id 对应表（用于面板分组显示）
function officeByDept(deptId) { return OFFICES.filter(o => o.dept === deptId); }
function officeByCat(cat)     { return OFFICES.filter(o => o.cat === cat); }
function findOffice(id)       { return OFFICES.find(o => o.id === id); }

// === 22) 选官三路九步 ========================================
// 选官方式：科举 / 荐举 / 荫封
// 步骤：乡试→会试→殿试（科举） / 察举（荐举） / 思荫（荫封）
// 官员死亡率 = 基础 + 任职风险 + 敌对派系权重
// 升迁 / 贬谪 / 致仕（告老） / 丁忧（守丧27月） / 罢官 / 赐死
// 入仕年龄、致仕年龄 = 65 退
const ENTRY_PATHS = [
    { id:'keju',  name:'科举正途', desc:'十年寒窗、乡试、会试、殿试。出身最高、最受文官器重。',
      steps:['童试','乡试','会试','殿试'], knowledgeBase: 5, age: 22, bias: 'civil', bonus: 8 },
    { id:'jianju',name:'荐举一途', desc:'大臣察举、郡国荐辟。速成但出身略低、易卷入党争。',
      steps:['察举','廷试','授官'], knowledgeBase: 3, age: 28, bias: 'mixed', bonus: 4 },
    { id:'yinfeng',name:'荫封一途', desc:'父祖恩荫、入国子监。门第显要、易被外戚宗室拉拢。',
      steps:['荫入','国子监','散官','实授'], knowledgeBase: 2, age: 20, bias: 'royal', bonus: 6 }
];
// 死亡模式
const DEATH_CAUSES = [
    { id:'old_age',  name:'老死',        desc:'年逾七十、油尽灯枯。'},
    { id:'disease',  name:'病故',        desc:'瘟疫、瘴气、积劳成疾。'},
    { id:'war',      name:'阵亡',        desc:'行军作战、以身殉国。'},
    { id:'assassin', name:'被刺',        desc:'政敌、敌国间谍、江湖刺客。'},
    { id:'executed', name:'赐死',        desc:'皇帝赐自尽、抄家灭族。'},
    { id:'imprison', name:'瘐死狱中',    desc:'东厂、锦衣卫诏狱。'},
    { id:'beheaded', name:'斩首示众',    desc:'罪状昭彰、刑部处决。'},
    { id:'accident', name:'意外',        desc:'落马、溺水、火灾。'},
    { id:'suicide',  name:'自尽',        desc:'畏罪、忧国、殉节。'},
    { id:'duel',     name:'决斗',        desc:'武将私斗、不幸身死。'},
    { id:'plague',   name:'疫死',        desc:'地方大疫、群医束手。'},
    { id:'wound',    name:'伤重不治',    desc:'行伍负伤、积伤而亡。'},
    { id:'unknown',  name:'失踪',        desc:'下落不明、生死不知。'}
];
// 致仕（告老）年龄（默认 65）
const RETIREMENT_AGE = 65;
const MAX_AGE = 95;
const EXAM_TYPES = ['童试','乡试','会试','殿试'];

// === 23) 扩省 30 府（地图大气化） ===============================
const PROVINCES_V3 = [
    // 顺天 京畿
    { id:'shunTian',   name:'顺天府',     x:300, y:185, pop:480, grain:120, commerce:80, fort:90, loyalty:80, garrison:15000, type:'capital',  range:5 },
    // 北方九边
    { id:'liaoDong',   name:'辽东都司',   x:380, y:130, pop:180, grain:45,  commerce:25, fort:75, loyalty:60, garrison:14000, type:'border',   range:6 },
    { id:'xuanFu',     name:'宣府镇',     x:300, y:140, pop:90,  grain:22,  commerce:10, fort:88, loyalty:65, garrison:12000, type:'border',   range:4 },
    { id:'daTong',     name:'大同镇',     x:260, y:140, pop:80,  grain:20,  commerce:10, fort:82, loyalty:60, garrison:11000, type:'border',   range:5 },
    { id:'shanXi',     name:'山西布政使司',x:280, y:200, pop:380, grain:90,  commerce:55, fort:70, loyalty:70, garrison:8000,  type:'mountain', range:5 },
    { id:'shanDong',   name:'山东布政使司',x:355, y:215, pop:620, grain:150, commerce:60, fort:60, loyalty:65, garrison:9000,  type:'plain',    range:5 },
    { id:'heNan',      name:'河南布政使司',x:295, y:240, pop:540, grain:180, commerce:50, fort:55, loyalty:70, garrison:7000,  type:'plain',    range:5 },
    { id:'shaanXi',    name:'陕西布政使司',x:220, y:255, pop:300, grain:90,  commerce:30, fort:62, loyalty:55, garrison:12000, type:'mountain', range:6 },
    { id:'ningXia',    name:'宁夏卫',     x:200, y:200, pop:60,  grain:18,  commerce:10, fort:78, loyalty:50, garrison:9000,  type:'border',   range:4 },
    { id:'ganSu',      name:'甘肃镇',     x:140, y:235, pop:120, grain:30,  commerce:20, fort:65, loyalty:45, garrison:7000,  type:'border',   range:5 },
    // 江南诸省
    { id:'jiangNan',   name:'南直隶',     x:340, y:295, pop:900, grain:320, commerce:160,fort:55, loyalty:75, garrison:7000,  type:'rich',     range:5 },
    { id:'zheJiang',   name:'浙江布政使司',x:370, y:335, pop:520, grain:160, commerce:120,fort:58, loyalty:75, garrison:6000,  type:'coast',    range:5 },
    { id:'jiangXi',    name:'江西布政使司',x:310, y:330, pop:380, grain:120, commerce:70, fort:55, loyalty:75, garrison:5000,  type:'plain',    range:5 },
    { id:'huBei',      name:'湖广布政使司',x:280, y:315, pop:480, grain:160, commerce:60, fort:55, loyalty:70, garrison:6000,  type:'plain',    range:5 },
    { id:'siChuan',    name:'四川布政使司',x:200, y:315, pop:420, grain:140, commerce:55, fort:60, loyalty:65, garrison:7000,  type:'mountain', range:5 },
    { id:'fuJian',     name:'福建布政使司',x:380, y:385, pop:260, grain:80,  commerce:60, fort:55, loyalty:70, garrison:5000,  type:'coast',    range:4 },
    { id:'guangDong',  name:'广东布政使司',x:320, y:430, pop:340, grain:90,  commerce:70, fort:50, loyalty:65, garrison:6000,  type:'coast',    range:4 },
    { id:'guangXi',    name:'广西布政使司',x:255, y:410, pop:180, grain:50,  commerce:20, fort:45, loyalty:55, garrison:4500,  type:'mountain', range:4 },
    { id:'yunNan',     name:'云南布政使司',x:205, y:395, pop:140, grain:30,  commerce:15, fort:55, loyalty:45, garrison:9000,  type:'mountain', range:5 },
    { id:'guiZhou',    name:'贵州布政使司',x:235, y:370, pop:120, grain:25,  commerce:10, fort:50, loyalty:50, garrison:4500,  type:'mountain', range:4 },
    // 海外宣慰 / 羁縻
    { id:'annan',      name:'安南都统使司',x:295, y:470, pop:200, grain:60,  commerce:25, fort:40, loyalty:35, garrison:3000,  type:'tributary',range:3 },
    { id:'luSong',     name:'琉球',       x:435, y:340, pop:15,  grain:5,   commerce:30, fort:20, loyalty:70, garrison:300,   type:'tributary',range:2 },
    { id:'yiZu',       name:'乌斯藏',     x:160, y:330, pop:40,  grain:8,   commerce:5,  fort:30, loyalty:50, garrison:1000,  type:'tributary',range:3 },
    { id:'mengGu',     name:'蒙古兀良哈', x:280, y:90,  pop:60,  grain:10,  commerce:5,  fort:25, loyalty:30, garrison:2000,  type:'tribal',   range:4 },
    { id:'haiXi',      name:'海西女真',   x:420, y:90,  pop:50,  grain:8,   commerce:5,  fort:20, loyalty:30, garrison:1500,  type:'tribal',   range:3 },
    { id:'shuoFang',   name:'朔方漠北',   x:200, y:80,  pop:30,  grain:5,   commerce:3,  fort:15, loyalty:20, garrison:800,   type:'tribal',   range:4 },
    // 行省（早期羁縻，后期实控）
    { id:'shuNan',     name:'蜀南羁縻',   x:175, y:355, pop:30,  grain:5,   commerce:3,  fort:25, loyalty:40, garrison:500,   type:'tributary',range:2 },
    { id:'taiWan',     name:'台湾',       x:410, y:430, pop:5,   grain:2,   commerce:2,  fort:10, loyalty:25, garrison:200,   type:'tribal',   range:2 },
    { id:'haiNan',     name:'海南',       x:340, y:475, pop:25,  grain:6,   commerce:5,  fort:15, loyalty:50, garrison:300,   type:'tributary',range:2 },
    { id:'kamChat',    name:'库页',       x:475, y:60,  pop:2,   grain:1,   commerce:1,  fort:5,  loyalty:20, garrison:100,   type:'tribal',   range:2 }
];
const PROVINCES_V3_NEIGHBORS = {
    shunTian:['liaoDong','xuanFu','daTong','shanXi','shanDong','heNan'],
    liaoDong:['shunTian','xuanFu','haiXi','shanDong','mengGu'],
    xuanFu:['shunTian','liaoDong','daTong','shanXi','mengGu'],
    daTong:['shunTian','xuanFu','shanXi','shaanXi','ningXia','mengGu'],
    shanXi:['shunTian','daTong','xuanFu','heNan','shaanXi'],
    shanDong:['shunTian','liaoDong','heNan','jiangNan','mengGu'],
    heNan:['shunTian','shanDong','shanXi','shaanXi','huBei','jiangNan'],
    shaanXi:['heNan','shanXi','daTong','ningXia','ganSu','siChuan','huBei','yiZu'],
    ningXia:['daTong','shaanXi','ganSu','mengGu','shuoFang'],
    ganSu:['ningXia','shaanXi','yiZu','shuoFang'],
    jiangNan:['shanDong','heNan','zheJiang','jiangXi','huBei'],
    zheJiang:['jiangNan','jiangXi','fuJian','luSong'],
    jiangXi:['jiangNan','zheJiang','huBei','fuJian'],
    huBei:['heNan','shaanXi','jiangNan','jiangXi','siChuan','guiZhou'],
    siChuan:['shaanXi','huBei','guiZhou','yunNan','shuNan'],
    fuJian:['zheJiang','jiangXi','guangDong','taiWan'],
    guangDong:['fuJian','guangXi','annan','haiNan'],
    guangXi:['guangDong','yunNan','guiZhou'],
    yunNan:['guiZhou','guangXi','siChuan','shuNan','annan'],
    guiZhou:['yunNan','guangXi','siChuan','huBei'],
    annan:['guangDong','yunNan','haiNan'],
    luSong:['zheJiang','fuJian'],
    yiZu:['shaanXi','ganSu','siChuan','shuNan'],
    mengGu:['liaoDong','xuanFu','daTong','ningXia','shuoFang','haiXi'],
    haiXi:['liaoDong','mengGu','kamChat'],
    shuoFang:['ningXia','ganSu','mengGu'],
    shuNan:['siChuan','yunNan','yiZu'],
    taiWan:['fuJian','haiNan'],
    haiNan:['guangDong','annan','taiWan'],
    kamChat:['haiXi']
};
// 山水、驿站
const RIVERS = [
    { id:'yellow', name:'黄河', color:'#e0c060', points:[[180,200],[220,235],[260,255],[310,260],[355,250],[410,230]], width:2.5 },
    { id:'yangtze',name:'长江', color:'#6ab0e0', points:[[210,310],[260,310],[305,318],[350,318],[395,330]], width:2.5 },
    { id:'pearl',  name:'珠江', color:'#80a0d0', points:[[290,440],[320,425],[345,440]], width:2 },
    { id:'amur',   name:'黑龙江',color:'#a0c0e0', points:[[420,40],[440,75],[450,110]], width:2 },
    { id:'wei',    name:'渭河', color:'#c0a050', points:[[220,260],[245,260]], width:1.5 },
    { id:'han',    name:'汉江', color:'#7aa0c0', points:[[255,290],[275,300],[290,310]], width:1.5 },
    { id:'xiang',  name:'湘江', color:'#8aaad0', points:[[280,330],[295,345],[310,360]], width:1.5 },
    { id:'min',    name:'闽江', color:'#90b0d0', points:[[365,390],[380,400],[395,415]], width:1.5 }
];
const MOUNTAINS = [
    { id:'changbai',name:'长白山', x:415, y:75,  r:8 },
    { id:'heng',    name:'恒山',   x:265, y:170, r:5 },
    { id:'hua',     name:'华山',   x:255, y:240, r:5 },
    { id:'qin',     name:'秦岭',   x:240, y:280, r:6 },
    { id:'heng2',   name:'衡山',   x:300, y:340, r:5 },
    { id:'lu',      name:'庐山',   x:320, y:310, r:4 },
    { id:'tai',     name:'泰山',   x:355, y:215, r:5 },
    { id:'wuyi',    name:'武夷山', x:360, y:360, r:5 },
    { id:'hengduan',name:'横断山', x:200, y:355, r:6 },
    { id:'helan',   name:'贺兰山', x:215, y:215, r:4 },
    { id:'tianshan',name:'天山',   x:90,  y:200, r:6 },
    { id:'kunlun',  name:'昆仑山', x:80,  y:280, r:7 },
    { id:'ali',     name:'阿里',   x:60,  y:340, r:5 },
    { id:'tai2',    name:'台湾山', x:410, y:430, r:4 }
];
const POST_STATIONS = [
    { id:'p1', x:305, y:185, name:'京师驿' },
    { id:'p2', x:290, y:235, name:'开封驿' },
    { id:'p3', x:355, y:215, name:'济南驿' },
    { id:'p4', x:340, y:300, name:'金陵驿' },
    { id:'p5', x:295, y:475, name:'升龙驿' },
    { id:'p6', x:200, y:395, name:'昆明驿' },
    { id:'p7', x:300, y:140, name:'宣府驿' },
    { id:'p8', x:140, y:235, name:'酒泉驿' },
    { id:'p9', x:380, y:335, name:'杭州驿' },
    { id:'p10', x:200, y:255, name:'西安驿' }
];
// 驿站之间的"官道" - 显示驿路
const POST_ROADS = [
    ['p1','p7'],['p7','p2'],['p2','p10'],['p10','p8'],['p1','p3'],['p3','p4'],
    ['p4','p9'],['p4','p6'],['p6','p5']
];
// 疆域多边形（每省实际占据的领土形状）
const PROVINCE_TERRITORY = {
    shunTian:  { poly:[[290,170],[330,165],[355,180],[355,210],[335,215],[305,210],[285,200]], color:'#3a5a3a' },
    liaoDong:  { poly:[[365,110],[420,105],[430,135],[410,160],[375,160],[360,135]], color:'#3a4a5a' },
    xuanFu:    { poly:[[285,125],[320,120],[320,155],[290,160],[280,140]], color:'#3a4a5a' },
    daTong:    { poly:[[245,125],[280,120],[285,160],[255,160],[240,140]], color:'#3a4a5a' },
    shanXi:    { poly:[[270,180],[310,180],[320,210],[290,225],[260,215],[255,190]], color:'#4a3a3a' },
    shanDong:  { poly:[[345,200],[380,205],[390,235],[365,245],[345,235]], color:'#3a4a3a' },
    heNan:     { poly:[[280,225],[320,225],[340,250],[315,275],[280,265],[270,245]], color:'#3a4a3a' },
    shaanXi:   { poly:[[200,240],[250,240],[255,290],[225,300],[195,290],[185,260]], color:'#4a3a3a' },
    ningXia:   { poly:[[185,185],[220,185],[220,220],[190,220]], color:'#4a3a3a' },
    ganSu:     { poly:[[115,220],[175,220],[175,265],[120,265]], color:'#4a3a3a' },
    jiangNan:  { poly:[[320,275],[360,275],[375,310],[355,325],[320,315],[310,290]], color:'#2a4a3a' },
    zheJiang:  { poly:[[355,315],[395,315],[400,355],[370,365],[355,345]], color:'#2a4a3a' },
    jiangXi:   { poly:[[295,315],[345,315],[350,355],[315,360],[290,345]], color:'#2a4a3a' },
    huBei:     { poly:[[260,295],[305,295],[310,340],[280,345],[255,325]], color:'#2a4a3a' },
    siChuan:   { poly:[[180,290],[235,290],[245,345],[200,355],[170,330]], color:'#4a3a3a' },
    fuJian:    { poly:[[365,365],[400,365],[410,415],[375,420],[360,395]], color:'#2a4a5a' },
    guangDong: { poly:[[305,415],[345,410],[355,460],[325,475],[295,455]], color:'#2a4a5a' },
    guangXi:   { poly:[[240,395],[295,395],[300,440],[260,450],[235,425]], color:'#3a4a3a' },
    yunNan:    { poly:[[185,380],[230,375],[240,420],[200,430],[175,410]], color:'#4a3a3a' },
    guiZhou:   { poly:[[220,355],[265,355],[275,395],[235,400],[220,380]], color:'#3a4a3a' },
    annan:     { poly:[[280,455],[320,455],[320,485],[280,485]], color:'#3a3a4a' },
    luSong:    { poly:[[425,330],[445,330],[445,355],[425,355]], color:'#2a3a4a' },
    yiZu:      { poly:[[140,310],[180,310],[185,365],[145,365]], color:'#3a3a4a' },
    mengGu:    { poly:[[250,75],[330,75],[330,110],[250,110]], color:'#4a3a3a' },
    haiXi:     { poly:[[400,75],[455,75],[455,115],[400,115]], color:'#4a3a3a' },
    shuoFang:  { poly:[[170,60],[230,60],[230,100],[170,100]], color:'#4a3a3a' },
    shuNan:    { poly:[[155,335],[195,335],[195,375],[155,375]], color:'#3a3a4a' },
    taiWan:    { poly:[[400,415],[420,415],[420,445],[400,445]], color:'#2a3a4a' },
    haiNan:    { poly:[[325,460],[350,460],[350,490],[325,490]], color:'#2a3a4a' },
    kamChat:   { poly:[[460,40],[490,40],[490,90],[460,90]], color:'#2a3a4a' }
};
// 敌人 = 现有 NATIONS（保留）
const ENEMY_LOCATIONS = [
    { nationId:'mongolYuan', x:200, y:60,  size:30 },
    { nationId:'oirat',      x:80,  y:160, size:25 },
    { nationId:'japan',      x:480, y:280, size:22 },
    { nationId:'korea',      x:430, y:230, size:18 },
    { nationId:'annam',      x:300, y:480, size:18 }
];
// 朝代轮替（启用"以史为鉴"：玩家可参考前朝官职）
// 异国朝代表
const NATION_CIVIL = {
    mongolYuan: { type:'部落联盟', ministers: 6, intelPower: 30, leader: '大汗' },
    oirat:      { type:'瓦剌贵族', ministers: 5, intelPower: 20, leader: '太师' },
    japan:      { type:'幕府将军', ministers: 7, intelPower: 55, leader: '将军' },
    korea:      { type:'李朝朝廷', ministers: 6, intelPower: 35, leader: '国王' },
    annam:      { type:'安南朝廷', ministers: 5, intelPower: 25, leader: '国王' }
};
// 自创官职的玩家加封表（用于"自创官职"）
const CUSTOM_OFFICE_PREFIX = ['大都督','大司马','大司徒','太子太师','太子太傅','太子太保','少师','少傅','少保','殿前','机务','赞画','赞军','谘议','参赞','奉使','钦差','督抚','提调','总制','总办','督办','会办','经略','招讨','宣慰','招谕','护军','抚军'];
// 朝代礼制：册封等级（公、侯、伯、子、男）
const NOBLE_TITLES = ['公','侯','伯','子','男'];
// 每年俸禄表
function annualSalaryTotal() {
    if (!state.appointments) return 0;
    let s = 0;
    Object.values(state.appointments).forEach(offId => {
        const off = findOffice(offId);
        if (off) s += off.salary;
    });
    return s;
}

// === 24) 天象 / 灾异 ============================
const CELESTIAL_EVENTS = [
    { id:'eclipse_sun', name:'日食', desc:'白昼忽暗，京师震惊。',
      effects: { mandate: -3, stability: -5 }, advice: '应遣官祭天、修德以禳。' },
    { id:'eclipse_moon',name:'月食', desc:'月有食之。',
      effects: { stability: -2 }, advice: '后宫当谨身修德。' },
    { id:'comet',      name:'彗星现', desc:'彗星扫过，朝野大骇。',
      effects: { mandate: -5, prestige: -3 }, advice: '宜避殿减膳、下诏求直言。' },
    { id:'meteor',     name:'流星雨', desc:'星陨如雨。',
      effects: { stability: -1 }, advice: '不以为意可也。' },
    { id:'aurora',     name:'北极光', desc:'北天紫气冲霄。',
      effects: { mandate: 2, prestige: 2 }, advice: '此盛世之兆也。' },
    { id:'qilin',      name:'麒麟现', desc:'传报有麒麟现于郊野。',
      effects: { mandate: 8, prestige: 5 }, advice: '大吉，告祭天地。' },
    { id:'phoenix',    name:'凤凰来仪', desc:'百官奏报凤凰现。',
      effects: { mandate: 10, prestige: 8, stability: 3 }, advice: '圣王之瑞。' },
    { id:'dragon',     name:'黄河清', desc:'黄河清三日，千年奇观。',
      effects: { mandate: 12, prestige: 6 }, advice: '海内升平之瑞。' },
    { id:'earthquake', name:'京师地震', desc:'宫殿动摇。',
      effects: { stability: -8, mandate: -2 }, advice: '修德禳灾。' },
    { id:'flood',      name:'黄河决口', desc:'大水灌开封。',
      effects: { stability: -10, food: -500 }, advice: '速遣大臣赈济。' },
    { id:'locust',     name:'蝗灾', desc:'北直隶蝗虫蔽日。',
      effects: { food: -1000, stability: -5 }, advice: '开仓赈济、督捕蝗虫。' },
    { id:'plague',     name:'大疫', desc:'江南大疫流行。',
      effects: { stability: -8, militaryPower: -500 }, advice: '遣医官、广设药局。' },
    { id:'good_harvest', name:'丰年', desc:'五谷丰登。',
      effects: { food: 1000, stability: 3, prestige: 2 }, advice: '盛世之象。' }
];
// === 25) 科举试题 / 殿试 ============================
const EXAM_QUESTIONS = [
    { q:'何为仁？', a:'仁者爱人，克己复礼为仁。' },
    { q:'何为孝？', a:'孝悌也者，其为仁之本与。' },
    { q:'何为君道？', a:'君为元首，臣为股肱，共治天下。' },
    { q:'何为治河？', a:'上疏下堵，因势利导，束水攻沙。' },
    { q:'何为足兵？', a:'兵者国之大事，足食足兵，民信之矣。' },
    { q:'何为驭夷？', a:'来则勿拒，去则勿追，怀柔远人。' },
    { q:'何为教化？', a:'建国君民，教学为先，化民成俗。' },
    { q:'何为用人？', a:'用人如器，各取所长，量才授任。' },
    { q:'何为正心？', a:'意诚心正，身修家齐，国治天下平。' },
    { q:'何为理财？', a:'开源节流，量入为出，藏富于民。' }
];
// === 26) 殿试排名 ============================
function generateExamResult(pathId, candidates) {
    return candidates.map((c, i) => {
        const base = c.ability + c.merits + Math.floor(Math.random() * 20);
        return { ...c, score: base, rank: i + 1 };
    }).sort((a, b) => b.score - a.score);
}
// === 27) 谥号 / 封号 ============================
const POSTHUMOUS_HONORS = ['文','武','忠','孝','仁','毅','靖','康','昭','穆','懿','献','庄','简','肃'];
const POSITIVE_TITLES = ['公','侯','伯'];
const NOBLE_GRANTS = ['开国辅运','经邦弘化','崇文','宣武','靖远','镇北','平西','安南'];
// === 28) 宫廷嫔妃 ============================
const CONCUBINE_RANKS = [
    { id:'queen',     name:'皇后',   rank:1, max:1 },
    { id:'huangGuiFei',name:'皇贵妃', rank:2, max:1 },
    { id:'guiFei',    name:'贵妃',   rank:3, max:4 },
    { id:'fei',       name:'妃',     rank:4, max:6 },
    { id:'pin',       name:'嫔',     rank:5, max:12 },
    { id:'guifei',    name:'贵人',   rank:6, max:20 },
    { id:'changzai',  name:'常在',   rank:7, max:30 },
    { id:'daying',    name:'答应',   rank:8, max:50 }
];
const CONCUBINE_FAMILY = ['张','王','李','刘','陈','杨','赵','周','吴','徐','孙','朱','高','郭'];
const CONCUBINE_GIVEN = ['玉','兰','凤','春','秋','月','香','莲','菊','梅','燕','莺','红','翠','青','云','雪','桃','杏','柳'];
// === 29) 内阁廷推（重要人事决议） ============================
const COURT_VOTE_TOPICS = [
    { id:'open_market', title:'开海通商', desc:'闽浙大贾请开海禁，户部以为利厚，兵部以为倭寇从海来。',
      options:[
        { text:'开月港一处', effects:{treasury:1500, stability:-3, civilSat:5, eunuchSat:-3, prestige:4} },
        { text:'维持海禁', effects:{stability:2, civilSat:-2, treasury:300} },
        { text:'全面开海', effects:{treasury:3000, stability:-5, civilSat:8, milSat:-5, prestige:6} }
      ]},
    { id:'salt_reform', title:'盐法改革', desc:'盐政败坏，私盐横行。',
      options:[
        { text:'开中法', effects:{treasury:1000, civilSat:3, eunuchSat:-3} },
        { text:'纲盐法', effects:{treasury:1500, civilSat:5, eunuchSat:-2, stability:-2} },
        { text:'维持旧制', effects:{civilSat:-5, treasury:500} }
      ]},
    { id:'prince_reform', title:'藩王护卫', desc:'诸王护卫日增，朝臣以为忧。',
      options:[
        { text:'削减护卫', effects:{royalSat:-15, milSat:-5, stability:-3, prestige:3} },
        { text:'维持现状', effects:{royalSat:2, treasury:-300} },
        { text:'准予增护卫', effects:{royalSat:10, treasury:-1000, stability:-2} }
      ]}
];
// === 30) 谥册 ============================
const SACRED_TITLES = {
    wen:'文', wu:'武', zhong:'忠', xiao:'孝', ren:'仁', yi:'毅', jing:'靖', kang:'康',
    zhao:'昭', mu:'穆', yi:'懿', xian:'献', zhuang:'庄', jian:'简', su:'肃', xian2:'宪'
};
// === 31) 节气 / 季节事件 ============================
const SOLAR_TERMS = ['立春','雨水','惊蛰','春分','清明','谷雨','立夏','小满','芒种','夏至','小暑','大暑','立秋','处暑','白露','秋分','寒露','霜降','立冬','小雪','大雪','冬至','小寒','大寒'];
// === 32) 大典 ============================
const GRAND_CEREMONIES = [
    { id:'jitian', name:'祭天', desc:'天子于天坛祭天，祈谷求雨。', cost:2000, effects:{mandate:5, prestige:3}, season:1 },
    { id:'jidi',   name:'祭地', desc:'夏至方泽祭地。', cost:1500, effects:{mandate:4, prestige:2}, season:2 },
    { id:'jizusheng', name:'祭祖', desc:'岁末大祭太庙。', cost:2000, effects:{mandate:4, royalSat:5}, season:4 },
    { id:'nanjin', name:'南巡', desc:'天子南巡江南，体察民情。', cost:3000, effects:{prestige:5, stability:-3, food:500}, season:2 },
    { id:'beizhen', name:'北征', desc:'天子亲征漠北。', cost:5000, effects:{milSat:10, militaryPower:1000, treasury:-2000, mandate:5}, season:3 },
    { id:'fengshan', name:'封禅', desc:'泰山封禅大典。', cost:5000, effects:{mandate:15, prestige:10, stability:5}, season:1 }
];
// === 33) 帝王谥号系统（玩家可追谥功臣） ============================
const GRANTABLE_POSTHUMOUS = ['文忠','武穆','忠肃','文献','武毅','忠靖','文康','武靖','忠献','文献','武襄','忠懿'];
// === 34) 特殊剧情 / 大事件池 ============================
const EPIC_EVENTS = [
    { id:'jiajing_dao', title:'大礼议', desc:'群臣议大礼，廷杖数十。', effects:{stability:-5, civilSat:-8, eunuchSat:5}, trigger:{yearMin:1, yearMax:99} },
    { id:'lantai_case', title:'蓝玉案', desc:'凉国公蓝玉谋反事发，株连万人。', effects:{militaryPower:-2000, milSat:-15, stability:-3}, trigger:{yearMin:1, yearMax:5} },
    { id:'hu_weiyong',  title:'胡惟庸案', desc:'丞相胡惟庸谋反伏诛，罢中书省。', effects:{stability:-5, civilSat:-10, mandate:3}, trigger:{yearMin:1, yearMax:8} },
    { id:'yingzong_captured', title:'土木之变', desc:'御驾亲征被俘，京师震动。', effects:{stability:-15, militaryPower:-3000, mandate:-10}, trigger:{yearMin:15, yearMax:30} },
    { id:'zhenghe_treasure', title:'郑和下西洋', desc:'宝船七下西洋，扬威海外。', effects:{treasury:-3000, prestige:15, militaryPower:500}, trigger:{yearMin:1, yearMax:20} },
    { id:'xuande_renaissance', title:'仁宣之治', desc:'天下太平，宇内清平。', effects:{stability:5, prestige:3, mandate:3}, trigger:{yearMin:20, yearMax:50} }
];
// === 35) 流放地名 ============================
const EXILE_PLACES = ['海南崖州','贵州都匀','广西南宁','云南金齿','辽东铁岭','甘肃酒泉','四川雅州','福建建宁','湖广沅州','陕西延安'];
// === 36) 赏赐（玩家可对功臣） ============================
const REWARD_TYPES = [
    { id:'gold',    name:'赐金',   cost:500,  desc:'赏银若干', effect:{civilSat:3, milSat:3, prestige:2} },
    { id:'silk',    name:'赐帛',   cost:800,  desc:'赐彩缎',  effect:{civilSat:3, eunuchSat:3} },
    { id:'horse',   name:'赐马',   cost:1500, desc:'御马一匹', effect:{milSat:5, prestige:2} },
    { id:'jade',    name:'赐玉',   cost:3000, desc:'御赐玉带', effect:{prestige:5, civilSat:3, milSat:3} },
    { id:'title',   name:'赐爵',   cost:5000, desc:'封侯爵',   effect:{prestige:8, milSat:5, civilSat:5} },
    { id:'land',    name:'赐田',   cost:2000, desc:'赐良田百亩', effect:{civilSat:5, treasury:500} },
    { id:'marriage',name:'赐婚',   cost:1500, desc:'与皇女下嫁', effect:{prestige:4, civilSat:5, royalSat:3} },
    { id:'jinshi_fang', name:'赐府第', cost:5000, desc:'赐宅京师', effect:{prestige:4, civilSat:3} }
];
// === 37) 抄家 / 没收 ============================
const CONFISCATION_GAINS = [
    { min:500, max:2000, label:'薄有家资' },
    { min:2000, max:8000, label:'中人之产' },
    { min:8000, max:30000, label:'家资巨万' }
];
// === 38) 皇帝赐宴（科举后） ============================
const BANQUET_MENU = ['鹿鸣宴','琼林宴','恩荣宴','鹰扬宴','武举宴'];
// === 39) 内阁票拟 / 司礼监批红 ============================
const CABINET_PROCEDURE = [
    { step:1, name:'奏本', desc:'百官奏本上报' },
    { step:2, name:'通政使司', desc:'汇总奏本' },
    { step:3, name:'内阁票拟', desc:'内阁拟定处理意见' },
    { step:4, name:'司礼监批红', desc:'司礼监用印' },
    { step:5, name:'六部执行', desc:'六部分头执行' },
    { step:6, name:'都察院监察', desc:'都察院监督' }
];
// === 40) 风水 / 堪舆 ============================
const FENG_SHUI_EVENTS = [
    { title:'祖陵有气', desc:'钦天监奏报祖陵气色葱郁。', effects:{mandate:5} },
    { title:'宫殿有异', desc:'紫禁城某处方向有异。', effects:{mandate:-3, stability:-2} }
];
// === 41) 高级朝贡物品 ============================
const TRIBUTE_ITEMS = [
    { id:'horse_tribute', name:'贡马', base:500, prestige:3 },
    { id:'jade_tribute',  name:'贡玉', base:1000, prestige:5 },
    { id:'ginseng',       name:'贡参', base:800, prestige:4 },
    { id:'fur',           name:'贡皮', base:600, prestige:2 },
    { id:'sword',         name:'贡剑', base:2000, prestige:6, militaryPower:200 },
    { id:'porcelain_t',   name:'贡瓷', base:1500, prestige:5 },
    { id:'tea_t',         name:'贡茶', base:300, prestige:2 }
];
// === 42) 军功爵位 ============================
const MERIT_TITLES = [
    { id:'no1',  name:'一等公', threshold:10000, salary:30000 },
    { id:'no2',  name:'二等公', threshold:5000,  salary:20000 },
    { id:'no3',  name:'三等公', threshold:3000,  salary:15000 },
    { id:'bo',   name:'伯爵',   threshold:1500,  salary:8000 },
    { id:'zi',   name:'子爵',   threshold:800,   salary:5000 },
    { id:'nan',  name:'男爵',   threshold:400,   salary:3000 }
];
// === 43) 经筵 / 帝王讲学 ============================
const JINGYAN_SPEAKERS = ['内阁首辅','国子监祭酒','翰林院学士','经筵讲官'];
// === 44) 贡举 / 制科 ============================
const SPECIAL_EXAMS = [
    { id:'juren',   name:'举人', quota:100, desc:'乡试中第' },
    { id:'jinshi',  name:'进士', quota:30,  desc:'殿试中第' },
    { id:'zhike',   name:'明经', quota:50,  desc:'明经科' },
    { id:'wuju',    name:'武举', quota:20,  desc:'武举科' }
];
// === 45) 皇帝生活起居 ============================
const IMPERIAL_LIFE = {
    schedule: [
        { hour:'卯',  name:'早朝', desc:'御门听政、群臣奏事' },
        { hour:'辰',  name:'批阅奏章', desc:'内阁票拟、司礼监批红' },
        { hour:'巳',  name:'经筵日讲', desc:'翰林进讲经史' },
        { hour:'午',  name:'午休小憩', desc:'皇后贵妃侍膳' },
        { hour:'未',  name:'召对', desc:'召大臣议政' },
        { hour:'申',  name:'晚朝', desc:'再议政事' },
        { hour:'酉',  name:'晚膳', desc:'后宫侍宴' },
        { hour:'戌',  name:'批览', desc:'批览章奏' },
        { hour:'亥',  name:'安寝', desc:'皇后/贵妃侍寝' }
    ]
};
// === 46) 兵部军制 ============================
const WEI_SUO = [
    { id:'wei',  name:'卫', soldiers:5600 },
    { id:'qiansuo', name:'千户所', soldiers:1120 },
    { id:'baisuo',  name:'百户所', soldiers:112 },
    { id:'zongqi',  name:'总旗', soldiers:56 },
    { id:'xiaqi',   name:'小旗', soldiers:11 }
];
// === 47) 土木之变类剧情 ============================
const HISTORIC_EVENTS = [
    { name:'永乐盛世', desc:'文治武功、海内清平', effects:{stability:5, prestige:5, mandate:3}, weight:5 },
    { name:'万国来朝', desc:'诸番使臣云集京师', effects:{prestige:8, treasury:2000}, weight:3 },
    { name:'风调雨顺', desc:'连年丰收', effects:{food:1500, stability:3}, weight:5 },
    { name:'黄河清',   desc:'千年奇观', effects:{mandate:5, prestige:3}, weight:2 },
    { name:'彗星见',   desc:'天示警戒', effects:{stability:-3, mandate:-2}, weight:2 }
];
// === 48) 赐姓 / 收继 ============================
const IMPERIAL_SURNAMES = ['朱'];
const BESTOWED_SURNAMES = ['义','忠','顺','从','奉','承','保','崇'];
// === 49) 各省特色物产 ============================
const PROVINCE_PRODUCTS = {
    shunTian:'棉布', liaoDong:'人参', xuanFu:'皮毛', daTong:'皮毛',
    shanXi:'汾酒', shanDong:'丝绸', heNan:'瓷器', shaanXi:'皮货',
    ningXia:'枸杞', ganSu:'马匹', jiangNan:'丝绸', zheJiang:'茶叶',
    jiangXi:'瓷器', huBei:'稻米', siChuan:'井盐', fuJian:'茶叶',
    guangDong:'珍珠', guangXi:'木材', yunNan:'铜矿', guiZhou:'朱砂',
    annan:'象牙', luSong:'硫磺', yiZu:'马匹', mengGu:'皮毛',
    haiXi:'人参', shuoFang:'皮毛', shuNan:'木材', taiWan:'硫磺',
    haiNan:'珍珠', kamChat:'皮毛'
};

