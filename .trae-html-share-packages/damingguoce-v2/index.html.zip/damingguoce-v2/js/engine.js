// ====================================================================
// 《大明国策 v2》核心引擎
// 账号/状态/资源/战斗/行军/AI 敌国/间谍/朝政
// ====================================================================

// ====== 账号（本地多账号） ======
const ACCOUNTS_KEY = 'daming_accounts_v2';
const CURRENT_KEY  = 'daming_current_v2';
function getAccountDB() { try { return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || '{}'); } catch (e) { return {}; } }
function getCurrentUser() { return localStorage.getItem(CURRENT_KEY) || null; }
function getSaveKey(u) { return 'daming_save_v2_' + (u || 'guest'); }
function registerAccount(user, pass) {
    user = (user || '').trim();
    if (!/^[A-Za-z0-9_\u4e00-\u9fa5]{2,16}$/.test(user)) return { ok:false, msg:'用户名需2-16位中文/字母/数字/下划线' };
    if (!pass || pass.length < 4) return { ok:false, msg:'密码至少4位' };
    const db = getAccountDB();
    if (db[user]) return { ok:false, msg:'该用户已存在' };
    db[user] = { password: pass, created: Date.now(), endings: [], games: 0, yearsPlayed: 0 };
    try { localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(db)); } catch(e){ return {ok:false,msg:'存储失败'}; }
    loginAccount(user, pass);
    return { ok:true, msg:'注册成功' };
}
function loginAccount(user, pass) {
    const db = getAccountDB();
    if (!db[user]) return { ok:false, msg:'用户不存在' };
    if (db[user].password !== pass) return { ok:false, msg:'密码错误' };
    try { localStorage.setItem(CURRENT_KEY, user); } catch(e){}
    return { ok:true, msg:'登录成功' };
}
function logoutAccount() { try { localStorage.removeItem(CURRENT_KEY); } catch(e){} }
function saveGame() {
    const u = getCurrentUser(); if (!u) return false;
    try { localStorage.setItem(getSaveKey(u), JSON.stringify(state)); return true; } catch(e) { return false; }
}
function loadGame() {
    const u = getCurrentUser(); if (!u) return false;
    try { const data = localStorage.getItem(getSaveKey(u)); if (!data) return false; Object.assign(state, JSON.parse(data)); return true; } catch(e) { return false; }
}
function recordEnding(endingType) {
    const u = getCurrentUser(); if (!u) return;
    const db = getAccountDB(); if (!db[u]) return;
    db[u].endings = db[u].endings || [];
    db[u].endings.push({ type: endingType, name: ACCOUNT_ENDING_NAMES[endingType] || endingType, year: state.year, date: Date.now() });
    db[u].games = (db[u].games || 0) + 1;
    db[u].yearsPlayed = (db[u].yearsPlayed || 0) + state.year;
    try { localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(db)); } catch(e){}
}

// ====== 全局状态 ======
const state = {
    year: 1, season: 1,
    treasury: 10000, food: 5000, stability: 60, prestige: 50,
    militaryPower: 8000, mandate: 70,
    factions: JSON.parse(JSON.stringify(FACTIONS)),
    currentMemorials: [],
    log: [],
    gameOver: false, victory: null,
    prosperityYears: 0, revivalYears: 0, wasLowStability: false,
    scholar: '儒家',
    policyChosen: false, chosenPolicy: null,
    projects: [], doneProjects: [],
    princes: [], heir: null,
    hazards: [],
    // —— v2 新增 ——
    generals: [],            // 我方将领池
    armies: [],              // 我方军团（带将领、兵种、状态）
    drafts: [],              // 训练中的新兵
    provinces: JSON.parse(JSON.stringify(PROVINCES_V3)), // 复制以挂载运行时属性
    provinceGarrisonExtra: {}, // 每省增派
    nations: JSON.parse(JSON.stringify(NATIONS)),  // 复制
    spyMissions: [],         // 我方派遣的间谍任务
    myIntel: 50,             // 我方情报值
    deptHeads: {},           // 府部官员（id -> {name, ability, loyalty, faction}）
    goodsPrices: {},         // 市肆当前价
    market: { grain: 0, salt: 0, iron: 0, tea: 0, silk: 0, horse: 0, cannon: 0, porcelain: 0, cotton: 0, paper: 0 }, // 玩家库存
    diplomacy: {},           // 国家id -> 外交值
    currentWars: {},         // 国家id -> 战事计数
    battleLog: [],           // 近期战斗
    mapView: { x: 0, y: 0, scale: 1 },  // 地图视图
    // —— v3 官员系统 ——
    appointments: {},        // officeId -> { officialId, since }
    officials: [],           // 官员池
    examQueue: [],           // 待授官 / 候缺
    customOffices: [],       // 玩家自创官职
    cabinetLog: [],          // 朝廷大事记
    immuneRetire: 0,         // 免疫致仕回合
    // —— v4 大改：宫廷/天象/大典/科举/赏赐/流放/嫔妃 ——
    celestial: [],           // 天象记录
    ceremonies: [],          // 在建/已毕大典
    concubines: [],          // 嫔妃
    banishments: [],         // 流放中官员
    rewards: [],             // 赏赐记录
    posthumous: [],           // 谥号
    princesMarriages: [],    // 皇子婚配
    courtierCases: [],       // 抄家案件
    examResults: [],         // 历次科举结果
    imperialActs: []         // 帝王起居
};

// ====== 工具函数 ======
function log(message, level) {
    state.log.unshift({ year: state.year, season: SEASONS[state.season - 1], text: message, level: level || 'info' });
    if (state.log.length > 120) state.log.pop();
    if (typeof renderLog === 'function') renderLog();
}
function getFaction(id) { return state.factions.find(f => f.id === id); }
function updateFaction(id, sat, inf) {
    const f = getFaction(id); if (!f) return;
    if (sat) f.satisfaction = Math.max(0, Math.min(100, f.satisfaction + sat));
    if (inf) f.influence    = Math.max(5, Math.min(100, f.influence + inf));
}
function applyEffects(e) {
    if (!e) return;
    if (e.treasury)      state.treasury      = Math.max(0, state.treasury + e.treasury);
    if (e.food)         state.food          = state.food + e.food;
    if (e.stability)    state.stability     = Math.max(0, Math.min(100, state.stability + e.stability));
    if (e.prestige)     state.prestige      = Math.max(0, Math.min(100, state.prestige + e.prestige));
    if (e.militaryPower) state.militaryPower = Math.max(0, state.militaryPower + e.militaryPower);
    if (e.mandate)      state.mandate       = Math.max(0, Math.min(100, state.mandate + e.mandate));
    if (e.civilSat)     updateFaction('civil', e.civilSat, 0);
    if (e.milSat)       updateFaction('military', e.milSat, 0);
    if (e.royalSat)     updateFaction('royal', e.royalSat, 0);
    if (e.eunuchSat)    updateFaction('eunuch', e.eunuchSat, 0);
    if (e.consortSat)   updateFaction('consort', e.consortSat, 0);
}

// ====== 奏折 / 政令 / 朝议 ======
function generateMemorials() {
    const baseCount = state.season === 4 ? 1 + Math.floor(Math.random() * 2) : 2 + Math.floor(Math.random() * 2);
    let count = baseCount;
    const list = [];
    if (state.hazards.length > 0 && count > 0) {
        const h = state.hazards[0];
        list.push({ id: 0, ...h, title: h.title + '（隐患）' });
        state.hazards.shift();
        count--;
    }
    const recent = state._recentMemorials || [];
    const pool = MEMORIAL_TEMPLATES.filter(t => !recent.includes(t.title));
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    const chosen = shuffled.slice(0, Math.min(count, pool.length));
    state._recentMemorials = recent.concat(chosen.map(c => c.title)).slice(-6);
    chosen.forEach((tpl, i) => list.push({ id: list.length + i, ...tpl }));
    state.currentMemorials = list;
    return list;
}
function maybeAccumulateHazard(opt) {
    const e = opt.effects || {};
    const bad = (e.stability <= -10) || (e.food !== undefined && e.food <= -800) || (e.treasury !== undefined && e.treasury <= -1200);
    if (!bad) return;
    const open = HAZARD_POOL.filter(h => !state.hazards.includes(h.title) && !state.currentMemorials.some(m => m.title.indexOf(h.title) === 0));
    if (open.length > 0) { const h = open[Math.floor(Math.random() * open.length)]; state.hazards.push(h.title); log(`朝局隐忧：${h.desc}`, 'warn'); }
}
function handleMemorialChoice(memorialId, optionIndex) {
    const m = state.currentMemorials.find(x => x.id === memorialId);
    if (!m) return;
    const opt = m.options[optionIndex]; if (!opt) return;
    applyEffects(opt.effects);
    maybeAccumulateHazard(opt);
    log(`批复「${m.title}」：${opt.text}`);
    state.currentMemorials = state.currentMemorials.filter(x => x.id !== memorialId);
    if (typeof renderMemorialList === 'function') renderMemorialList();
    if (state.currentMemorials.length === 0) { closeMemorialModal(); completeSeason(); }
}
function choosePolicy(idx) {
    const list = POLICY_TEMPLATES[state.season]; if (!list || !list[idx]) return;
    const p = list[idx];
    if ((p.effects.treasury || 0) < 0 && state.treasury + (p.effects.treasury || 0) < 0) return;
    applyEffects(p.effects);
    state.chosenPolicy = p.text;
    state.policyChosen = true;
    log(`颁行政策：${p.text}（${p.desc}）`);
    if (typeof renderPolicyPanel === 'function') renderPolicyPanel();
}
function handleProject(idx, mode) {
    const p = PROJECTS[idx]; if (!p) return;
    if (mode === 'start') {
        if (state.projects.some(x => x.id === p.id)) return;
        if (state.doneProjects.includes(p.id)) return;
        if (state.treasury < p.cost.treasury) { log(`国库不足，无法启动「${p.name}」。`, 'warn'); return; }
        if (p.cost.food && state.food < p.cost.food) { log(`粮食不足，无法启动「${p.name}」。`, 'warn'); return; }
        state.treasury -= p.cost.treasury;
        if (p.cost.food) state.food -= p.cost.food;
        state.projects.push({ id: p.id, progress: 0, turns: p.turns });
        log(`大兴土木：启动「${p.name}」（需${p.turns}季）。`);
    } else if (mode === 'advance') {
        const pr = state.projects.find(x => x.id === p.id); if (!pr) return;
        pr.progress++;
        log(`「${p.name}」施工推进（${pr.progress}/${pr.turns}）。`);
        if (pr.progress >= pr.turns) {
            state.projects = state.projects.filter(x => x.id !== p.id);
            state.doneProjects.push(p.id);
            applyEffects(p.effect);
            log(`「${p.name}」落成！`, 'good');
        }
    }
    if (typeof renderProjectsPanel === 'function') renderProjectsPanel();
}
function startCourt() {
    if (state.gameOver) return;
    if (!state.policyChosen) { openPolicyPanel(); return; }
    if (state.currentMemorials.length > 0) { document.getElementById('memorialModal').classList.remove('hide'); renderMemorialList(); return; }
    generateMemorials();
    renderMemorialList();
    document.getElementById('memorialModal').classList.remove('hide');
    document.getElementById('btnYear').disabled = true;
    if (typeof renderPolicyAck === 'function') renderPolicyAck();
}
function closeMemorialModal() { const m = document.getElementById('memorialModal'); if (m) m.classList.add('hide'); }

// ====== 季节推进 / 结算 ======
function completeSeason() {
    const inc = SEASONAL_INCOME[state.season];
    if (inc) {
        if (inc.food) state.food += inc.food;
        if (inc.militaryPower) state.militaryPower += inc.militaryPower;
        if (inc.treasury) state.treasury += inc.treasury;
        if (inc.prestige) state.prestige = Math.min(100, state.prestige + inc.prestige);
        if (inc.mandate) state.mandate = Math.min(100, state.mandate + inc.mandate);
        log(`${SEASONS[state.season - 1]}季结算：${inc.desc}`);
    }
    // 训练中的部队按季推进
    state.drafts = state.drafts.filter(d => { d.daysLeft -= 90; if (d.daysLeft <= 0) {
        const a = { id:'army_' + Date.now() + '_' + Math.floor(Math.random()*1000), name:d.name, unitType:d.unitType, count:d.count, general:null, morale:70, training:60, origin:null, status:'ready' };
        state.armies.push(a);
        state.militaryPower += d.count;
        log(`新军「${d.name}」成军，编入京师。`);
        return false;
    } return true; });
    // 推进所有行军中军团
    tickMarches();
    // 推进所有间谍任务
    tickSpies();
    // 推进奇观（每季可推 1）
    // AI 行为 tick
    tickAI();
    // 维护费：每千兵 3 银/季
    const upkeep = Math.ceil(state.militaryPower / 1000) * 3;
    state.treasury = Math.max(0, state.treasury - upkeep);
    log(`军费：支出 ${upkeep} 银（按兵数）。`);

    state.season++;
    if (state.season > 4) { annualSettlement(); state.season = 1; state.year++; }
    state.policyChosen = false; state.chosenPolicy = null;
    checkFactionThresholds();
    checkVictoryDefeat();
    refreshAfterTick();
    if (state.gameOver) { if (typeof showGameOver === 'function') showGameOver(); return; }
    const sn = SEASONS[state.season - 1];
    const status = document.getElementById('courtStatus');
    const btn = document.getElementById('btnYear');
    if (status) status.innerHTML = `已进入${sn}季，点击「开启${sn}季朝议」先颁政令，再处奏折。`;
    if (btn) { btn.textContent = `开启${sn}季朝议`; btn.disabled = false; }
}
function refreshAfterTick() {
    ['updateTopBar','renderFactionPanel','renderOverview','renderFactionAlert','renderProjectsPanel','renderPrincesPanel','renderPolicyPanel','renderDiplomacyPanel','renderArmiesPanel','renderMarketPanel','renderSpyPanel','renderDeptsPanel'].forEach(fn => { try { if (typeof window[fn] === 'function') window[fn](); } catch(e){} });
    if (typeof renderLog === 'function') renderLog();
    if (typeof switchTab === 'function') switchTab('court');
}
function annualSettlement() {
    state.treasury += 500; state.food += 300;
    if (Math.random() < 0.3) { state.food += 200; log('今年风调雨顺，粮食丰收。', 'good'); }
    updateFaction('civil', 1, 1);
    updateFaction('military', -1, 0);
    updateFaction('eunuch', 1, 1);
    agePrinces();
    state.scholar = SCHOLAR_LIST[Math.floor(Math.random() * SCHOLAR_LIST.length)];
    log(`永乐${state.year}年年度结算。今岁由【${state.scholar}】学派执掌朝柄。`);
    checkPrinceBirth();
    if (typeof tickOfficials === 'function') tickOfficials();
    if (typeof paySalaries === 'function') paySalaries();
    // 敌国每年外交自然恢复
    state.nations.forEach(n => { state.diplomacy[n.id] = (state.diplomacy[n.id] || 0); state.diplomacy[n.id] = Math.min(100, state.diplomacy[n.id] + 3); });
    // v4 大改：年度大事
    if (typeof yearlyOfficials === 'function') yearlyOfficials();
}

// ====== 皇储 ======
function checkPrinceBirth() {
    if (state.princes.length === 0) { ensureFirstPrince(); return; }
    if (Math.random() < 0.4) {
        const g = PRINCE_GIVEN[Math.floor(Math.random() * PRINCE_GIVEN.length)];
        const c = PRINCE_CHAR[Math.floor(Math.random() * PRINCE_CHAR.length)];
        const ab = 30 + Math.floor(Math.random() * 70);
        state.princes.push({ name: '朱' + g, char: c, ability: ab, age: 1, crown: false });
        log(`后宫喜讯：皇子「朱${g}」诞生。`);
    }
}
function ensureFirstPrince() {
    if (state.princes.length > 0) return;
    const g = PRINCE_GIVEN[Math.floor(Math.random() * PRINCE_GIVEN.length)];
    const c = PRINCE_CHAR[Math.floor(Math.random() * PRINCE_CHAR.length)];
    const ab = 40 + Math.floor(Math.random() * 55);
    state.princes.push({ name: '朱' + g, char: c, ability: ab, age: 1, crown: false });
}
function agePrinces() { state.princes.forEach(p => p.age++); }
function setHeir(idx) {
    if (!state.princes[idx]) return;
    const old = state.princes.findIndex(p => p.crown);
    if (old >= 0) state.princes[old].crown = false;
    state.princes[idx].crown = true;
    state.heir = idx;
    const p = state.princes[idx];
    if (p.ability >= 65) { state.prestige = Math.min(100, state.prestige + 5); log(`立贤储君「${p.name}」声望更隆。`, 'good'); }
    else { state.stability = Math.min(100, state.stability + 3); log(`循例立长「${p.name}」，朝局稳固。`); }
    const others = state.princes.filter((_, i) => i !== idx);
    if (others.length > 0) { updateFaction('royal', -3, 0); log('未被立储的皇子心怀不满，宗室微恙。', 'warn'); }
}
function enfeoffPrince(idx) {
    if (!state.princes[idx]) return;
    const p = state.princes[idx];
    updateFaction('royal', 2, 3);
    log(`皇子「${p.name}」就藩之国，宗室拱卫愈固。`);
    if (p.crown) { state.princes[idx].crown = false; state.heir = null; }
}

// ====== 派系 / 胜负 ======
function checkFactionThresholds() {
    state.factions.forEach(f => {
        if (f.satisfaction < 20 && FACTION_EVENTS[f.id] && FACTION_EVENTS[f.id].lowSat) {
            const ev = FACTION_EVENTS[f.id].lowSat;
            if (f.id === 'military' && Math.random() < 0.5) {
                applyEffects({ militaryPower: -500, stability: -5 });
                log(`【兵变】${f.name}军心崩溃，部分兵将哗变劫掠州县！`, 'danger');
            } else { log(`【${ev.name}】${ev.desc}`, 'warn'); applyEffects(ev.effects); }
            f.satisfaction = 25;
        }
        if (f.influence > 80 && FACTION_EVENTS[f.id] && FACTION_EVENTS[f.id].highInf) {
            const ev = FACTION_EVENTS[f.id].highInf;
            log(`【${ev.name}】${ev.desc}`, 'warn'); applyEffects(ev.effects);
            f.influence = 75;
        }
        if ((f.id === 'eunuch' || f.id === 'consort') && f.influence > 90) {
            const fail = f.id === 'eunuch' ? FAIL_THRESHOLDS.eunuchOver90 : FAIL_THRESHOLDS.consortOver90;
            triggerGameOver(fail.type, fail.desc);
        }
    });
}
function checkVictoryDefeat() {
    if (state.mandate <= 0) { triggerGameOver('mandate_end', FAIL_THRESHOLDS.mandate0.desc); return; }
    if (state.stability <= 0) { triggerGameOver('stability_end', FAIL_THRESHOLDS.stability0.desc); return; }
    if (state.food < 0 && state.stability < 20) { triggerGameOver('peasant_end', FAIL_THRESHOLDS.peasantRevolt.desc); return; }
    if (state.stability > 80 && state.prestige > 80 && state.mandate > 80) {
        state.prosperityYears++;
        if (state.prosperityYears >= 10) { triggerVictory('yongleProsperity', VICTORY_CONDITIONS.yongleProsperity.name); return; }
    } else state.prosperityYears = 0;
    if (state.stability < 30) state.wasLowStability = true;
    if (state.wasLowStability && state.stability > 70) {
        state.revivalYears++;
        if (state.revivalYears >= 5) triggerVictory('revival', VICTORY_CONDITIONS.revival.name);
    } else if (state.stability <= 70) state.revivalYears = 0;
    // 万国来朝：所有邻国/朝贡国外交>50 且无战事
    const allGood = state.nations.every(n => (state.diplomacy[n.id] || 0) > 50 && !state.currentWars[n.id]);
    if (allGood) triggerVictory('allComeToCourt', VICTORY_CONDITIONS.allComeToCourt.name);
}
function triggerGameOver(failType, desc) {
    if (state.gameOver) return;
    state.gameOver = true; state.victory = false;
    log(`【亡国】${desc}`, 'danger');
    recordEnding(failType); saveGame();
}
function triggerVictory(winId, name) {
    if (state.gameOver) return;
    state.gameOver = true; state.victory = true;
    log(`【盛世】${name} —— 大明万年！`, 'good');
    recordEnding('victory'); saveGame();
}

// ====== 府部 ======
function initDeptHeads() {
    if (Object.keys(state.deptHeads).length > 0) return;
    DEPARTMENTS.forEach(d => state.deptHeads[d.id] = blankDeptHead());
    // 随机给 4 个府部配上人
    const sample = [...DEPARTMENTS].sort(() => Math.random() - 0.5).slice(0, 4);
    sample.forEach(d => state.deptHeads[d.id] = { name: ['王守仁','严嵩','于谦','张居正','李景隆','胡宗宪','戚继光','杨荣','徐阶','王振'][Math.floor(Math.random()*10)], ability: 40 + Math.floor(Math.random()*50), loyalty: 50 + Math.floor(Math.random()*30), faction: ['civil','military','eunuch','consort'][Math.floor(Math.random()*4)] });
}
function appointHead(deptId, name) {
    if (!state.deptHeads[deptId]) return;
    const ab = 30 + Math.floor(Math.random() * 60);
    const loy = 50 + Math.floor(Math.random() * 30);
    state.deptHeads[deptId] = { name: name || state.deptHeads[deptId].name, ability: ab, loyalty: loy, faction: 'civil' };
    log(`任命${DEPARTMENTS.find(d=>d.id===deptId).name}主官：${state.deptHeads[deptId].name}。`);
}

// ====== 将领 / 部队 / 行军 / 战斗 ======
function recruitGeneral() {
    const given = GENERAL_GIVEN[Math.floor(Math.random() * GENERAL_GIVEN.length)];
    const style = GENERAL_STYLE[Math.floor(Math.random() * GENERAL_STYLE.length)];
    const ab = 30 + Math.floor(Math.random() * 60);
    const fac = ['civil','military','eunuch'][Math.floor(Math.random()*3)];
    const g = makeGeneral('朱' + given, style, ab, fac);
    state.generals.push(g);
    log(`新将投效：「${g.name}」${g.style}（能${g.ability}）。`, 'good');
}
function ensureGenerals() {
    if (state.generals.length >= 4) return;
    while (state.generals.length < 4) recruitGeneral();
}
function raiseArmy(unitType, count) {
    const ut = UNIT_TYPES[unitType]; if (!ut) return null;
    count = Math.max(100, count);
    const cost = Math.ceil(count / 1000) * ut.cost * 5; // 训练期一次性成本
    if (state.treasury < cost) { log(`国库不足，无法建军。`, 'warn'); return null; }
    state.treasury -= cost;
    const name = ut.name + '营' + (state.armies.length + state.drafts.length + 1);
    const days = 180; // 半年训练
    state.drafts.push({ name, unitType, count, daysLeft: days });
    log(`新募${name} ${count}人，征训中。`);
    return true;
}
function assignGeneralToArmy(armyId, generalId) {
    const a = state.armies.find(x => x.id === armyId); if (!a) return;
    const g = state.generals.find(x => x.id === generalId); if (!g) return;
    if (a.general) { a.general.commanding = null; a.general.status = 'free'; }
    a.general = g; g.commanding = armyId; g.status = 'commanding';
}
function unassignGeneral(armyId) {
    const a = state.armies.find(x => x.id === armyId); if (!a || !a.general) return;
    a.general.commanding = null; a.general.status = 'free'; a.general = null;
}
function moveArmy(armyId, targetProvinceId) {
    const a = state.armies.find(x => x.id === armyId); if (!a || a.status !== 'ready') return;
    if (!a.origin) a.origin = 'shunTian';
    const days = marchDaysBetween(a.origin, targetProvinceId) * 30;
    a.status = 'marching';
    a.march = { from: a.origin, to: targetProvinceId, daysLeft: days, total: days };
    state.militaryPower -= a.count; // 离开京师
    log(`「${a.name}」自${nameOfProvince(a.origin)}出发，奔袭${nameOfProvince(targetProvinceId)}（${days}日）。`);
}
function nameOfProvince(id) {
    const p = state.provinces.find(x => x.id === id); return p ? p.name : id;
}
function tickMarches() {
    state.armies.forEach(a => {
        if (a.status !== 'marching' || !a.march) return;
        a.march.daysLeft -= 90;
        if (a.march.daysLeft <= 0) {
            a.origin = a.march.to;
            a.status = 'ready';
            a.march = null;
            state.militaryPower += a.count; // 到达
            log(`「${a.name}」抵达${nameOfProvince(a.origin)}。`);
        }
    });
}
// 战斗公式
function computePower(army) {
    const ut = UNIT_TYPES[army.unitType];
    const gen = army.general;
    const atkBase = army.count * (ut.atk / 10) * (army.training / 100) * (army.morale / 100);
    const defBase = army.count * (ut.def / 10) * (army.training / 100) * (army.morale / 100);
    const atk = atkBase * (gen ? (1 + gen.stats.attack / 200) : 1);
    const def = defBase * (gen ? (1 + gen.stats.defense / 200) : 1);
    return { atk, def };
}
// 玩家对敌国某省发动进攻
function attackProvince(nationId, provinceIdx, armyIds) {
    const nation = state.nations.find(n => n.id === nationId); if (!nation) return;
    const target = nation.provinces[provinceIdx]; if (!target) return;
    const myArmies = armyIds.map(id => state.armies.find(a => a.id === id)).filter(Boolean);
    if (myArmies.length === 0) return;
    // 聚合
    const myCount = myArmies.reduce((s, a) => s + a.count, 0);
    const myAtk = myArmies.reduce((s, a) => s + computePower(a).atk, 0);
    const myDef = myArmies.reduce((s, a) => s + computePower(a).def, 0);
    // 守军（敌国总军力按 AI persona 比例分配到该省）
    const guard = Math.round(nation.military * 0.3);
    const enemyAtk = guard * 0.8; // 守城
    const enemyDef = guard * 1.5;
    // 战损
    const myLoss = Math.round(myCount * Math.min(0.5, (enemyAtk / (myAtk + enemyDef || 1))));
    const enLoss = Math.round(guard * Math.min(0.7, (myAtk / (myAtk + enemyDef || 1))));
    // 分配
    let remainLoss = myLoss;
    myArmies.forEach(a => { const l = Math.floor(a.count / myCount * myLoss); a.count = Math.max(0, a.count - l); a.morale = Math.max(20, a.morale - 15); });
    state.militaryPower = Math.max(0, state.militaryPower - myLoss);
    nation.military = Math.max(0, nation.military - enLoss);
    state.diplomacy[nationId] = (state.diplomacy[nationId] || 0) - 20;
    state.currentWars[nationId] = (state.currentWars[nationId] || 0) + 1;
    state.battleLog.unshift({ year: state.year, season: SEASONS[state.season-1], target: target.name, myLoss, enLoss });
    if (state.battleLog.length > 30) state.battleLog.pop();
    log(`【攻伐】攻${target.name}：歼敌${enLoss}，我军伤亡${myLoss}。`, 'warn');
    // 胜负判定
    if (enLoss >= guard * 0.5) {
        // 占领
        nation.provinces.splice(provinceIdx, 1);
        log(`我军攻克「${target.name}」！`, 'good');
        // 灭国判定
        if (nation.provinces.length === 0) { log(`【灭国】${nation.name}既亡！`, 'good'); nation.military = 0; state.diplomacy[nationId] = -100; triggerVictory('driveOutTartar', `灭${nation.name}：${VICTORY_CONDITIONS.driveOutTartar.name}`); }
    }
    // 溃败
    myArmies.forEach(a => { if (a.count === 0) { a.status = 'dead'; a.general && (a.general.status = 'wounded'); }});
    state.armies = state.armies.filter(a => a.status !== 'dead');
}

// ====== 间谍 ======
function dispatchSpy(nationId, opId) {
    const op = SPY_OPS.find(o => o.id === opId); if (!op) return;
    const cost = op.cost;
    if (state.treasury < cost) { log(`国库不足，无法派遣。`, 'warn'); return; }
    const nation = state.nations.find(n => n.id === nationId); if (!nation) return;
    state.treasury -= cost;
    const mission = { id:'m_'+Date.now()+'_'+Math.floor(Math.random()*1000), nationId, opId, daysLeft: op.dur * 90, total: op.dur * 90, success: null };
    state.spyMissions.push(mission);
    state.diplomacy[nationId] = (state.diplomacy[nationId] || 0) - (op.id === 'assassinate' ? 10 : 5);
    log(`已派遣【${op.name}】至${nation.name}，预计${op.dur}季完成。`);
}
function tickSpies() {
    const remain = [];
    state.spyMissions.forEach(m => {
        m.daysLeft -= 90;
        if (m.daysLeft <= 0) {
            const op = SPY_OPS.find(o => o.id === m.opId);
            const nation = state.nations.find(n => n.id === m.nationId);
            const success = Math.random() < (1 - op.risk + (state.myIntel - nation.gov.intelPower) / 200);
            if (success) {
                log(`【谍报】对${nation.name}的「${op.name}」成功！`, 'good');
                if (m.opId === 'recon') state.myIntel = Math.min(100, state.myIntel + 8);
                if (m.opId === 'bribe') nation.gov.ministersLeft = Math.max(1, nation.gov.ministersLeft - 1);
                if (m.opId === 'sabotage') nation.military = Math.max(0, nation.military - 500);
                if (m.opId === 'assassinate') { nation.gov.ministersLeft = Math.max(0, nation.gov.ministersLeft - 2); nation.aggression = Math.max(0, nation.aggression - 10); }
                if (m.opId === 'counter') { state.myIntel = Math.min(100, state.myIntel + 12); nation.gov.intelPower = Math.max(10, nation.gov.intelPower - 5); }
            } else {
                log(`【谍报】对${nation.name}的「${op.name}」失败，线人折损。`, 'warn');
                state.myIntel = Math.max(0, state.myIntel - 5);
            }
        } else remain.push(m);
    });
    state.spyMissions = remain;
}

// ====== 市肆（10 类商品买卖） ======
function refreshMarketPrices() {
    GOODS.forEach(g => { const v = (Math.random() * 0.5 + 0.75); state.goodsPrices[g.id] = Math.round(g.base * v); });
}
function buyGood(id, qty) {
    const g = GOODS.find(x => x.id === id); if (!g) return;
    const price = state.goodsPrices[id] || g.base;
    const cost = price * qty;
    if (state.treasury < cost) { log(`国库不足。`, 'warn'); return; }
    state.treasury -= cost;
    state.market[id] = (state.market[id] || 0) + qty;
    if (id === 'grain') state.food += qty;
    if (id === 'iron' || id === 'cannon') state.militaryPower += Math.floor(qty / 100);
    log(`采买${g.name}${qty}${g.unit}（${cost}银）。`);
}
function sellGood(id, qty) {
    const g = GOODS.find(x => x.id === id); if (!g) return;
    if ((state.market[id] || 0) < qty) { log(`库存不足。`, 'warn'); return; }
    const price = state.goodsPrices[id] || g.base;
    const rev = Math.floor(price * qty * 0.9);
    state.market[id] -= qty;
    state.treasury += rev;
    log(`卖出${g.name}${qty}${g.unit}（得${rev}银）。`);
}

// ====== AI 敌国 ======
function tickAI() {
    state.nations.forEach(n => {
        const persona = AI_BEHAVIORS[n.aiPersona] || AI_BEHAVIORS.aggressive;
        // 外交自然衰减 / 增长
        state.diplomacy[n.id] = (state.diplomacy[n.id] || 0);
        if (state.currentWars[n.id]) state.diplomacy[n.id] -= 5;
        // 朝贡
        if (Math.random() < persona.tributeProb && !state.currentWars[n.id]) {
            state.treasury += 200; state.prestige = Math.min(100, state.prestige + 2);
            log(`${n.name}遣使朝贡，进贡金银。`, 'good');
            state.diplomacy[n.id] = Math.min(100, state.diplomacy[n.id] + 3);
        }
        // 互市
        if (Math.random() < persona.tradeProb && !state.currentWars[n.id]) {
            state.treasury += 300; log(`${n.name}遣商互市，朝廷抽分。`, 'good');
            state.diplomacy[n.id] = Math.min(100, state.diplomacy[n.id] + 2);
        }
        // 进攻
        if (Math.random() < persona.attackProb && !state.currentWars[n.id]) {
            const borderCandidates = ['xuanFu','daTong','liaoDong','ningXia','ganSu','yunNan'].filter(id => state.provinces.find(p => p.id === id));
            if (borderCandidates.length > 0) {
                const target = borderCandidates[Math.floor(Math.random() * borderCandidates.length)];
                const loss = Math.min(state.militaryPower, 200 + Math.floor(Math.random() * 600));
                const stDam = 2 + Math.floor(Math.random() * 4);
                state.militaryPower = Math.max(0, state.militaryPower - loss);
                state.stability = Math.max(0, state.stability - stDam);
                state.currentWars[n.id] = (state.currentWars[n.id] || 0) + 1;
                log(`【边患】${n.name}袭扰${nameOfProvince(target)}，损兵${loss}，稳定-${stDam}。`, 'danger');
                n.military = Math.max(0, n.military - Math.floor(loss * 0.7));
            }
        }
    });
}

// ====== 外交动作 ======
function improveDiplomacy(nationId, delta) {
    state.diplomacy[nationId] = Math.max(-100, Math.min(100, (state.diplomacy[nationId] || 0) + delta));
}
function declareWar(nationId) {
    state.diplomacy[nationId] = -100; state.currentWars[nationId] = (state.currentWars[nationId] || 0) + 1;
    log(`与${state.nations.find(n=>n.id===nationId).name}开战！`, 'warn');
}
function makePeace(nationId) {
    state.diplomacy[nationId] = 0; state.currentWars[nationId] = 0;
    log(`与${state.nations.find(n=>n.id===nationId).name}议和。`);
}

// ====== 新游戏 / 初始化 ======
function newGame() {
    const fresh = {
        year: 1, season: 1, treasury: 10000, food: 5000,
        stability: 60, prestige: 50, militaryPower: 8000, mandate: 70,
        factions: JSON.parse(JSON.stringify(FACTIONS)),
        currentMemorials: [], log: [], gameOver: false, victory: null,
        prosperityYears: 0, revivalYears: 0, wasLowStability: false,
        scholar: SCHOLAR_LIST[Math.floor(Math.random() * SCHOLAR_LIST.length)],
        policyChosen: false, chosenPolicy: null,
        projects: [], doneProjects: [],
        princes: [], heir: null,
        hazards: [], _recentMemorials: [],
        generals: [], armies: [], drafts: [],
        provinces: JSON.parse(JSON.stringify(PROVINCES_V3)),
        provinceGarrisonExtra: {},
        nations: JSON.parse(JSON.stringify(NATIONS)),
        spyMissions: [],
        myIntel: 50,
        deptHeads: {},
        goodsPrices: {},
        market: { grain:0,salt:0,iron:0,tea:0,silk:0,horse:0,cannon:0,porcelain:0,cotton:0,paper:0 },
        diplomacy: { mongolYuan:-30, oirat:-15, japan:0, korea:50, annam:20 },
        currentWars: {},
        battleLog: [],
        mapView: { x: 0, y: 0, scale: 1 },
        appointments: {}, officials: [], examQueue: [], customOffices: [], cabinetLog: [], immuneRetire: 0
    };
    Object.assign(state, fresh);
    ensureFirstPrince();
    initDeptHeads();
    initOfficials();
    ensureGenerals();
    refreshMarketPrices();
    // 给我方一支在京师的现成军团
    state.armies.push({ id:'army_init', name:'京营', unitType:'infantry', count:3000, general:null, morale:80, training:70, origin:'shunTian', status:'ready' });
    state.armies.push({ id:'army_cav', name:'三千营', unitType:'cavalry', count:1500, general:null, morale:80, training:75, origin:'shunTian', status:'ready' });
    state.armies.push({ id:'army_gun', name:'神机营', unitType:'gunner', count:1000, general:null, morale:80, training:80, origin:'shunTian', status:'ready' });
}

// ====================================================================
// v3 官员系统
// ====================================================================

// 生成官员
function makeOfficial(name, age, path) {
    const fam = ['王','李','张','刘','陈','杨','赵','黄','周','吴','徐','孙','胡','朱','高','林','何','郭','马','罗','梁','宋','郑','谢','韩','唐','冯','于','董','萧','程','曹','袁','邓','许','傅','沈','曾','彭','吕','苏','卢','蒋','蔡','贾','丁','魏','薛','叶','阎','余','潘','杜','戴','夏','钟','汪','田','任','姜','范','方','石','姚','谭','廖','邹','熊','金','陆','郝','孔','白','崔','康','毛','邱','秦','江','史','顾','侯','邵','孟','龙','万','段','雷','钱','汤','尹','黎','易','常','武','乔','贺','赖','龚','文'];
    const given = ['守仁','景略','梦得','孟起','季长','元凯','子昂','君禹','彦霖','季和','彦章','君道','景仁','明远','彦升','季长','景阳','仲平','德辉','子固','君远','孟安','彦文','德润','君实','孟坚','景升','季和','君道','伯仁','彦英','君直','景云','彦修','君正','梦得','子昂','君肃','明远','仲礼','德元','景升','君直','孟之','彦柔','伯伦','君厚','子诚','仲孚','德彰','景行','君达','季藩','彦明','君信','孟远','子坚'];
    if (!name) name = fam[Math.floor(Math.random() * fam.length)] + given[Math.floor(Math.random() * given.length)];
    const faction = path === 'keju' ? 'civil' : path === 'yinfeng' ? 'royal' : (Math.random() < 0.5 ? 'civil' : 'military');
    const o = {
        id: 'off_' + Date.now() + '_' + Math.floor(Math.random() * 10000),
        name,
        age: age || (22 + Math.floor(Math.random() * 8)),
        path: path || 'keju',
        rank: 9, // 初授官品
        office: null,
        ability: 30 + Math.floor(Math.random() * 60),
        loyalty: 50 + Math.floor(Math.random() * 40),
        integrity: 50 + Math.floor(Math.random() * 50),
        reputation: 10 + Math.floor(Math.random() * 30),
        faction,
        merits: 0,
        flaws: 0,
        spouse: Math.random() < 0.5 ? fam[Math.floor(Math.random() * fam.length)] + '氏' : null,
        children: Math.floor(Math.random() * 3),
        health: 80 + Math.floor(Math.random() * 20),
        alive: true,
        deathCause: null,
        deathYear: null,
        retirements: 0,
        promotions: 0,
        demotions: 0,
        tasks: [],  // 派任记录
        gold: 200 + Math.floor(Math.random() * 500),
        lands: 0,
        since: state.year,
        notes: ''
    };
    return o;
}
function initOfficials() {
    if (state.officials.length > 0) return;
    // 初始 30 名官员，覆盖各类出身
    const paths = ['keju','keju','keju','jianju','yinfeng'];
    for (let i = 0; i < 30; i++) {
        state.officials.push(makeOfficial(null, 25 + Math.floor(Math.random() * 35), paths[i % paths.length]));
    }
    // 给内阁 / 六部 / 督抚 / 边镇 / 都指挥使 默认配人
    const defaultFill = ['c1','c2','c3','m1','m2','m3','m4','m5','m6','s1','a1','p1','p4','p6','l3'];
    defaultFill.forEach(offId => {
        const off = findOffice(offId);
        if (!off) return;
        const o = makeOfficial(null, 35 + Math.floor(Math.random() * 25), 'keju');
        o.rank = off.rank; o.office = offId; o.ability = 50 + Math.floor(Math.random() * 40);
        state.appointments[offId] = { officialId: o.id, since: state.year };
    });
    // 6 个布政使 / 6 个总兵 / 6 个按察使
    const pids = ['shunTian','heNan','shanDong','shaanXi','jiangNan','siChuan','zheJiang','jiangXi','huBei','fuJian','guangDong','yunNan'];
    pids.forEach(pid => {
        const o = makeOfficial(null, 30 + Math.floor(Math.random() * 30), 'keju');
        o.rank = 3; o.office = 'l3'; o.province = pid; o.ability = 45 + Math.floor(Math.random() * 40);
        state.appointments[pid + '_l3'] = { officialId: o.id, since: state.year };
    });
    const borderPids = ['xuanFu','daTong','liaoDong','ningXia','ganSu','yunNan'];
    borderPids.forEach(pid => {
        const o = makeOfficial(null, 30 + Math.floor(Math.random() * 30), 'keju');
        o.rank = 3; o.office = 'w4'; o.province = pid; o.ability = 50 + Math.floor(Math.random() * 35);
        state.appointments[pid + '_w4'] = { officialId: o.id, since: state.year };
    });
}
// 选官——三路九步完整流程
function recruitCandidate(pathId) {
    const p = ENTRY_PATHS.find(x => x.id === pathId); if (!p) return null;
    const o = makeOfficial(null, p.age + Math.floor(Math.random() * 12), pathId);
    o.merits = p.bonus;
    o.reputation = p.bonus * 2;
    o.notes = `${p.name}第${Math.floor(Math.random()*9)+1}步：${p.steps[0]}`;
    o.candProgress = 0;  // 选官进度（0..steps.length）
    o.path = pathId;
    state.officials.push(o);
    state.examQueue.push({ officialId: o.id, pathId, since: state.year });
    log(`新增候选官员：「${o.name}」（${p.name}，${o.age}岁）。`, 'good');
    return o;
}
function examProgress(officialId) {
    const q = state.examQueue.find(x => x.officialId === officialId); if (!q) return;
    const p = ENTRY_PATHS.find(x => x.id === q.pathId); if (!p) return;
    const off = state.officials.find(x => x.id === officialId); if (!off) return;
    off.candProgress = (off.candProgress || 0) + 1;
    off.notes = `${p.name}：${p.steps[off.candProgress - 1]}`;
    if (off.candProgress >= p.steps.length) {
        // 授官：按品级授最低知县 / 散官
        const rank = p.id === 'keju' ? 7 : p.id === 'jianju' ? 8 : 6;
        off.rank = rank;
        off.office = null; // 候缺
        state.examQueue = state.examQueue.filter(x => x.officialId !== officialId);
        log(`「${off.name}」三路九步走完，候选候缺。`, 'good');
    } else log(`「${off.name}」${p.steps[off.candProgress - 1]}（${off.candProgress}/${p.steps.length}）。`);
}
function assignOffice(officialId, officeId, opts) {
    const o = state.officials.find(x => x.id === officialId);
    const off = findOffice(officeId);
    if (!o || !off) return false;
    // 顶掉旧任
    Object.keys(state.appointments).forEach(k => { if (state.appointments[k] && state.appointments[k].officialId === officialId) delete state.appointments[k]; });
    // 顶掉该职位旧人
    const old = state.appointments[officeId];
    if (old) {
        const oldOff = state.officials.find(x => x.id === old.officialId);
        if (oldOff) { oldOff.office = null; }
    }
    o.office = officeId; o.rank = off.rank;
    o.since = state.year;
    if (opts && opts.province) o.province = opts.province;
    state.appointments[officeId] = { officialId: o.id, since: state.year };
    log(`拜「${o.name}」为【${off.name}】。`, 'good');
    return true;
}
function demoteOffice(officialId, reason) {
    const o = state.officials.find(x => x.id === officialId); if (!o || !o.office) return;
    const off = findOffice(o.office); if (!off) return;
    const next = off.next && off.next.length ? findOffice(off.next[0]) : null;
    if (next) { assignOffice(officialId, next.id); log(`贬「${o.name}」为【${next.name}】。${reason ? '（' + reason + '）' : ''}`, 'warn'); }
    else {
        delete state.appointments[o.office]; o.office = null;
        log(`罢「${o.name}」${off.name}，削职为民。${reason ? '（' + reason + '）' : ''}`, 'warn');
    }
    o.demotions++;
}
function retireOfficial(officialId, reason) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    if (o.office) delete state.appointments[o.office];
    o.office = null; o.retirements++; o.notes = reason || '致仕';
    log(`「${o.name}」${reason || '告老还乡'}，朝廷赐金币、归田。`, 'good');
}
function executeOfficial(officialId, reason) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    if (o.office) delete state.appointments[o.office];
    o.office = null; o.alive = false; o.deathCause = 'executed'; o.deathYear = state.year;
    log(`皇帝赐死「${o.name}」：${reason || '罪状昭彰'}。`, 'danger');
    state.stability = Math.max(0, state.stability - 1);
    state.mandate = Math.max(0, state.mandate - 1);
}
function banishOfficial(officialId, reason) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    if (o.office) delete state.appointments[o.office];
    o.office = null; o.notes = reason || '流放';
    log(`流「${o.name}」三千里。${reason || ''}`, 'warn');
}
// 丁忧（27 月）：父/母亡
function startMourning(officialId) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    if (o.office) delete state.appointments[o.office];
    o.office = null;
    o.mourning = 27; // 月
    log(`「${o.name}」丁忧去职，守丧二十七月。`, 'warn');
}
function endMourning(officialId) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    o.mourning = 0; o.notes = '服阕候补';
    log(`「${o.name}」服阕，候补原官。`);
}
// 自创官职
function createCustomOffice(name, cat, rank, salary, max, dept) {
    const c = { id: 'cst_' + Date.now() + '_' + Math.floor(Math.random() * 1000), name, cat, rank, salary, max, dept: dept || 'cabinet', desc:'玩家自创官职', next:[], isCustom:true };
    state.customOffices.push(c);
    log(`敕设新职：【${name}】。`, 'good');
    return c;
}
function grantTitle(officialId, title) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    o.title = title;
    log(`加「${o.name}」${title}衔。`, 'good');
}
function allOffices() { return OFFICES.concat(state.customOffices || []); }
function allOfficials() { return state.officials; }
function findOfficial(id) { return state.officials.find(x => x.id === id); }
function appointmentsOf(officeId) { return state.appointments[officeId]; }
function officialByOffice(officeId) {
    const a = state.appointments[officeId]; if (!a) return null;
    return findOfficial(a.officialId);
}
// 死亡 / 老死 / 致仕 季推
function tickOfficials() {
    const causes = ['old_age','disease','war','assassin','accident','plague','wound','unknown'];
    const assass = ['executed','imprison','beheaded','suicide','duel','imprison'];
    state.officials.forEach(o => {
        if (!o.alive) return;
        // 丁忧计时
        if (o.mourning) { o.mourning--; if (o.mourning === 0) endMourning(o.id); }
        // 升一年
        o.age++;
        // 致仕
        if (o.age >= RETIREMENT_AGE && o.office && state.immuneRetire === 0) {
            // 概率致仕
            if (Math.random() < 0.5) { retireOfficial(o.id, '年老致仕'); return; }
        }
        // 老死概率
        if (o.age >= MAX_AGE) { o.alive = false; o.deathCause='old_age'; o.deathYear = state.year; log(`「${o.name}」卒于京邸，享年${o.age}。`, 'warn'); return; }
        if (o.age >= 70 && Math.random() < 0.1) { o.alive = false; o.deathCause='old_age'; o.deathYear = state.year; log(`「${o.name}」年老病故。`, 'warn'); if (o.office) delete state.appointments[o.office]; return; }
        // 病故
        if (Math.random() < 0.02) { o.alive = false; o.deathCause='disease'; o.deathYear=state.year; log(`「${o.name}」病故。`, 'warn'); if (o.office) delete state.appointments[o.office]; return; }
        // 疫死
        if (Math.random() < 0.01) { o.alive = false; o.deathCause='plague'; o.deathYear=state.year; log(`「${o.name}」疫死。`, 'danger'); if (o.office) delete state.appointments[o.office]; return; }
        // 武将：阵亡
        if (o.office && (findOffice(o.office).dept === 'war' || findOffice(o.office).dept === 'jinyi' || findOffice(o.office).dept === 'east' || findOffice(o.office).dept === 'grand') && Math.random() < 0.015) {
            o.alive = false; o.deathCause='war'; o.deathYear=state.year; log(`「${o.name}」阵亡。`, 'danger'); if (o.office) delete state.appointments[o.office]; return;
        }
        // 刺杀
        if (Math.random() < 0.005) { o.alive = false; o.deathCause='assassin'; o.deathYear=state.year; log(`「${o.name}」被刺身亡。`, 'danger'); if (o.office) delete state.appointments[o.office]; return; }
        // 意外
        if (Math.random() < 0.003) { o.alive = false; o.deathCause='accident'; o.deathYear=state.year; log(`「${o.name}」意外身死。`, 'warn'); if (o.office) delete state.appointments[o.office]; return; }
        // 瘐死狱中
        if (o.imprisoned && Math.random() < 0.1) { o.alive = false; o.deathCause='imprison'; o.deathYear=state.year; log(`「${o.name}」瘐死诏狱。`, 'danger'); if (o.office) delete state.appointments[o.office]; return; }
        // 功过升降
        if (o.merits >= 5 && o.office && Math.random() < 0.2) { o.merits -= 5; o.promotions++; const off = findOffice(o.office); if (off && off.next && off.next.length) { const n = findOffice(off.next[0]); if (n) { assignOffice(o.id, n.id); log(`「${o.name}」功升【${n.name}】。`, 'good'); } } }
        if (o.flaws >= 5 && o.office && Math.random() < 0.2) { o.flaws -= 5; demoteOffice(o.id, '失职'); }
        // 资不重送：年龄>90 强制下野
        if (o.age > 90) { retireOfficial(o.id, '耄耋归田'); }
    });
}
// 玩家俸禄：每年从国库扣
function paySalaries() {
    const total = annualSalaryTotal();
    if (total > 0) {
        state.treasury = Math.max(0, state.treasury - total);
        log(`百官俸禄支出 ${total} 银。`, 'warn');
    }
}
// 任免：依朝政推进每季
function promotionReview() {
    // 内阁首辅若不称职/老迈，玩家可免
    // 这里是自动逻辑
}

// ====================================================================
// v4 大改：宫廷 / 天象 / 大典 / 科举 / 赏赐 / 流放 / 嫔妃 / 自创官职
// ====================================================================

// === 科举：完整流程（三路九步自动推） ===
function startExam(pathId, count) {
    count = count || 10;
    const p = ENTRY_PATHS.find(x => x.id === pathId);
    if (!p) return [];
    const newOnes = [];
    for (let i = 0; i < count; i++) {
        const o = makeOfficial(null, p.age + Math.floor(Math.random() * 12), pathId);
        o.merits = p.bonus;
        o.reputation = p.bonus * 2;
        o.notes = `${p.name}：${p.steps[0]}`;
        o.candProgress = 0;
        o.path = pathId;
        o.examStep = 0;
        state.officials.push(o);
        state.examQueue.push({ officialId: o.id, pathId, since: state.year });
        newOnes.push(o);
    }
    log(`开科取士：${p.name}，${count}人应试。`, 'good');
    return newOnes;
}
function autoAdvanceExam() {
    if (state.examQueue.length === 0) return;
    state.examQueue.forEach(q => examProgress(q.officialId));
}
// === 殿试排名 + 赐宴 ===
function finalExam(pathId) {
    const p = ENTRY_PATHS.find(x => x.id === pathId); if (!p) return null;
    const cands = state.officials.filter(o => o.path === pathId && (o.candProgress || 0) >= p.steps.length - 1 && !o.office);
    if (cands.length === 0) return null;
    const result = generateExamResult(pathId, cands);
    const top = result[0];
    top.examRank = '状元';
    if (result[1]) result[1].examRank = '榜眼';
    if (result[2]) result[2].examRank = '探花';
    result.forEach((c, i) => {
        if (i < 10) c.examRank = c.examRank || ('进士第' + (i + 1) + '名');
        c.merits = (c.merits || 0) + 10;
        c.reputation = (c.reputation || 0) + 20;
    });
    state.examResults.unshift({ year: state.year, path: p.name, top: top.name, count: cands.length });
    log(`【殿试】${p.name}：状元「${top.name}」等 ${cands.length} 人中式。`, 'good');
    log(`皇帝于奉天殿赐「${BANQUET_MENU[0]}」宴。`, 'good');
    return result;
}

// === 谥号追谥 ===
function grantPosthumous(officialId, name) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    o.posthumous = name;
    state.posthumous.push({ officialId, name, year: state.year });
    log(`追谥「${o.name}」为【${name}】。`, 'good');
}

// === 抄家 ===
function confiscate(officialId) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    if (o.office) { delete state.appointments[o.office]; o.office = null; }
    const tier = CONFISCATION_GAINS[Math.floor(Math.random() * CONFISCATION_GAINS.length)];
    const gain = tier.min + Math.floor(Math.random() * (tier.max - tier.min));
    state.treasury += gain;
    o.alive = false; o.deathCause = 'executed'; o.deathYear = state.year;
    state.courtierCases.push({ officialId, name: o.name, year: state.year, gain, label: tier.label });
    log(`【抄家】没收「${o.name}」家产，得 ${gain} 银（${tier.label}）。`, 'warn');
    return gain;
}

// === 流放 ===
function exile(officialId, place) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    if (o.office) { delete state.appointments[o.office]; o.office = null; }
    o.exiled = true;
    o.exilePlace = place || EXILE_PLACES[Math.floor(Math.random() * EXILE_PLACES.length)];
    state.banishments.push({ officialId, name: o.name, place: o.exilePlace, year: state.year });
    log(`流「${o.name}」于【${o.exilePlace}】。`, 'warn');
}
function recallFromExile(officialId) {
    const o = state.officials.find(x => x.id === officialId); if (!o || !o.exiled) return;
    o.exiled = false; o.exilePlace = null;
    log(`赦还「${o.name}」，复原官。`, 'good');
}

// === 赏赐 ===
function reward(officialId, typeId) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    const t = REWARD_TYPES.find(x => x.id === typeId); if (!t) return;
    if (state.treasury < t.cost) { log(`国库不足。`, 'warn'); return; }
    state.treasury -= t.cost;
    applyEffects(t.effect);
    o.merits = (o.merits || 0) + 3;
    state.rewards.push({ officialId, name: o.name, type: t.name, year: state.year });
    log(`【赏赐】赐「${o.name}」${t.name}。`, 'good');
}

// === 大典（祭天、封禅、南巡、北征） ===
function performCeremony(ceremonyId) {
    const c = GRAND_CEREMONIES.find(x => x.id === ceremonyId); if (!c) return;
    if (state.treasury < c.cost) { log(`国库不足，${c.name}暂停。`, 'warn'); return; }
    state.treasury -= c.cost;
    applyEffects(c.effects);
    state.ceremonies.push({ id: c.id, name: c.name, year: state.year, season: state.season });
    log(`【大典】${c.name}（${c.desc}）。`, 'good');
}

// === 天象 ===
function triggerCelestial() {
    if (Math.random() > 0.3) return; // 30% 概率
    const e = CELESTIAL_EVENTS[Math.floor(Math.random() * CELESTIAL_EVENTS.length)];
    state.celestial.push({ ...e, year: state.year, season: state.season });
    applyEffects(e.effects);
    const isBad = (e.effects.mandate || 0) + (e.effects.stability || 0) < 0;
    log(`【天象】${e.name}：${e.desc} ${e.advice}`, isBad ? 'warn' : 'good');
}

// === 嫔妃系统 ===
function addConcubine(rank) {
    const r = CONCUBINE_RANKS.find(x => x.id === rank);
    if (!r) return null;
    if (state.concubines.filter(c => c.rank === rank).length >= r.max) { log(`${r.name}位已满。`, 'warn'); return null; }
    const family = CONCUBINE_FAMILY[Math.floor(Math.random() * CONCUBINE_FAMILY.length)];
    const given = CONCUBINE_GIVEN[Math.floor(Math.random() * CONCUBINE_GIVEN.length)];
    const c = {
        id: 'c_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
        name: family + '氏·' + given,
        rank, rankName: r.name,
        beauty: 50 + Math.floor(Math.random() * 50),
        family: family,
        sonCount: 0,
        favored: 50,
        age: 16 + Math.floor(Math.random() * 8),
        inPalace: state.year
    };
    state.concubines.push(c);
    log(`册封【${c.name}】为${r.name}。`, 'good');
    return c;
}
function favorConcubine(id, delta) {
    const c = state.concubines.find(x => x.id === id); if (!c) return;
    c.favored = Math.max(0, Math.min(100, c.favored + delta));
    if (delta > 0) log(`皇帝召幸【${c.name}】。`, 'good');
}

// === 皇帝赐爵 / 赐谥 / 联姻 ===
function grantNobleTitle(officialId, title) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    o.nobleTitle = title;
    log(`封「${o.name}」为${title}爵。`, 'good');
}
function marryOfficial(officialId, princessIdx) {
    const o = state.officials.find(x => x.id === officialId); if (!o) return;
    const p = state.princes[princessIdx];
    if (!p) return;
    o.marriedTo = p.name;
    p.married = true;
    state.princesMarriages.push({ officialId, name: o.name, princess: p.name, year: state.year });
    log(`以皇女「${p.name}」下嫁「${o.name}」。`, 'good');
    updateFaction('civil', 3, 2);
}

// === 内阁廷推（重要政事投票） ===
function startCourtVote() {
    const topic = COURT_VOTE_TOPICS[Math.floor(Math.random() * COURT_VOTE_TOPICS.length)];
    state._currentVote = topic;
    log(`【廷推】群臣议「${topic.title}」：${topic.desc}`, 'good');
    return topic;
}
function decideVote(optionIdx) {
    if (!state._currentVote) return;
    const opt = state._currentVote.options[optionIdx];
    if (!opt) return;
    applyEffects(opt.effects);
    log(`皇帝裁定「${state._currentVote.title}」：${opt.text}。`, 'good');
    state._currentVote = null;
}

// === 自创官职（更复杂） ===
function createCustomOfficeDetailed(name, cat, rank, salary, max, dept) {
    const c = {
        id: 'cst_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
        name, cat, rank, salary, max, dept: dept || 'cabinet',
        desc: '敕设：' + name,
        next: [],
        isCustom: true
    };
    state.customOffices.push(c);
    log(`敕设新职：【${name}】（${cat}，正${['一','二','三','四','五','六','七','八','九'][rank-1]}品）。`, 'good');
    return c;
}
function abolishOffice(officeId) {
    // 找该官职的当前任职
    const a = state.appointments[officeId];
    if (a) {
        const o = state.officials.find(x => x.id === a.officialId);
        if (o) { o.office = null; }
        delete state.appointments[officeId];
    }
    // 从自创官职中删除
    const idx = state.customOffices.findIndex(x => x.id === officeId);
    if (idx >= 0) {
        log(`裁撤【${state.customOffices[idx].name}】。`, 'warn');
        state.customOffices.splice(idx, 1);
    } else {
        // 标内置官职为废
        log(`裁撤内置官职：${officeId}（标记为废）。`, 'warn');
    }
}

// === 抄家产 / 没收案件 ===
function doConfiscate(officialId) {
    return confiscate(officialId);
}

// === 帝王起居 / 批红 / 赐膳 ===
function imperialAct(action) {
    state.imperialActs.unshift({ action, year: state.year, season: state.season });
    if (state.imperialActs.length > 50) state.imperialActs.pop();
    log(`皇帝${action}。`);
}

// === 廷试 / 殿试 题目与结果 ===
function holdExamTopic(pathId) {
    const q = EXAM_QUESTIONS[Math.floor(Math.random() * EXAM_QUESTIONS.length)];
    log(`【${pathId === 'keju' ? '殿试' : '廷试'}】策论题：${q.q}`, 'good');
    return q;
}

// === 战争大臣调度 ===
function dispatchGeneralToWar(generalId, warNationId) {
    const g = state.generals.find(x => x.id === generalId); if (!g) return;
    g.onCampaign = warNationId;
    log(`遣「${g.name}」率军赴${warNationId}。`, 'good');
}

// === 帝王勤政评分 ===
function getImperialScore() {
    let s = 0;
    if (state.stability > 60) s += 10;
    if (state.prestige > 60) s += 10;
    if (state.mandate > 60) s += 10;
    if (state.treasury > 5000) s += 5;
    if (state.food > 3000) s += 5;
    return s;
}

// === 每年天象随机发生 ===
function yearlyCelestial() {
    triggerCelestial();
}

// === 戏剧性事件 ===
function triggerEpicEvent() {
    if (Math.random() > 0.4) return; // 40% 概率
    const candidates = EPIC_EVENTS.filter(e => state.year >= (e.trigger.yearMin || 0) && state.year <= (e.trigger.yearMax || 99));
    if (candidates.length === 0) return;
    const e = candidates[Math.floor(Math.random() * candidates.length)];
    if (state._epicShown && state._epicShown[e.id]) return;
    state._epicShown = state._epicShown || {};
    state._epicShown[e.id] = true;
    applyEffects(e.effects);
    log(`【${e.title}】${e.desc}`, 'warn');
}

// === 自动科举：每 3 年一次 ===
function autoRunExam() {
    if (state.year % 3 !== 0) return;
    startExam('keju', 8);
    autoAdvanceExam();
    finalExam('keju');
}

// === 帝王内廷生活（按季） ===
function seasonalConcubine() {
    // 后宫随机事件
    if (state.concubines.length === 0) {
        if (Math.random() < 0.5) addConcubine('pin');
    } else {
        if (Math.random() < 0.2) {
            // 册封新人
            const ranks = ['fei','pin','guifei','changzai','daying'];
            addConcubine(ranks[Math.floor(Math.random() * ranks.length)]);
        } else if (Math.random() < 0.1 && state.concubines.length > 0) {
            // 怀孕 / 生育
            const c = state.concubines[Math.floor(Math.random() * state.concubines.length)];
            c.sonCount++;
            log(`【内廷】${c.name}诞育皇子。`, 'good');
        }
    }
}

// === 推进一年的官员更替（科举 / 天象 / 戏剧事件） ===
function yearlyOfficials() {
    autoRunExam();
    yearlyCelestial();
    triggerEpicEvent();
    seasonalConcubine();
}

// === 改写 annualSettlement 加入新功能 ===
function annualSettlementV4() {
    if (typeof yearlyOfficials === 'function') yearlyOfficials();
}
