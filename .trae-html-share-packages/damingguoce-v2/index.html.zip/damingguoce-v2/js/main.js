// ====================================================================
// 《大明国策 v2》启动与初始化
// ====================================================================
function initGame() {
    if (typeof renderAccountList === 'function') renderAccountList();
    if (getCurrentUser()) {
        const loaded = loadGame();
        if (!loaded) newGame();
        // 兼容旧存档
        if (!state.scholar) state.scholar = (typeof SCHOLAR_LIST !== 'undefined') ? SCHOLAR_LIST[Math.floor(Math.random() * SCHOLAR_LIST.length)] : '儒家';
        if (!Array.isArray(state.projects)) state.projects = [];
        if (!Array.isArray(state.doneProjects)) state.doneProjects = [];
        if (!Array.isArray(state.princes)) state.princes = [];
        if (!Array.isArray(state.generals)) state.generals = [];
        if (!Array.isArray(state.armies)) state.armies = [];
        if (!Array.isArray(state.drafts)) state.drafts = [];
        if (!Array.isArray(state.spyMissions)) state.spyMissions = [];
        if (!state.diplomacy) state.diplomacy = {};
        if (!state.market) state.market = { grain:0,salt:0,iron:0,tea:0,silk:0,horse:0,cannon:0,porcelain:0,cotton:0,paper:0 };
        if (!state.deptHeads) state.deptHeads = {};
        if (!state.goodsPrices) state.goodsPrices = {};
        if (!Array.isArray(state.nations) || !state.nations.length) state.nations = JSON.parse(JSON.stringify(NATIONS));
        if (!Array.isArray(state.provinces) || !state.provinces.length) state.provinces = JSON.parse(JSON.stringify(PROVINCES));
        if (!state.mapView) state.mapView = { x:0, y:0, scale:1 };
        document.getElementById('app').classList.remove('hide');
        if (!state.princes.length && typeof ensureFirstPrince === 'function') ensureFirstPrince();
        if (!Object.keys(state.deptHeads).length && typeof initDeptHeads === 'function') initDeptHeads();
        if (!state.generals.length && typeof ensureGenerals === 'function') ensureGenerals();
        if (!Object.keys(state.goodsPrices).length && typeof refreshMarketPrices === 'function') refreshMarketPrices();
        log(`欢迎回来，${getCurrentUser()}。`);
        refreshAllUI();
        switchTab('court');
        updateSeasonButton();
    } else {
        document.getElementById('app').classList.add('hide');
        document.getElementById('loginOverlay').classList.remove('hide');
        setAuthTab('login');
    }
    renderAccountList();
}
window.onload = initGame;
window.addEventListener('beforeunload', () => {
    if (typeof saveGame === 'function' && getCurrentUser()) saveGame();
});
