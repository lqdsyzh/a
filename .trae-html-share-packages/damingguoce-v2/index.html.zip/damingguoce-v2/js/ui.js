// ====================================================================
// 《大明国策 v2》UI
// 顶栏 / 八大面板 / 地图 / 弹窗 / 府部 / 市肆 / 部队 / 间谍 / 敌国
// ====================================================================

// ====== 顶栏 ======
function updateTopBar() {
    document.getElementById('yearDisplay').textContent = `永乐${state.year}年`;
    document.getElementById('seasonDisplay').textContent = `· ${SEASONS[state.season-1]}`;
    document.getElementById('treasury').textContent = state.treasury;
    document.getElementById('food').textContent = state.food;
    document.getElementById('stability').textContent = state.stability;
    document.getElementById('prestige').textContent = state.prestige;
    document.getElementById('militaryPower').textContent = state.militaryPower;
    document.getElementById('mandate').textContent = state.mandate;
}
function updateSeasonButton() {
    const btn = document.getElementById('btnYear');
    if (!btn) return;
    if (state.gameOver) { btn.disabled = true; btn.textContent = state.victory ? '盛世已成' : '国祚已断'; return; }
    const sn = SEASONS[state.season - 1];
    btn.textContent = `开启${sn}季朝议`; btn.disabled = false;
}

// ====== 派系 ======
function renderFactionPanel() {
    const c = document.getElementById('factionList'); if (!c) return;
    let html = '';
    state.factions.forEach(f => {
        const satCls = f.satisfaction < 30 ? 'faction-sat-low' : 'faction-sat';
        const infCls = f.influence > 70 ? 'faction-inf-high' : 'faction-inf';
        const a1 = f.satisfaction < 20 ? '<span style="color:#e06060;font-size:9px;">⚠ 动乱</span>' : '';
        const a2 = f.influence > 80 ? '<span style="color:#e0d080;font-size:9px;">⚠ 专权</span>' : '';
        html += `<div class="faction-block">
            <div class="faction-bar"><div class="faction-name">${f.name}</div>
                <div class="faction-bar-track" title="满意度"><div class="faction-bar-fill ${satCls}" style="width:${f.satisfaction}%"></div></div>
                <span style="font-size:10px;min-width:28px;text-align:right;">${f.satisfaction}</span>${a1}</div>
            <div class="faction-bar"><div class="faction-name">影响力</div>
                <div class="faction-bar-track" title="影响力"><div class="faction-bar-fill ${infCls}" style="width:${f.influence}%"></div></div>
                <span style="font-size:10px;min-width:28px;text-align:right;">${f.influence}</span>${a2}</div>
            <div class="desc">${f.desc}</div>
        </div>`;
    });
    c.innerHTML = html;
}
function renderFactionAlert() {
    const c = document.getElementById('factionAlert'); if (!c) return;
    let html = '';
    state.factions.forEach(f => {
        if (f.satisfaction < 20) html += `<div class="alert">${f.name}满意度极低（${f.satisfaction}），可能引发动乱！</div>`;
        if (f.influence > 80) html += `<div class="alert warn">${f.name}影响力过高（${f.influence}），有专权之虞！</div>`;
    });
    c.innerHTML = html;
}
function renderFactionPanelMini() {
    let html = '<div class="row" style="margin-top:6px;">';
    state.factions.forEach(f => {
        const satCls = f.satisfaction < 30 ? 'danger' : '';
        html += `<div class="stat-box ${satCls}"><l>${f.name}</l><s>${f.satisfaction}</s></div>`;
    });
    return html + '</div>';
}
function renderOverview() {
    const c = document.getElementById('overviewContent'); if (!c) return;
    const stCls = state.stability <= 30 ? 'danger' : (state.stability >= 80 ? 'good' : '');
    const prCls = state.prestige <= 30 ? 'danger' : '';
    const mnCls = state.mandate <= 20 ? 'danger' : '';
    const fkCls = state.food < 0 ? 'danger' : '';
    const trCls = state.treasury < 1000 ? 'warn' : '';
    const princeInfo = state.princes.length
        ? state.princes.map(p => `${p.name}（${p.char}${p.crown?'·太子':''} 能${p.ability}）`).join('　')
        : '尚无皇子';
    c.innerHTML = `
        <div class="row">
            <div class="stat-box ${trCls}"><l>国库</l><s>${state.treasury}</s></div>
            <div class="stat-box ${fkCls}"><l>粮食</l><s>${state.food}</s></div>
            <div class="stat-box ${stCls}"><l>稳定</l><s>${state.stability}</s></div>
            <div class="stat-box ${prCls}"><l>威望</l><s>${state.prestige}</s></div>
            <div class="stat-box"><l>军力</l><s>${state.militaryPower}</s></div>
            <div class="stat-box ${mnCls}"><l>天命</l><s>${state.mandate}</s></div>
            <div class="stat-box"><l>情报</l><s>${state.myIntel}</s></div>
            <div class="stat-box"><l>军队</l><s>${state.armies.length}</s></div>
        </div>
        <h4>当朝首辅学派</h4>
        <div style="font-size:11px;color:#a0c8ff;">【${state.scholar}】— ${SCHOLAR_CAUTION[state.scholar] || ''}</div>
        <h4>势力平衡</h4>
        <div>${renderFactionPanelMini()}</div>
        <h4>宗室子嗣</h4>
        <div style="font-size:11px;color:#6a9ad5;">${princeInfo}</div>
        <h4>在位进度</h4>
        <div style="font-size:11px;color:#6a9ad5;line-height:1.7;">
            永乐盛世：${state.prosperityYears}/10 年　·　中兴之主：${state.revivalYears}/5 年${state.wasLowStability ? '（已历经低谷）' : '（未触发）'}
        </div>`;
}

// ====== 日志 ======
function renderLog() {
    const c = document.getElementById('logPanel'); if (!c) return;
    if (state.log.length === 0) { c.innerHTML = '<p style="color:#5a7a9f;">暂无日志。</p>'; return; }
    c.innerHTML = state.log.map(l => {
        const cls = l.level === 'danger' ? 'style="color:#e06060;"'
                  : l.level === 'warn'    ? 'style="color:#e0d080;"'
                  : l.level === 'good'    ? 'style="color:#80e080;"' : '';
        return `<div class="log-entry"><span class="meta">[永乐${l.year}·${l.season}]</span><span ${cls}>${l.text}</span></div>`;
    }).join('');
}

// ====== 奏折 / 政令 ======
function renderMemorialList() {
    const c = document.getElementById('memorialList'); if (!c) return;
    const scholarLine = `<div class="alert good" style="margin-bottom:8px;">当朝首辅【${state.scholar}】：${SCHOLAR_CAUTION[state.scholar] || ''}</div>`;
    if (state.currentMemorials.length === 0) { c.innerHTML = scholarLine + '<p>所有奏折已批复完毕。</p>'; return; }
    let html = scholarLine;
    state.currentMemorials.forEach(m => {
        let optsHtml = '';
        m.options.forEach((opt, idx) => { optsHtml += `<button onclick="handleMemorialChoice(${m.id}, ${idx})">${opt.text}</button>`; });
        html += `<div class="memorial-item">
            <h4>${m.title} <span style="color:#6a9ad5;font-size:10px;">[${m.type}]</span></h4>
            <p>${m.desc}</p>
            <div class="advisor">内阁建议：${m.advisor}</div>
            <div class="options">${optsHtml}</div>
        </div>`;
    });
    c.innerHTML = html;
}
function renderPolicyAck() {
    const s = document.getElementById('courtStatus'); if (!s) return;
    if (state.chosenPolicy) s.innerHTML = `本季已颁政令「${state.chosenPolicy}」。点击上方「开启${SEASONS[state.season-1]}季朝议」批复奏折。`;
}
let _projectAdvancedThisSeason = false;
function openPolicyPanel() { document.getElementById('policyModal').classList.remove('hide'); _projectAdvancedThisSeason = false; renderPolicyPanel(); }
function closePolicyModal() { document.getElementById('policyModal').classList.add('hide'); }
function renderPolicyPanel() {
    const list = POLICY_TEMPLATES[state.season] || [];
    const polHtml = `<h4>本季政令（${SEASONS[state.season-1]}季，必选其一）</h4>` +
        list.map((p, i) => `<div class="memorial-item">
            <h4 style="color:#7ec8ff;">${p.text}</h4><p>${p.desc}</p>
            <button ${state.policyChosen ? 'disabled' : ''} onclick="choosePolicy(${i})">颁行此令</button>
        </div>`).join('') +
        (state.chosenPolicy ? `<div class="alert good">本季已颁：「${state.chosenPolicy}」</div>` : '');
    const pol = document.getElementById('policyOpts'); if (pol) pol.innerHTML = polHtml;
    const lp = document.getElementById('policyListPanel'); if (lp) lp.innerHTML = polHtml;
    const proj = document.getElementById('projectOpts');
    if (proj) {
        let html = '<h4>修造奇观（可选，每季至多推进一座）</h4>';
        PROJECTS.forEach((p, idx) => {
            const building = state.projects.find(x => x.id === p.id);
            const done = state.doneProjects.includes(p.id);
            if (building) html += `<div class="memorial-item"><h4>${p.name}（营建中 ${building.progress}/${building.turns}）</h4>
                <div class="faction-bar-track"><div class="faction-bar-fill faction-inf" style="width:${Math.round(building.progress/building.turns*100)}%"></div></div>
                <button ${_projectAdvancedThisSeason ? 'disabled' : ''} onclick="advanceProject(${idx})">今日推进</button></div>`;
            else if (!done) {
                const can = state.treasury >= p.cost.treasury && (!p.cost.food || state.food >= p.cost.food);
                html += `<div class="memorial-item"><h4>${p.name}</h4><p>${p.desc}　造价：${p.cost.treasury}银${p.cost.food?' + '+p.cost.food+'粮':''}　工期：${p.turns}季</p>
                    <button ${can ? '' : 'disabled'} onclick="handleProject(${idx},'start')">破土动工</button></div>`;
            } else html += `<div class="memorial-item"><h4>${p.name} <span style="color:#80e080;">（已成）</span></h4></div>`;
        });
        proj.innerHTML = html;
    }
}
function beginMemorialsAction() { closePolicyModal(); if (state.currentMemorials.length === 0) generateMemorials(); renderMemorialList(); document.getElementById('memorialModal').classList.remove('hide'); document.getElementById('btnYear').disabled = true; }
function advanceProject(idx) { if (_projectAdvancedThisSeason) return; const p = PROJECTS[idx]; if (!p || !state.projects.some(x => x.id === p.id)) return; handleProject(idx, 'advance'); _projectAdvancedThisSeason = true; renderPolicyPanel(); renderProjectsPanel(); }

// ====== 奇观 / 皇子 / 账号 ======
function renderProjectsPanel() {
    const c = document.getElementById('projectsPanelContent'); if (!c) return;
    let html = state.doneProjects.length ? `<div style="margin-bottom:8px;">已落成：${state.doneProjects.map(id => PROJECT_NAMES[id]).join('、')}</div>` : '';
    html += state.projects.length
        ? state.projects.map(p => { const m = PROJECTS.find(x => x.id === p.id); return `<div class="log-entry">营建中：${m.name} ${p.progress}/${p.turns}</div>`; }).join('')
        : '<div style="color:#5a7a9f;font-size:11px;">暂无在建奇观。点击「开启朝议」时可选督建。</div>';
    c.innerHTML = html;
}
function renderPrincesPanel() {
    const c = document.getElementById('royalPanelContent'); if (!c) return;
    if (!state.princes.length) { c.innerHTML = '<div style="color:#5a7a9f;">尚无皇子。国立不早，恐社稷无继。</div>'; return; }
    let html = '';
    state.princes.forEach((p, i) => {
        const cls = p.ability >= 65 ? 'good' : p.ability < 40 ? 'danger' : '';
        html += `<div class="faction-block">
            <div class="faction-bar">
                <div class="faction-name">${p.name}</div>
                <span style="font-size:10px;color:#e8a040;">【${p.char}】</span>
                <span style="font-size:11px;" class="${cls}">资质 ${p.ability}</span>
                <span style="font-size:10px;color:#6a9ad5;">${p.age} 岁</span>
                ${p.crown ? '<span style="color:#e0d080;font-size:10px;">★ 太子</span>' : ''}
            </div>
            <div class="row">
                ${p.crown ? '' : `<button onclick="setHeir(${i})">立为太子</button>`}
                <button onclick="enfeoffPrince(${i})">就藩封王</button>
            </div>
        </div>`;
    });
    c.innerHTML = html;
}
function renderAccountList() {
    const db = getAccountDB();
    const c = document.getElementById('accountList'); if (!c) return;
    const names = Object.keys(db); const cur = getCurrentUser();
    c.innerHTML = names.length
        ? names.map(n => `<div class="account-pill ${n === cur ? 'sel' : ''}" onclick="quickLogin('${n}')">${n} · ${db[n].games||0}局 · ${db[n].endings?db[n].endings.length:0}结局</div>`).join('')
        : '<div style="color:#5a7a9f;font-size:11px;">尚无注册账号，请注册。</div>';
}
function renderAccountPanel() {
    const c = document.getElementById('accountPanelContent'); if (!c) return;
    const user = getCurrentUser(); const db = getAccountDB(); const acc = user ? db[user] : null;
    let endingsHtml = '';
    if (acc && acc.endings && acc.endings.length) {
        endingsHtml = acc.endings.slice().reverse().map(e => `<div class="log-entry"><span style="${e.type==='victory'?'color:#80e080;':''}">${e.name} · 永乐${e.year}年 · ${new Date(e.date).toLocaleDateString()}</span></div>`).join('');
    } else endingsHtml = '<div style="color:#5a7a9f;font-size:11px;">尚无历史结局。</div>';
    c.innerHTML = `
        <div class="faction-block">
            <div class="faction-bar"><div class="faction-name">当前账号</div><span style="color:#7ec8ff;font-weight:bold;">${user || '未登录'}</span></div>
            <div class="desc">已开局：${acc ? (acc.games||0) : 0} 局　累计在位：${acc ? (acc.yearsPlayed||0) : 0} 年</div>
        </div>
        <h4>历史结局</h4>
        ${endingsHtml}
        <p style="font-size:11px;color:#5a7a9f;margin-top:10px;">本账号为本地账号，进度仅保存在当前设备浏览器。跨设备同步需后端支持。</p>
        <div class="row" style="margin-top:10px;">
            <button class="green" onclick="startNewGame()">开启新局</button>
            <button class="red" onclick="logout()">切换账号</button>
        </div>`;
}

// ====== 府部（12 部院） ======
function renderDeptsPanel() {
    const c = document.getElementById('deptsPanelContent'); if (!c) return;
    let html = '<div class="row" style="margin-bottom:8px;"><button class="green" onclick="recruitGeneral()">招募新将</button></div>';
    html += '<h4>五军都督府 / 府部主官</h4>';
    DEPARTMENTS.forEach(d => {
        const h = state.deptHeads[d.id] || { name:'空缺', ability:0, loyalty:0 };
        const al = h.name === '空缺' ? 'danger' : '';
        html += `<div class="faction-block">
            <div class="faction-bar">
                <div class="faction-name">${d.name}</div>
                <span style="font-size:11px;color:#7ec8ff;" class="${al}">${h.name}</span>
            </div>
            <div class="desc" style="font-size:10px;">${d.desc}　职能：${d.function}</div>
            <div class="row" style="font-size:10px;color:#6a9ad5;">
                <span>能力 ${h.ability||'-'}</span>
                <span>忠诚 ${h.loyalty||'-'}</span>
                <span>流派 ${h.faction||'-'}</span>
            </div>
            <div class="row">
                <button onclick="promptAppoint('${d.id}')">任命</button>
            </div>
        </div>`;
    });
    c.innerHTML = html;
}
function promptAppoint(deptId) {
    const name = prompt('拟任主官姓名（留空则保留现任）', '');
    appointHead(deptId, name && name.trim() ? name.trim() : null);
    renderDeptsPanel();
}

// ====== 部队（军、将领、行军） ======
function renderArmiesPanel() {
    const c = document.getElementById('armyPanelContent'); if (!c) return;
    let html = '<div class="row" style="margin-bottom:8px;">';
    html += '<select id="newUnitType">';
    Object.keys(UNIT_TYPES).forEach(k => { html += `<option value="${k}">${UNIT_TYPES[k].name}（攻${UNIT_TYPES[k].atk} 防${UNIT_TYPES[k].def} 维持${UNIT_TYPES[k].cost}/千）</option>`; });
    html += '</select> ';
    html += '<input id="newUnitCount" type="number" value="1000" min="100" max="20000" step="100" style="width:80px;"> ';
    html += '<button class="green" onclick="cmdRaiseArmy()">募兵</button></div>';
    html += '<h4>在役军团</h4>';
    if (!state.armies.length) html += '<div style="color:#5a7a9f;font-size:11px;">尚无成军。</div>';
    state.armies.forEach(a => {
        const ut = UNIT_TYPES[a.unitType];
        const g = a.general;
        const status = a.status === 'marching' ? `行军中（${a.march.daysLeft}日）` : a.status === 'ready' ? '待命' : a.status;
        html += `<div class="faction-block">
            <div class="faction-bar">
                <div class="faction-name">${a.name}</div>
                <span style="font-size:11px;color:#7ec8ff;">${ut.name}×${a.count}</span>
                <span style="font-size:10px;color:#6a9ad5;">${status}</span>
            </div>
            <div class="row" style="font-size:10px;color:#6a9ad5;">
                <span>士气 ${a.morale}</span>
                <span>操练 ${a.training}</span>
                <span>驻地 ${nameOfProvince(a.origin||'shunTian')}</span>
            </div>
            <div class="row">
                <select id="g4a_${a.id}"><option value="">--指派将领--</option>${state.generals.map(g => `<option value="${g.id}">${g.name}（${g.style} 能${g.ability}）</option>`).join('')}</select>
                <button onclick="cmdAssignGeneral('${a.id}')">任命</button>
                <select id="m4a_${a.id}">${state.provinces.map(p => `<option value="${p.id}">${p.name}</option>`).join('')}</select>
                <button onclick="cmdMove('${a.id}')">调遣</button>
            </div>
        </div>`;
    });
    html += '<h4>在训新兵</h4>';
    if (!state.drafts.length) html += '<div style="color:#5a7a9f;font-size:11px;">无在训新兵。</div>';
    state.drafts.forEach(d => { html += `<div class="log-entry">${d.name}（${UNIT_TYPES[d.unitType].name}×${d.count}），${Math.ceil(d.daysLeft/30)}月后成军。</div>`; });
    html += '<h4>将领池</h4>';
    state.generals.forEach(g => { html += `<div class="log-entry">${g.name}【${g.style}】能${g.ability} 攻${g.stats.attack} 防${g.stats.defense} 智${g.stats.intellect}（${g.status}）</div>`; });
    c.innerHTML = html;
}
function cmdRaiseArmy() {
    const t = document.getElementById('newUnitType').value;
    const n = parseInt(document.getElementById('newUnitCount').value, 10) || 1000;
    raiseArmy(t, n);
    renderArmiesPanel();
}
function cmdAssignGeneral(armyId) {
    const gid = document.getElementById('g4a_' + armyId).value; if (!gid) return;
    assignGeneralToArmy(armyId, gid);
    renderArmiesPanel();
}
function cmdMove(armyId) {
    const pid = document.getElementById('m4a_' + armyId).value;
    moveArmy(armyId, pid);
    renderArmiesPanel();
}

// ====== 间谍 ======
function renderSpyPanel() {
    const c = document.getElementById('spyPanelContent'); if (!c) return;
    let html = `<h4>情报能力：${state.myIntel}/100</h4>`;
    html += '<h4>派遣间谍</h4>';
    state.nations.forEach(n => {
        const dipl = state.diplomacy[n.id] || 0;
        const war = state.currentWars[n.id] ? '（交战）' : '';
        html += `<div class="faction-block">
            <div class="faction-bar">
                <div class="faction-name">${n.name} ${war}</div>
                <span style="font-size:10px;color:#6a9ad5;">军力 ${n.military} 情报 ${n.gov.intelPower} 阁员 ${n.gov.ministersLeft}/${n.gov.ministers}</span>
            </div>
            <div class="row">`;
        SPY_OPS.forEach(op => { html += `<button onclick="dispatchSpy('${n.id}','${op.id}')">${op.name}（${op.cost}银）</button>`; });
        html += `</div>
            <div class="row" style="font-size:10px;color:#6a9ad5;">
                <span>外交：${dipl}</span>
                <span>首府：${n.capital}</span>
                <span>政体：${n.gov.type}</span>
            </div>
        </div>`;
    });
    html += '<h4>执行中任务</h4>';
    if (!state.spyMissions.length) html += '<div style="color:#5a7a9f;font-size:11px;">无。</div>';
    state.spyMissions.forEach(m => {
        const n = state.nations.find(x => x.id === m.nationId); const op = SPY_OPS.find(x => x.id === m.opId);
        html += `<div class="log-entry">${n.name}「${op.name}」${Math.ceil(m.daysLeft/30)}月后完成。</div>`;
    });
    c.innerHTML = html;
}

// ====== 市肆 ======
function renderMarketPanel() {
    const c = document.getElementById('marketPanelContent'); if (!c) return;
    if (!Object.keys(state.goodsPrices || {}).length) refreshMarketPrices();
    let html = '<h4>京都互市</h4><p style="font-size:11px;color:#6a9ad5;">随季节波动；可买入补库，可卖出套现。</p>';
    html += '<table><tr><th>品名</th><th>当前价</th><th>库存</th><th>操作</th></tr>';
    GOODS.forEach(g => {
        const p = state.goodsPrices[g.id] || g.base;
        const stock = state.market[g.id] || 0;
        html += `<tr>
            <td class="left">${g.name}（${g.unit}）</td>
            <td>${p}</td>
            <td>${stock}</td>
            <td>
                <input id="q_${g.id}" type="number" value="100" min="1" style="width:60px;">
                <button onclick="cmdBuy('${g.id}')">买</button>
                <button onclick="cmdSell('${g.id}')">卖</button>
            </td>
        </tr>`;
    });
    html += '</table>';
    html += '<button class="green" onclick="refreshMarketPrices()">刷新行情</button>';
    c.innerHTML = html;
}
function cmdBuy(id) { const q = parseInt(document.getElementById('q_' + id).value, 10) || 1; buyGood(id, q); renderMarketPanel(); }
function cmdSell(id) { const q = parseInt(document.getElementById('q_' + id).value, 10) || 1; sellGood(id, q); renderMarketPanel(); }

// ====== 敌国外交 ======
function renderDiplomacyPanel() {
    const c = document.getElementById('diplomacyPanelContent'); if (!c) return;
    let html = '<h4>四邻与朝贡国</h4>';
    state.nations.forEach(n => {
        const d = state.diplomacy[n.id] || 0;
        const war = state.currentWars[n.id] ? '<span style="color:#e06060;">[交战]</span>' : '';
        const diClr = d < 0 ? 'danger' : d > 30 ? 'good' : '';
        html += `<div class="faction-block">
            <div class="faction-bar">
                <div class="faction-name">${n.name} ${war}</div>
                <span style="font-size:11px;color:#7ec8ff;">首府：${n.capital}</span>
            </div>
            <div class="row" style="font-size:10px;color:#6a9ad5;">
                <span class="${diClr}">外交 ${d}</span>
                <span>军力 ${n.military}</span>
                <span>国库 ${n.treasury}</span>
                <span>性格 ${n.aiPersona}</span>
                <span>政体 ${n.gov.type}</span>
            </div>
            <div class="row">
                <button onclick="improveDiplomacy('${n.id}', 5); renderDiplomacyPanel();">+5 外交</button>
                <button onclick="improveDiplomacy('${n.id}', 15); renderDiplomacyPanel();">+15 外交（300 银）</button>
                <button onclick="declareWar('${n.id}'); renderDiplomacyPanel();">开战</button>
                <button onclick="makePeace('${n.id}'); renderDiplomacyPanel();">议和</button>
                <button onclick="openAttackPanel('${n.id}')">攻伐</button>
            </div>
            <div class="row" style="font-size:10px;color:#6a9ad5;">
                ${n.provinces.map((p, i) => `<button onclick="attackSingle('${n.id}', ${i})">击 ${p.name}</button>`).join(' ')}
            </div>
        </div>`;
    });
    html += '<h4>战报</h4>';
    if (!state.battleLog.length) html += '<div style="color:#5a7a9f;font-size:11px;">无战事。</div>';
    state.battleLog.slice(0, 8).forEach(b => html += `<div class="log-entry">永乐${b.year}·${b.season} 攻${b.target}：歼敌${b.enLoss} 我损${b.myLoss}</div>`);
    c.innerHTML = html;
}
function openAttackPanel(nationId) {
    const sel = state.armies.filter(a => a.status === 'ready').map(a => a.id).join(',');
    if (!sel) { alert('没有可调遣的待命军团。'); return; }
    const which = prompt('输入参战军团 id（逗号分隔，留空为所有待命军）', sel);
    let ids = which ? which.split(',').filter(Boolean) : state.armies.filter(a => a.status === 'ready').map(a => a.id);
    const npIdx = prompt('攻哪个省（0,1,2...）', '0');
    const idx = parseInt(npIdx, 10) || 0;
    attackProvince(nationId, idx, ids);
    renderDiplomacyPanel();
    renderArmiesPanel();
}
function attackSingle(nationId, provinceIdx) {
    const ids = state.armies.filter(a => a.status === 'ready').map(a => a.id);
    if (!ids.length) { alert('没有可调遣的待命军团。'); return; }
    attackProvince(nationId, provinceIdx, ids);
    renderDiplomacyPanel();
    renderArmiesPanel();
}

// ====== 地图（可缩放可拖动） ======
let _mapDrag = null;
function renderMapPanel() {
    const c = document.getElementById('mapPanelContent'); if (!c) return;
    if (!c.dataset.inited) {
        c.innerHTML = `
            <div class="map-toolbar">
                <span style="font-size:11px;color:#6a9ad5;">滚轮缩放 · 拖动平移 · 点击省/军查看详情</span>
                <span style="flex:1;"></span>
                <button onclick="mapZoom(1.2)">+</button>
                <button onclick="mapZoom(0.83)">−</button>
                <button onclick="mapReset()">复位</button>
            </div>
            <div id="mapView" class="map-view">
                <div id="mapInner" class="map-inner">
                    <svg id="mapSvg" width="600" height="560" viewBox="0 0 500 500" preserveAspectRatio="xMidYMid meet"></svg>
                </div>
            </div>
            <div id="mapInfo" class="map-info"></div>
        `;
        c.dataset.inited = '1';
        const view = document.getElementById('mapView');
        view.addEventListener('wheel', (e) => { e.preventDefault(); mapZoom(e.deltaY < 0 ? 1.1 : 0.9); }, { passive:false });
        view.addEventListener('mousedown', (e) => { _mapDrag = { x: e.clientX, y: e.clientY }; });
        window.addEventListener('mousemove', (e) => { if (!_mapDrag) return; state.mapView.x += e.clientX - _mapDrag.x; state.mapView.y += e.clientY - _mapDrag.y; _mapDrag.x = e.clientX; _mapDrag.y = e.clientY; applyMapTransform(); });
        window.addEventListener('mouseup', () => { _mapDrag = null; });
    }
    drawMap();
}
function applyMapTransform() {
    const inner = document.getElementById('mapInner');
    if (!inner) return;
    inner.style.transform = `translate(${state.mapView.x}px, ${state.mapView.y}px) scale(${state.mapView.scale})`;
}
function mapZoom(f) { state.mapView.scale = Math.max(0.5, Math.min(3, state.mapView.scale * f)); applyMapTransform(); }
function mapReset() { state.mapView = { x:0, y:0, scale:1 }; applyMapTransform(); }
function drawMap() {
    const svg = document.getElementById('mapSvg'); if (!svg) return;
    // 背景
    let s = `<rect x="0" y="0" width="500" height="500" fill="#0a1020" stroke="#1a3050"/>`;
    // 邻接线
    const drawn = new Set();
    state.provinces.forEach(p => {
        (PROVINCE_NEIGHBORS[p.id] || []).forEach(nb => {
            const key = [p.id, nb].sort().join('|');
            if (drawn.has(key)) return; drawn.add(key);
            const np = state.provinces.find(x => x.id === nb); if (!np) return;
            s += `<line x1="${p.x}" y1="${p.y}" x2="${np.x}" y2="${np.y}" stroke="#1e3a5f" stroke-width="1"/>`;
        });
    });
    // 省
    state.provinces.forEach(p => {
        const r = p.type === 'capital' ? 10 : p.type === 'rich' ? 8 : p.type === 'border' ? 7 : 6;
        const fill = p.type === 'capital' ? '#7ec8ff' : p.type === 'rich' ? '#5ac88a' : p.type === 'border' ? '#e8a040' : p.type === 'coast' ? '#5a9ad5' : '#6a8ab5';
        s += `<circle cx="${p.x}" cy="${p.y}" r="${r}" fill="${fill}" stroke="#0a1020" stroke-width="2" style="cursor:pointer" onclick="showProvince('${p.id}')">
            <title>${p.name}（${p.type}）</title></circle>`;
        s += `<text x="${p.x}" y="${p.y - r - 4}" fill="#b8c8e0" font-size="9" text-anchor="middle">${p.name}</text>`;
    });
    // 敌国位置
    state.nations.forEach(n => {
        n.provinces.forEach(p => {
            s += `<rect x="${p.x-6}" y="${p.y-6}" width="12" height="12" fill="${n.color}" stroke="#fff" stroke-width="1">
                <title>${n.name}·${p.name}</title></rect>`;
        });
    });
    // 军团
    state.armies.forEach(a => {
        const p = state.provinces.find(x => x.id === (a.origin || 'shunTian'));
        if (!p) return;
        const c = a.status === 'marching' ? '#e0d080' : '#80e080';
        s += `<polygon points="${p.x-5},${p.y+5} ${p.x+5},${p.y+5} ${p.x},${p.y-7}" fill="${c}" stroke="#0a1020" stroke-width="1">
            <title>${a.name}（${UNIT_TYPES[a.unitType].name}×${a.count}）</title></polygon>`;
    });
    svg.innerHTML = s;
}
function showProvince(pid) {
    const p = state.provinces.find(x => x.id === pid);
    if (!p) return;
    const myArmies = state.armies.filter(a => (a.origin || 'shunTian') === pid);
    const html = `<div class="row"><div class="stat-box"><l>省名</l><s>${p.name}</s></div>
        <div class="stat-box"><l>类型</l><s>${p.type}</s></div>
        <div class="stat-box"><l>人口</l><s>${p.pop}万</s></div>
        <div class="stat-box"><l>粮产</l><s>${p.grain}万石</s></div>
        <div class="stat-box"><l>商业</l><s>${p.commerce}</s></div>
        <div class="stat-box"><l>城防</l><s>${p.fort}</s></div>
        <div class="stat-box"><l>忠诚</l><s>${p.loyalty}</s></div>
        <div class="stat-box"><l>卫所</l><s>${p.garrison}</s></div></div>
        <h4>驻军</h4>
        ${myArmies.length ? myArmies.map(a => `<div class="log-entry">${a.name}（${UNIT_TYPES[a.unitType].name}×${a.count}）${a.general?`主将：${a.general.name}`:''} ${a.status==='marching'?'行军中':'待命'}</div>`).join('') : '<div style="color:#5a7a9f;font-size:11px;">本省无我军。</div>'}`;
    document.getElementById('mapInfo').innerHTML = html;
}

// ====== 登录 / 注册 ======
function showLogin() { document.getElementById('loginOverlay').classList.remove('hide'); renderAccountList(); }
function hideLogin() { document.getElementById('loginOverlay').classList.add('hide'); }
function setAuthTab(tab) {
    document.getElementById('loginForm').classList.toggle('hide', tab !== 'login');
    document.getElementById('registerForm').classList.toggle('hide', tab !== 'register');
    const tl = document.getElementById('tabLogin'); const tr = document.getElementById('tabReg');
    if (tl) tl.classList.toggle('sel', tab === 'login');
    if (tr) tr.classList.toggle('sel', tab === 'register');
}
function handleLogin() { const u = document.getElementById('loginUser').value; const p = document.getElementById('loginPass').value; const res = loginAccount(u, p); if (res.ok) enterGame(); else showAuthMsg(res.msg, true); }
function handleRegister() {
    const u = document.getElementById('regUser').value; const p = document.getElementById('regPass').value; const p2 = document.getElementById('regPass2').value;
    if (p !== p2) { showAuthMsg('两次密码不一致', true); return; }
    const res = registerAccount(u, p); if (res.ok) { showAuthMsg(res.msg); enterGame(); } else showAuthMsg(res.msg, true);
}
function showAuthMsg(msg, isErr) { const el = document.getElementById('authMsg'); if (!el) return; el.textContent = msg; el.style.color = isErr ? '#e06060' : '#80e080'; }
function quickLogin(name) { const u = document.getElementById('loginUser'); if (u) u.value = name; setAuthTab('login'); showAuthMsg(`已选账号"${name}"，请输入密码。`, false); }
function enterGame() {
    const app = document.getElementById('app'); if (app) app.classList.remove('hide');
    hideLogin();
    const user = getCurrentUser();
    const loaded = loadGame();
    if (!loaded) newGame();
    if (!state.scholar) state.scholar = SCHOLAR_LIST[Math.floor(Math.random() * SCHOLAR_LIST.length)];
    if (!Array.isArray(state.projects)) state.projects = [];
    if (!Array.isArray(state.doneProjects)) state.doneProjects = [];
    if (!Array.isArray(state.princes)) state.princes = [];
    if (!Array.isArray(state.generals)) state.generals = [];
    if (!Array.isArray(state.armies)) state.armies = [];
    if (!state.diplomacy) state.diplomacy = {};
    if (!state.market) state.market = { grain:0,salt:0,iron:0,tea:0,silk:0,horse:0,cannon:0,porcelain:0,cotton:0,paper:0 };
    log(`登录成功：${user}。`, 'good');
    if (!state.princes.length) ensureFirstPrince();
    if (!Object.keys(state.deptHeads || {}).length) initDeptHeads();
    if (!state.generals.length) ensureGenerals();
    if (!Object.keys(state.goodsPrices || {}).length) refreshMarketPrices();
    refreshAllUI();
    if (typeof switchTab === 'function') switchTab('court');
    updateSeasonButton();
    if (typeof saveGame === 'function') saveGame();
}
function logout() { logoutAccount(); const app = document.getElementById('app'); if (app) app.classList.add('hide'); showLogin(); }
function startNewGame() { newGame(); log('开启新的一局，再续大明！', 'good'); refreshAllUI(); switchTab('court'); updateSeasonButton(); saveGame(); }
function refreshAllUI() {
    ['updateTopBar','renderFactionPanel','renderOverview','renderLog','renderFactionAlert','renderPolicyPanel','renderProjectsPanel','renderPrincesPanel','renderDiplomacyPanel','renderArmiesPanel','renderMarketPanel','renderSpyPanel','renderDeptsPanel','renderAccountPanel','renderAccountList'].forEach(fn => { try { if (typeof window[fn] === 'function') window[fn](); } catch(e){} });
    updateSeasonButton();
}
function showGameOver() {
    const s = document.getElementById('courtStatus'); const b = document.getElementById('btnYear');
    if (state.victory) { if (s) s.innerHTML = '<span style="color:#80e080;font-size:14px;">🎉 大明万年！盛世达成！</span>'; }
    else { if (s) s.innerHTML = '<span style="color:#e06060;font-size:14px;">💀 国祚断绝，大明亡矣！</span>'; }
    if (b) { b.disabled = true; b.textContent = state.victory ? '盛世已成' : '国祚已断'; }
}
function switchTab(tab) {
    document.querySelectorAll('.panel').forEach(p => p.classList.add('hide'));
    document.querySelectorAll('.navBtn').forEach(b => b.classList.remove('act'));
    const panel = document.getElementById('panel-' + tab);
    if (panel) panel.classList.remove('hide');
    const btn = document.querySelector(`.navBtn[data-tab="${tab}"]`);
    if (btn) btn.classList.add('act');
    if (tab === 'account') renderAccountPanel();
    if (tab === 'projects') renderProjectsPanel();
    if (tab === 'royal') renderPrincesPanel();
    if (tab === 'depts') renderDeptsPanel();
    if (tab === 'army') renderArmiesPanel();
    if (tab === 'spy') renderSpyPanel();
    if (tab === 'market') renderMarketPanel();
    if (tab === 'diplomacy') renderDiplomacyPanel();
    if (tab === 'map') renderMapPanel();
}
// 暴露到 window
window.startCourt = startCourt;
window.switchTab = switchTab;
window.handleMemorialChoice = handleMemorialChoice;
window.choosePolicy = choosePolicy;
window.handleProject = handleProject;
window.advanceProject = advanceProject;
window.setHeir = setHeir;
window.enfeoffPrince = enfeoffPrince;
window.openPolicyPanel = openPolicyPanel;
window.beginMemorialsAction = beginMemorialsAction;
window.showLogin = showLogin;
window.hideLogin = hideLogin;
window.setAuthTab = setAuthTab;
window.handleLogin = handleLogin;
window.handleRegister = handleRegister;
window.logout = logout;
window.startNewGame = startNewGame;
window.recruitGeneral = recruitGeneral;
window.promptAppoint = promptAppoint;
window.raiseArmy = raiseArmy;
window.assignGeneralToArmy = assignGeneralToArmy;
window.unassignGeneral = unassignGeneral;
window.moveArmy = moveArmy;
window.attackProvince = attackProvince;
window.dispatchSpy = dispatchSpy;
window.buyGood = buyGood;
window.sellGood = sellGood;
window.refreshMarketPrices = refreshMarketPrices;
window.declareWar = declareWar;
window.makePeace = makePeace;
window.improveDiplomacy = improveDiplomacy;
window.attackSingle = attackSingle;
window.openAttackPanel = openAttackPanel;
window.cmdRaiseArmy = cmdRaiseArmy;
window.cmdAssignGeneral = cmdAssignGeneral;
window.cmdMove = cmdMove;
window.cmdBuy = cmdBuy;
window.cmdSell = cmdSell;
window.mapZoom = mapZoom;
window.mapReset = mapReset;
window.showProvince = showProvince;
window.quickLogin = quickLogin;
